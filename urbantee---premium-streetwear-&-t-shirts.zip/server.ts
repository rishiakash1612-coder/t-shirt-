import express from 'express';
import cors from 'cors';
import path from 'path';
import { createServer as createViteServer } from 'vite';

import authRoutes from './server/routes/auth.js';
import productRoutes from './server/routes/products.js';
import categoryRoutes from './server/routes/categories.js';
import cartRoutes from './server/routes/cart.js';
import wishlistRoutes from './server/routes/wishlist.js';
import orderRoutes from './server/routes/orders.js';
import couponRoutes from './server/routes/coupons.js';
import reviewRoutes from './server/routes/reviews.js';
import analyticsRoutes from './server/routes/analytics.js';
import userRoutes from './server/routes/users.js';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Basic Middlewares
  app.use(cors());
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', service: 'UrbanTee Backend Engine', version: '2.0.0' });
  });

  // REST API Routes
  app.use('/api/auth', authRoutes);
  app.use('/api/products', productRoutes);
  app.use('/api/categories', categoryRoutes);
  app.use('/api/cart', cartRoutes);
  app.use('/api/wishlist', wishlistRoutes);
  app.use('/api/orders', orderRoutes);
  app.use('/api/coupons', couponRoutes);
  app.use('/api/reviews', reviewRoutes);
  app.use('/api/admin/analytics', analyticsRoutes);
  app.use('/api/users', userRoutes);

  // Vite middleware for dev or static bundle for prod
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`UrbanTee Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
