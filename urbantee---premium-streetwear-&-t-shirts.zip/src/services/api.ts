import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json'
  }
});

// Attach JWT token and guest session ID automatically
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('urbantee_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  let guestSessionId = localStorage.getItem('urbantee_guest_id');
  if (!guestSessionId) {
    guestSessionId = 'guest_' + Math.random().toString(36).substring(2, 10);
    localStorage.setItem('urbantee_guest_id', guestSessionId);
  }
  config.headers['x-guest-session-id'] = guestSessionId;

  return config;
});

export default api;
