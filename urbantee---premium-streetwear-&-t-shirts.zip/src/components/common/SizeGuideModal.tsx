import React, { useState } from 'react';
import { X, Ruler, CheckCircle } from 'lucide-react';

interface SizeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SizeGuideModal: React.FC<SizeGuideModalProps> = ({ isOpen, onClose }) => {
  const [unit, setUnit] = useState<'inches' | 'cm'>('inches');

  if (!isOpen) return null;

  const sizeChart = [
    { size: 'S', chestIn: '40"', chestCm: '102 cm', lengthIn: '28"', lengthCm: '71 cm', shoulderIn: '20"', shoulderCm: '51 cm' },
    { size: 'M', chestIn: '42"', chestCm: '107 cm', lengthIn: '29"', lengthCm: '74 cm', shoulderIn: '21"', shoulderCm: '53 cm' },
    { size: 'L', chestIn: '44"', chestCm: '112 cm', lengthIn: '30"', lengthCm: '76 cm', shoulderIn: '22"', shoulderCm: '56 cm' },
    { size: 'XL', chestIn: '46"', chestCm: '117 cm', lengthIn: '31"', lengthCm: '79 cm', shoulderIn: '23"', shoulderCm: '58 cm' },
    { size: 'XXL', chestIn: '48"', chestCm: '122 cm', lengthIn: '32"', lengthCm: '81 cm', shoulderIn: '24"', shoulderCm: '61 cm' }
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative bg-white dark:bg-neutral-900 rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-neutral-200 dark:border-neutral-800">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-neutral-400 hover:text-neutral-900 dark:hover:text-white rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-2">
          <Ruler className="w-5 h-5 text-neutral-900 dark:text-white" />
          <h2 className="text-xl font-extrabold text-neutral-900 dark:text-white font-heading">
            UrbanTee Size Guide & Measurements
          </h2>
        </div>
        <p className="text-xs text-neutral-500 mb-6">
          Our oversized t-shirts are designed with a boxy, dropped-shoulder silhouette. If you prefer a regular tailored fit, consider sizing down one size.
        </p>

        {/* Unit Toggle */}
        <div className="flex justify-end mb-4">
          <div className="bg-neutral-100 dark:bg-neutral-800 p-1 rounded-xl flex gap-1 text-xs font-bold">
            <button
              onClick={() => setUnit('inches')}
              className={`px-3 py-1 rounded-lg transition-all ${
                unit === 'inches' ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-sm' : 'text-neutral-500'
              }`}
            >
              Inches (in)
            </button>
            <button
              onClick={() => setUnit('cm')}
              className={`px-3 py-1 rounded-lg transition-all ${
                unit === 'cm' ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-sm' : 'text-neutral-500'
              }`}
            >
              Centimeters (cm)
            </button>
          </div>
        </div>

        {/* Size Table */}
        <div className="overflow-x-auto rounded-2xl border border-neutral-200 dark:border-neutral-800 mb-6">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-100 dark:bg-neutral-800 text-neutral-900 dark:text-white font-bold">
              <tr>
                <th className="p-3">Size</th>
                <th className="p-3">Chest Circumference</th>
                <th className="p-3">Body Length</th>
                <th className="p-3">Shoulder Width</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200 dark:divide-neutral-800 text-neutral-700 dark:text-neutral-300">
              {sizeChart.map((row) => (
                <tr key={row.size} className="hover:bg-neutral-50 dark:hover:bg-neutral-800/50">
                  <td className="p-3 font-bold text-neutral-900 dark:text-white">{row.size}</td>
                  <td className="p-3">{unit === 'inches' ? row.chestIn : row.chestCm}</td>
                  <td className="p-3">{unit === 'inches' ? row.lengthIn : row.lengthCm}</td>
                  <td className="p-3">{unit === 'inches' ? row.shoulderIn : row.shoulderCm}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Measuring Tips */}
        <div className="bg-neutral-50 dark:bg-neutral-800/40 rounded-2xl p-4 border border-neutral-200 dark:border-neutral-800">
          <p className="text-xs font-bold text-neutral-900 dark:text-white uppercase tracking-wider mb-2">
            How to Measure:
          </p>
          <ul className="space-y-1.5 text-xs text-neutral-600 dark:text-neutral-400">
            <li className="flex items-start gap-2">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-500 mt-0.5 shrink-0" />
              <span><strong>Chest:</strong> Measure horizontally around the fullest part of your chest, keeping the tape under arms.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-500 mt-0.5 shrink-0" />
              <span><strong>Length:</strong> Measure from the highest point of the shoulder down to the bottom hemline.</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
