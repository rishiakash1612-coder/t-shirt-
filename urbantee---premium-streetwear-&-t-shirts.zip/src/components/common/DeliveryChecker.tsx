import React, { useState } from 'react';
import { MapPin, CheckCircle2, Clock, Truck, Zap } from 'lucide-react';

export const DeliveryChecker: React.FC = () => {
  const [pincode, setPincode] = useState('600040');
  const [result, setResult] = useState<{
    available: boolean;
    city?: string;
    state?: string;
    estDays?: string;
    codAvailable?: boolean;
    hub?: string;
  }>({
    available: true,
    city: 'Chennai (Anna Nagar)',
    state: 'Tamil Nadu',
    estDays: '24-36 Hours Express',
    codAvailable: true,
    hub: 'Dispatches from Tirupur Central Hub'
  });
  const [isChecking, setIsChecking] = useState(false);

  const tnQuickPins = [
    { city: 'Chennai', pin: '600040' },
    { city: 'Coimbatore', pin: '641002' },
    { city: 'Madurai', pin: '625001' },
    { city: 'Tirupur', pin: '641604' },
    { city: 'Trichy', pin: '620001' },
    { city: 'Salem', pin: '636001' }
  ];

  const handleCheck = (e?: React.FormEvent, customPin?: string) => {
    if (e) e.preventDefault();
    const pinToUse = customPin || pincode;
    if (!pinToUse || pinToUse.length !== 6 || isNaN(Number(pinToUse))) {
      return;
    }

    setIsChecking(true);
    setTimeout(() => {
      const isTamilNadu = pinToUse.startsWith('60') || pinToUse.startsWith('61') || pinToUse.startsWith('62') || pinToUse.startsWith('63') || pinToUse.startsWith('64');
      
      let locName = 'Tamil Nadu Express Delivery Zone';
      if (pinToUse.startsWith('600') || pinToUse.startsWith('601') || pinToUse.startsWith('602') || pinToUse.startsWith('603')) locName = 'Chennai & North TN';
      else if (pinToUse.startsWith('641')) locName = 'Coimbatore & Nilgiris';
      else if (pinToUse.startsWith('6416') || pinToUse.startsWith('638')) locName = 'Tirupur & Erode Central Hub';
      else if (pinToUse.startsWith('625') || pinToUse.startsWith('624')) locName = 'Madurai & South TN';
      else if (pinToUse.startsWith('620') || pinToUse.startsWith('621')) locName = 'Tiruchirappalli (Trichy)';
      else if (pinToUse.startsWith('636') || pinToUse.startsWith('637')) locName = 'Salem & Namakkal';
      else if (isTamilNadu) locName = 'Tamil Nadu District';
      else locName = 'All India Delivery';

      setResult({
        available: true,
        city: locName,
        state: isTamilNadu ? 'Tamil Nadu' : 'Rest of India',
        estDays: isTamilNadu ? '24-48 Hours Express' : '3-4 Business Days',
        codAvailable: true,
        hub: isTamilNadu ? 'Dispatched directly from Tirupur Hub' : 'Standard Air Express'
      });
      setIsChecking(false);
    }, 250);
  };

  const handleQuickSelect = (pin: string) => {
    setPincode(pin);
    handleCheck(undefined, pin);
  };

  return (
    <div className="bg-neutral-50 dark:bg-neutral-800/40 rounded-2xl p-4 border border-neutral-200 dark:border-neutral-800 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MapPin className="w-4 h-4 text-rose-500" />
          <span className="text-xs font-bold text-neutral-900 dark:text-white font-heading uppercase tracking-wider">
            Check Delivery in Tamil Nadu & COD
          </span>
        </div>
        <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800">
          ⚡ 24hr Dispatch from Tirupur
        </span>
      </div>

      <form onSubmit={(e) => handleCheck(e)} className="flex gap-2">
        <input
          type="text"
          maxLength={6}
          value={pincode}
          onChange={(e) => {
            setPincode(e.target.value.replace(/\D/g, ''));
          }}
          placeholder="Enter 6-digit PIN (e.g. 600040)"
          className="flex-1 px-3 py-2 text-xs rounded-xl bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 text-neutral-900 dark:text-white font-mono placeholder:font-sans placeholder:text-neutral-400 focus:outline-none focus:border-neutral-900 dark:focus:border-white"
        />
        <button
          type="submit"
          disabled={pincode.length !== 6 || isChecking}
          className="px-4 py-2 bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 text-xs font-bold rounded-xl hover:opacity-90 disabled:opacity-40 transition-opacity"
        >
          {isChecking ? 'Checking...' : 'Check'}
        </button>
      </form>

      {/* Quick Select Tamil Nadu Major Cities */}
      <div className="flex items-center gap-1.5 flex-wrap pt-1">
        <span className="text-[10px] text-neutral-400 font-medium">Quick Pick:</span>
        {tnQuickPins.map((item) => (
          <button
            key={item.pin}
            type="button"
            onClick={() => handleQuickSelect(item.pin)}
            className={`text-[10px] px-2 py-0.5 rounded-lg border transition-all ${
              pincode === item.pin
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 border-neutral-900 font-bold'
                : 'bg-white dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700 hover:border-neutral-400'
            }`}
          >
            {item.city} ({item.pin})
          </button>
        ))}
      </div>

      {result && (
        <div className="pt-2 border-t border-neutral-200 dark:border-neutral-700 space-y-1.5 text-xs animate-fade-in">
          <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-semibold">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>Delivery available for {pincode} ({result.city})</span>
          </div>
          <div className="flex items-center justify-between text-neutral-600 dark:text-neutral-300 pl-6 text-[11px] flex-wrap gap-2">
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-neutral-400" />
              Delivery: <strong className="text-neutral-900 dark:text-white">{result.estDays}</strong>
            </span>
            <span className="flex items-center gap-1">
              <Truck className="w-3.5 h-3.5 text-neutral-400" />
              COD: <strong className="text-emerald-600">Available at ₹0 Extra</strong>
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
