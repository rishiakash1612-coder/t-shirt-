import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { X, Star, Heart, ShoppingBag, Truck, ShieldCheck, Check, Zap, Sparkles } from 'lucide-react';
import { Product } from '../../types';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';

interface QuickViewModalProps {
  product: Product | null;
  onClose: () => void;
}

export const QuickViewModal: React.FC<QuickViewModalProps> = ({ product, onClose }) => {
  if (!product) return null;

  const { addToCart } = useCart();
  const { isInWishlist, toggleWishlist } = useWishlist();

  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'M');
  const [selectedColor, setSelectedColor] = useState(product.colors[0]?.name || '');
  const [quantity, setQuantity] = useState(1);
  const [isAdding, setIsAdding] = useState(false);

  useEffect(() => {
    if (product) {
      setSelectedImage(0);
      setSelectedSize(product.sizes[0] || 'M');
      setSelectedColor(product.colors[0]?.name || '');
      setQuantity(1);
    }
  }, [product]);

  const inWishlist = isInWishlist(product.id);

  const handleAddToCart = async () => {
    setIsAdding(true);
    await addToCart(product.id, selectedSize, selectedColor, quantity);
    setIsAdding(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative bg-white dark:bg-neutral-900 rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-800">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 text-neutral-500 hover:text-neutral-900 dark:hover:text-white rounded-full bg-white/80 dark:bg-neutral-800/80 backdrop-blur-sm transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          
          {/* Gallery side */}
          <div className="p-6 bg-neutral-50 dark:bg-neutral-800/40 flex flex-col justify-between">
            <div className="aspect-[3/4] rounded-2xl overflow-hidden bg-neutral-200 dark:bg-neutral-800 mb-3 shadow-inner">
              <img
                src={product.images[selectedImage] || product.images[0]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Thumbnail selector (All 4-6 images) */}
            {product.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-1">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`w-14 h-16 rounded-xl overflow-hidden border-2 shrink-0 transition-all ${
                      selectedImage === idx
                        ? 'border-neutral-900 dark:border-white scale-105 shadow-md'
                        : 'border-transparent opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Details side */}
          <div className="p-6 md:p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
                <span className="uppercase font-bold tracking-wider text-amber-600 dark:text-amber-400">
                  {product.category === 'tamil-drops' ? 'தமிழ்நாடு ஸ்பெஷல்' : product.category}
                </span>
                <span className="font-mono text-neutral-500">{product.sku}</span>
              </div>

              <h2 className="text-lg sm:text-xl font-extrabold text-neutral-900 dark:text-white font-heading">
                {product.name}
              </h2>

              <div className="flex items-center gap-2 mt-1.5">
                <div className="flex items-center text-amber-400">
                  <Star className="w-3.5 h-3.5 fill-current" />
                </div>
                <span className="text-xs font-bold text-neutral-900 dark:text-white">{product.rating}</span>
                <span className="text-xs text-neutral-400">({product.reviewCount} customer reviews)</span>
              </div>

              {/* Price */}
              <div className="flex items-baseline gap-2.5 mt-3">
                <span className="text-2xl font-black text-neutral-900 dark:text-white">₹{product.price}</span>
                {product.originalPrice > product.price && (
                  <span className="text-xs text-neutral-400 line-through">₹{product.originalPrice}</span>
                )}
                {product.discount > 0 && (
                  <span className="px-2 py-0.5 bg-rose-500/10 text-rose-600 dark:text-rose-400 text-xs font-bold rounded-md">
                    {product.discount}% OFF
                  </span>
                )}
                {product.price <= 299 && (
                  <span className="px-2 py-0.5 bg-amber-400 text-neutral-950 text-[10px] font-black rounded-md uppercase">
                    Zudio Price
                  </span>
                )}
              </div>

              {/* Fabric Specs */}
              <div className="mt-2 text-xs font-medium text-neutral-600 dark:text-neutral-300">
                <span>{product.fabric}</span> • <span>{product.gsm} GSM</span> • <span>{product.fit}</span>
              </div>

              {/* Color Select (Multiple colors) */}
              <div className="mt-4">
                <p className="text-xs font-bold text-neutral-900 dark:text-white mb-2">
                  Select Color: <span className="font-normal text-amber-600 dark:text-amber-400 font-bold">{selectedColor}</span>
                </p>
                <div className="flex gap-2 flex-wrap">
                  {product.colors.map((c) => (
                    <button
                      key={c.name}
                      onClick={() => setSelectedColor(c.name)}
                      className={`w-7 h-7 rounded-full border-2 p-0.5 flex items-center justify-center transition-all ${
                        selectedColor === c.name ? 'border-neutral-900 dark:border-white scale-110 shadow-sm ring-1 ring-amber-400' : 'border-transparent'
                      }`}
                      title={c.name}
                    >
                      <span className="w-full h-full rounded-full border border-neutral-300 shadow-inner" style={{ backgroundColor: c.hex }} />
                    </button>
                  ))}
                </div>
              </div>

              {/* Size Select */}
              <div className="mt-4">
                <p className="text-xs font-bold text-neutral-900 dark:text-white mb-2">
                  Select Size: <span className="font-normal text-neutral-500">{selectedSize}</span>
                </p>
                <div className="flex gap-1.5">
                  {product.sizes.map((sz) => (
                    <button
                      key={sz}
                      onClick={() => setSelectedSize(sz)}
                      className={`px-3 py-1.5 text-xs font-bold rounded-xl border transition-all ${
                        selectedSize === sz
                          ? 'border-neutral-900 bg-neutral-900 text-white dark:border-white dark:bg-white dark:text-neutral-900 shadow'
                          : 'border-neutral-200 dark:border-neutral-700 hover:border-neutral-400 text-neutral-800 dark:text-neutral-200'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-6 border-t border-neutral-200 dark:border-neutral-800 mt-4 space-y-2">
              <div className="flex gap-3">
                <button
                  onClick={handleAddToCart}
                  disabled={isAdding || product.stock <= 0}
                  className="flex-1 py-3 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-900 font-extrabold text-xs uppercase tracking-wider rounded-xl shadow-lg flex items-center justify-center gap-2 transition-all disabled:opacity-50"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>{isAdding ? 'Adding...' : 'Add to Bag'}</span>
                </button>

                <button
                  onClick={() => toggleWishlist(product.id)}
                  className={`p-3 rounded-xl border transition-colors ${
                    inWishlist
                      ? 'bg-rose-500 text-white border-rose-500'
                      : 'border-neutral-300 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${inWishlist ? 'fill-current' : ''}`} />
                </button>
              </div>

              <Link
                to={`/product/${product.slug}`}
                onClick={onClose}
                className="block text-center text-xs font-bold text-neutral-600 dark:text-neutral-400 hover:underline pt-1"
              >
                View Full Specifications & Tamil Nadu Reviews →
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
