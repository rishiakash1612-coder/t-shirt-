import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Eye, Star, ShoppingBag, Check, Zap, Sparkles } from 'lucide-react';
import { Product } from '../../types';
import { useWishlist } from '../../context/WishlistContext';
import { useCart } from '../../context/CartContext';
import { useCompare } from '../../context/CompareContext';

interface ProductCardProps {
  product: Product;
  onQuickView?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onQuickView }) => {
  const { isInWishlist, toggleWishlist } = useWishlist();
  const { addToCart } = useCart();
  const { isComparing, addToCompare } = useCompare();

  const [isHovered, setIsHovered] = useState(false);
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'M');
  const [selectedColorIdx, setSelectedColorIdx] = useState<number>(0);
  const [showSizeSelector, setShowSizeSelector] = useState(false);
  const [isAdding, setIsAdding] = useState(false);

  const inWishlist = isInWishlist(product.id);
  const comparing = isComparing(product.id);

  const currentColor = product.colors[selectedColorIdx] || product.colors[0];

  const handleQuickAdd = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsAdding(true);
    await addToCart(
      product.id,
      selectedSize,
      currentColor?.name || 'Standard',
      1
    );
    setIsAdding(false);
    setShowSizeSelector(false);
  };

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleWishlist(product.id);
  };

  const handleCompareToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCompare(product);
  };

  const primaryImage = product.images[0] || 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80';
  const secondaryImage = product.images[1] || primaryImage;
  const activeImage = isHovered && product.images.length > 1 ? secondaryImage : (product.images[selectedColorIdx % product.images.length] || primaryImage);

  return (
    <div
      className="group relative bg-white dark:bg-neutral-900 rounded-2xl overflow-hidden border border-neutral-200/80 dark:border-neutral-800 flex flex-col transition-all duration-300 hover:shadow-xl hover:border-neutral-300 dark:hover:border-neutral-700"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        setShowSizeSelector(false);
      }}
    >
      {/* Image Container with Badges */}
      <div className="relative aspect-[3/4] w-full overflow-hidden bg-neutral-100 dark:bg-neutral-800">
        
        {/* Discount & Price Badges */}
        <div className="absolute top-2.5 left-2.5 z-10 flex flex-col gap-1">
          {product.discount > 0 && (
            <span className="px-2 py-0.5 bg-rose-500 text-white text-[10px] font-black uppercase tracking-wider rounded-md shadow-md">
              {product.discount}% OFF
            </span>
          )}
          {product.price <= 299 && (
            <span className="px-2 py-0.5 bg-amber-400 text-neutral-950 text-[9px] font-black uppercase tracking-wider rounded-md shadow-md flex items-center gap-0.5">
              <Zap className="w-2.5 h-2.5 fill-current" /> Zudio Price
            </span>
          )}
        </div>

        {/* Low Stock Badge */}
        {product.stock > 0 && product.stock <= 5 && (
          <span className="absolute top-2.5 right-11 z-10 px-2 py-0.5 bg-amber-500/90 backdrop-blur-sm text-white text-[9px] font-bold rounded shadow-sm">
            Only {product.stock} left
          </span>
        )}

        {/* Out of Stock Overlay */}
        {product.stock <= 0 && (
          <div className="absolute inset-0 z-20 bg-black/60 backdrop-blur-[2px] flex items-center justify-center">
            <span className="px-3 py-1 bg-white text-neutral-950 text-xs font-black uppercase tracking-widest rounded-lg">
              Out of Stock
            </span>
          </div>
        )}

        {/* Wishlist Button */}
        <button
          onClick={handleWishlistToggle}
          className={`absolute top-2.5 right-2.5 z-10 p-2 rounded-full backdrop-blur-md transition-all duration-200 ${
            inWishlist
              ? 'bg-rose-500 text-white shadow-md scale-110'
              : 'bg-white/85 text-neutral-700 hover:bg-white dark:bg-neutral-900/85 dark:text-neutral-200 dark:hover:bg-neutral-900'
          }`}
          aria-label={inWishlist ? 'Remove from Wishlist' : 'Add to Wishlist'}
        >
          <Heart className={`w-3.5 h-3.5 ${inWishlist ? 'fill-current' : ''}`} />
        </button>

        {/* Main Product Image Links */}
        <Link to={`/product/${product.slug}`} className="block w-full h-full">
          <img
            src={activeImage}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
            loading="lazy"
          />
        </Link>

        {/* Action Overlay Buttons (Quick View & Compare) */}
        <div
          className={`absolute bottom-2.5 inset-x-2.5 z-10 flex gap-2 transition-all duration-300 ${
            isHovered ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2 pointer-events-none'
          }`}
        >
          {onQuickView && (
            <button
              onClick={() => onQuickView(product)}
              className="flex-1 py-2 bg-white/95 dark:bg-neutral-900/95 text-neutral-900 dark:text-white hover:bg-white text-xs font-bold rounded-xl shadow-lg backdrop-blur-sm flex items-center justify-center gap-1.5 transition-colors"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Quick View</span>
            </button>
          )}

          <button
            onClick={handleCompareToggle}
            className={`p-2 rounded-xl shadow-lg backdrop-blur-sm transition-colors text-xs font-bold ${
              comparing
                ? 'bg-indigo-600 text-white'
                : 'bg-white/95 dark:bg-neutral-900/95 text-neutral-700 dark:text-neutral-300 hover:bg-white'
            }`}
            title="Compare Product"
          >
            {comparing ? <Check className="w-3.5 h-3.5" /> : 'VS'}
          </button>
        </div>
      </div>

      {/* Content Details */}
      <div className="p-3.5 flex flex-col flex-1 justify-between">
        <div>
          {/* Category & Fit */}
          <div className="flex items-center justify-between text-[11px] text-neutral-400 mb-1">
            <span className="uppercase font-semibold tracking-wider text-[9px] text-amber-600 dark:text-amber-400 font-bold">
              {product.category === 'tamil-drops' ? 'தமிழ் ஸ்பெஷல்' : product.category}
            </span>
            <span className="font-medium text-neutral-500 text-[10px]">{product.gsm} GSM</span>
          </div>

          {/* Title */}
          <Link
            to={`/product/${product.slug}`}
            className="block text-xs sm:text-sm font-bold text-neutral-900 dark:text-white hover:underline line-clamp-1 font-heading"
          >
            {product.name}
          </Link>

          {/* Rating & Review Count */}
          <div className="flex items-center gap-1.5 mt-1">
            <div className="flex items-center text-amber-400">
              <Star className="w-3 h-3 fill-current" />
            </div>
            <span className="text-[11px] font-bold text-neutral-900 dark:text-white">
              {product.rating}
            </span>
            <span className="text-[10px] text-neutral-400">({product.reviewCount})</span>
          </div>
        </div>

        {/* Pricing & Colors */}
        <div className="mt-2.5 pt-2.5 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-sm sm:text-base font-black text-neutral-900 dark:text-white">
                ₹{product.price}
              </span>
              {product.originalPrice > product.price && (
                <span className="text-[11px] text-neutral-400 line-through">
                  ₹{product.originalPrice}
                </span>
              )}
            </div>

            {/* Interactive Color Swatches */}
            <div className="flex items-center gap-1 mt-1">
              {product.colors.slice(0, 5).map((c, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setSelectedColorIdx(i);
                  }}
                  className={`w-3 h-3 rounded-full border transition-transform ${
                    selectedColorIdx === i ? 'scale-125 border-neutral-900 dark:border-white ring-1 ring-amber-400' : 'border-neutral-300 dark:border-neutral-600'
                  }`}
                  style={{ backgroundColor: c.hex }}
                  title={c.name}
                />
              ))}
              {product.colors.length > 5 && (
                <span className="text-[9px] font-bold text-neutral-400">+{product.colors.length - 5}</span>
              )}
            </div>
          </div>

          {/* Add to Cart Trigger */}
          <div className="relative">
            {showSizeSelector ? (
              <div className="absolute bottom-0 right-0 z-30 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 shadow-2xl rounded-2xl p-2.5 min-w-[140px] animate-scale">
                <p className="text-[9px] font-bold text-neutral-500 uppercase mb-1.5 text-center">
                  Size ({selectedSize})
                </p>
                <div className="grid grid-cols-3 gap-1 mb-2">
                  {product.sizes.map((sz) => (
                    <button
                      key={sz}
                      onClick={() => setSelectedSize(sz)}
                      className={`py-1 text-[11px] font-bold rounded-lg ${
                        selectedSize === sz
                          ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 shadow-sm'
                          : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>
                <button
                  onClick={handleQuickAdd}
                  disabled={isAdding}
                  className="w-full py-1.5 bg-amber-400 hover:bg-amber-300 text-neutral-950 text-[10px] font-black uppercase rounded-lg shadow"
                >
                  {isAdding ? 'Adding...' : 'Add ₹' + product.price}
                </button>
              </div>
            ) : (
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setShowSizeSelector(true);
                }}
                disabled={product.stock <= 0}
                className="p-2 rounded-xl bg-neutral-900 text-white hover:bg-neutral-800 dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-200 transition-colors shadow-sm disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1 text-[11px] font-bold px-2.5"
                title="Add to Cart"
                aria-label="Add to bag"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Add</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
