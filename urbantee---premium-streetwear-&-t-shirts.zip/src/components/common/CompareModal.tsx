import React from 'react';
import { Link } from 'react-router-dom';
import { X, Trash2, ShoppingBag, Star, Layers } from 'lucide-react';
import { useCompare } from '../../context/CompareContext';
import { useCart } from '../../context/CartContext';

export const CompareModal: React.FC = () => {
  const { compareList, isCompareModalOpen, closeCompareModal, removeFromCompare, clearCompare } = useCompare();
  const { addToCart } = useCart();

  if (!isCompareModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative bg-white dark:bg-neutral-900 rounded-3xl max-w-5xl w-full p-6 sm:p-8 shadow-2xl border border-neutral-200 dark:border-neutral-800">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-200 dark:border-neutral-800 mb-6">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-neutral-900 dark:text-white" />
            <h2 className="text-xl font-extrabold text-neutral-900 dark:text-white font-heading">
              Compare T-Shirts ({compareList.length}/4)
            </h2>
          </div>
          <div className="flex items-center gap-2">
            {compareList.length > 0 && (
              <button
                onClick={clearCompare}
                className="text-xs font-semibold text-rose-600 hover:underline px-3 py-1.5"
              >
                Clear All
              </button>
            )}
            <button
              onClick={closeCompareModal}
              className="p-2 text-neutral-400 hover:text-neutral-900 dark:hover:text-white rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {compareList.length === 0 ? (
          <div className="text-center py-12">
            <Layers className="w-12 h-12 mx-auto text-neutral-300 dark:text-neutral-700 mb-3" />
            <h3 className="text-base font-bold text-neutral-900 dark:text-white">No items to compare</h3>
            <p className="text-xs text-neutral-500 mt-1 max-w-xs mx-auto">
              Click the "VS" compare icon on any t-shirt card in the shop to compare fabrics, weights, GSM, and pricing.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr>
                  <th className="p-3 w-32 bg-neutral-50 dark:bg-neutral-800/50 rounded-tl-xl font-bold text-neutral-500">Feature</th>
                  {compareList.map((p) => (
                    <th key={p.id} className="p-3 min-w-[200px] border-l border-neutral-100 dark:border-neutral-800 text-center align-top">
                      <div className="relative group">
                        <button
                          onClick={() => removeFromCompare(p.id)}
                          className="absolute -top-2 -right-2 p-1 bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-200 rounded-full hover:bg-rose-500 hover:text-white transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                        <img src={p.images[0]} alt={p.name} className="w-28 h-36 object-cover mx-auto rounded-xl shadow-sm mb-2" />
                        <Link
                          to={`/product/${p.slug}`}
                          onClick={closeCompareModal}
                          className="font-bold text-neutral-900 dark:text-white line-clamp-2 hover:underline"
                        >
                          {p.name}
                        </Link>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200 dark:divide-neutral-800">
                <tr>
                  <td className="p-3 font-bold text-neutral-500">Price</td>
                  {compareList.map((p) => (
                    <td key={p.id} className="p-3 border-l border-neutral-100 dark:border-neutral-800 text-center">
                      <span className="text-sm font-black text-neutral-900 dark:text-white">₹{p.price}</span>
                      {p.originalPrice > p.price && (
                        <span className="text-[10px] text-neutral-400 line-through block">₹{p.originalPrice}</span>
                      )}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-3 font-bold text-neutral-500">Fabric & GSM</td>
                  {compareList.map((p) => (
                    <td key={p.id} className="p-3 border-l border-neutral-100 dark:border-neutral-800 text-center font-medium">
                      <span className="block font-bold">{p.gsm} GSM</span>
                      <span className="text-neutral-500 text-[11px]">{p.fabric}</span>
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-3 font-bold text-neutral-500">Fit Profile</td>
                  {compareList.map((p) => (
                    <td key={p.id} className="p-3 border-l border-neutral-100 dark:border-neutral-800 text-center">
                      <span className="px-2 py-0.5 rounded-full bg-neutral-100 dark:bg-neutral-800 text-[11px] font-semibold">
                        {p.fit}
                      </span>
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-3 font-bold text-neutral-500">Rating</td>
                  {compareList.map((p) => (
                    <td key={p.id} className="p-3 border-l border-neutral-100 dark:border-neutral-800 text-center">
                      <div className="flex items-center justify-center gap-1 font-bold text-amber-500">
                        <Star className="w-3.5 h-3.5 fill-current" />
                        <span>{p.rating}</span>
                        <span className="text-neutral-400 text-[10px]">({p.reviewCount})</span>
                      </div>
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-3 font-bold text-neutral-500">Colors Available</td>
                  {compareList.map((p) => (
                    <td key={p.id} className="p-3 border-l border-neutral-100 dark:border-neutral-800 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {p.colors.map((c, i) => (
                          <span key={i} className="w-3 h-3 rounded-full border border-neutral-300" style={{ backgroundColor: c.hex }} title={c.name} />
                        ))}
                      </div>
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-3 font-bold text-neutral-500">Action</td>
                  {compareList.map((p) => (
                    <td key={p.id} className="p-3 border-l border-neutral-100 dark:border-neutral-800 text-center">
                      <button
                        onClick={() => {
                          addToCart(p.id, p.sizes[0] || 'M', p.colors[0]?.name || 'Default', 1);
                          closeCompareModal();
                        }}
                        className="w-full py-2 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1 hover:opacity-90"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                        <span>Add to Bag</span>
                      </button>
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
