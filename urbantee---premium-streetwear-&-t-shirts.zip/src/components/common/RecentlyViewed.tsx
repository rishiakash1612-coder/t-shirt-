import React, { useState, useEffect } from 'react';
import { Product } from '../../types';
import { ProductCard } from './ProductCard';
import { History } from 'lucide-react';

interface RecentlyViewedProps {
  currentProductId?: string;
  onQuickView?: (product: Product) => void;
}

export const RecentlyViewed: React.FC<RecentlyViewedProps> = ({ currentProductId, onQuickView }) => {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    try {
      const stored = localStorage.getItem('urbantee_recently_viewed');
      if (stored) {
        const parsed: Product[] = JSON.parse(stored);
        const filtered = parsed.filter((p) => p.id !== currentProductId);
        setProducts(filtered.slice(0, 4));
      }
    } catch {
      // Ignore
    }
  }, [currentProductId]);

  if (products.length === 0) return null;

  return (
    <section className="py-12 border-t border-neutral-200 dark:border-neutral-800">
      <div className="flex items-center gap-2 mb-6">
        <History className="w-5 h-5 text-neutral-900 dark:text-white" />
        <h2 className="text-xl font-extrabold text-neutral-900 dark:text-white font-heading">
          Recently Viewed T-Shirts
        </h2>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} onQuickView={onQuickView} />
        ))}
      </div>
    </section>
  );
};
