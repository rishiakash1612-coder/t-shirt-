import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, ArrowRight, ShieldCheck, Truck, RefreshCw, Lock, Instagram, Facebook, Youtube, Sparkles } from 'lucide-react';
import { useToast } from '../../context/ToastContext';

export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const { showToast } = useToast();

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      showToast('Please enter a valid email address', 'error');
      return;
    }
    setSubscribed(true);
    showToast('Subscribed! Use code FIRSTORDER for 15% off 🎉', 'success');
  };

  return (
    <footer className="bg-neutral-900 text-neutral-300 border-t border-neutral-800">
      
      {/* Value Proposition Bar */}
      <div className="border-b border-neutral-800/80 bg-neutral-950/50 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 text-center sm:text-left">
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center shrink-0 text-white">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-white font-heading">Free Express Shipping</p>
              <p className="text-xs text-neutral-400">On all orders above ₹999 across India</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center shrink-0 text-white">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-white font-heading">7-Day Easy Returns</p>
              <p className="text-xs text-neutral-400">Hassle-free doorstep pickup policy</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center shrink-0 text-white">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-white font-heading">240 GSM Heavyweight</p>
              <p className="text-xs text-neutral-400">100% combed long-staple cotton</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center shrink-0 text-white">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-white font-heading">100% Secure Payments</p>
              <p className="text-xs text-neutral-400">UPI, Cards, NetBanking & COD</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          
          {/* Brand Info & Newsletter */}
          <div className="lg:col-span-2 space-y-4">
            <Link to="/" className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-white text-neutral-950 flex items-center justify-center font-black text-lg tracking-tighter font-heading">
                UT
              </span>
              <span className="text-2xl font-black tracking-tight text-white font-heading">
                URBAN<span className="text-neutral-500 font-light">TEE</span>
              </span>
            </Link>
            <p className="text-sm text-neutral-400 max-w-sm leading-relaxed">
              UrbanTee is India's leading streetwear label creating high-density graphic, acid washed, and oversized heavyweight t-shirts engineered for modern attitude and timeless longevity.
            </p>

            {/* Newsletter Subscription */}
            <div className="pt-2">
              <p className="text-xs font-semibold uppercase tracking-wider text-white mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Join the Club & Get 10% OFF
              </p>
              {subscribed ? (
                <div className="p-3 rounded-xl bg-neutral-800 border border-neutral-700 text-xs text-emerald-400 font-medium">
                  🎉 Welcome to the UrbanTee family! Use promo code <span className="font-mono font-bold text-white">WELCOME10</span> at checkout.
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex gap-2 max-w-md">
                  <div className="relative flex-1">
                    <Mail className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email address"
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-neutral-800 border border-neutral-700 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-white transition-colors"
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-2.5 bg-white text-neutral-950 hover:bg-neutral-200 font-bold text-xs uppercase tracking-wider rounded-xl flex items-center gap-1 transition-colors"
                  >
                    <span>Join</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Shop Column */}
          <div>
            <p className="text-sm font-bold text-white uppercase tracking-wider mb-4 font-heading">Shop</p>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/shop?gender=men" className="hover:text-white transition-colors">Men's T-Shirts</Link>
              </li>
              <li>
                <Link to="/shop?gender=women" className="hover:text-white transition-colors">Women's T-Shirts</Link>
              </li>
              <li>
                <Link to="/category/oversized" className="hover:text-white transition-colors">Oversized Fits</Link>
              </li>
              <li>
                <Link to="/category/graphic" className="hover:text-white transition-colors">Graphic Tees</Link>
              </li>
              <li>
                <Link to="/category/plain" className="hover:text-white transition-colors">Plain Basics</Link>
              </li>
              <li>
                <Link to="/category/printed" className="hover:text-white transition-colors">Printed Styles</Link>
              </li>
              <li>
                <Link to="/new-arrivals" className="hover:text-white transition-colors">New Arrivals</Link>
              </li>
              <li>
                <Link to="/sale" className="text-rose-400 hover:text-rose-300 font-medium transition-colors">Sale & Offers</Link>
              </li>
            </ul>
          </div>

          {/* Customer Help Column */}
          <div>
            <p className="text-sm font-bold text-white uppercase tracking-wider mb-4 font-heading">Customer Care</p>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/contact" className="hover:text-white transition-colors">Contact Us</Link>
              </li>
              <li>
                <Link to="/faq" className="hover:text-white transition-colors">FAQs</Link>
              </li>
              <li>
                <Link to="/size-guide" className="hover:text-white transition-colors">Size Guide & Chart</Link>
              </li>
              <li>
                <Link to="/shipping-info" className="hover:text-white transition-colors">Shipping & Delivery</Link>
              </li>
              <li>
                <Link to="/returns-refunds" className="hover:text-white transition-colors">Returns & Refunds</Link>
              </li>
              <li>
                <Link to="/account?tab=orders" className="hover:text-white transition-colors">Track Your Order</Link>
              </li>
            </ul>
          </div>

          {/* Legal & Social Column */}
          <div>
            <p className="text-sm font-bold text-white uppercase tracking-wider mb-4 font-heading">Company & Legal</p>
            <ul className="space-y-2.5 text-sm mb-6">
              <li>
                <Link to="/about" className="hover:text-white transition-colors">About Us</Link>
              </li>
              <li>
                <Link to="/privacy-policy" className="hover:text-white transition-colors">Privacy Policy</Link>
              </li>
              <li>
                <Link to="/terms" className="hover:text-white transition-colors">Terms & Conditions</Link>
              </li>
            </ul>

            <p className="text-xs font-bold text-white uppercase tracking-wider mb-3 font-heading">Follow UrbanTee</p>
            <div className="flex items-center gap-3 text-neutral-400">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-neutral-800 hover:bg-neutral-700 hover:text-white flex items-center justify-center transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-neutral-800 hover:bg-neutral-700 hover:text-white flex items-center justify-center transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-neutral-800 hover:bg-neutral-700 hover:text-white flex items-center justify-center transition-colors"
                aria-label="YouTube"
              >
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500">
          <p>© {new Date().getFullYear()} UrbanTee Apparel Private Limited. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span>UPI • VISA • MASTERCARD • RUPAY • NET BANKING • COD</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
