import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import {
  Search,
  Heart,
  ShoppingBag,
  User as UserIcon,
  Menu,
  X,
  Sun,
  Moon,
  Shield,
  LogOut,
  Package,
  Layers,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { useTheme } from '../../context/ThemeContext';
import { useCompare } from '../../context/CompareContext';
import api from '../../services/api';
import { Product } from '../../types';

export const Navbar: React.FC = () => {
  const { user, logout, loginDemoAdmin, loginDemoUser } = useAuth();
  const { itemCount, openCartDrawer } = useCart();
  const { wishlistIds } = useWishlist();
  const { theme, toggleTheme } = useTheme();
  const { compareList, openCompareModal } = useCompare();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const searchInputRef = useRef<HTMLInputElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const location = useLocation();

  // Close menus on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
    setIsUserMenuOpen(false);
    setIsSearchOpen(false);
  }, [location]);

  // Click outside to close user menu
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Search autocomplete debounce
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }
    const timer = setTimeout(async () => {
      try {
        setIsSearching(true);
        const res = await api.get(`/products?search=${encodeURIComponent(searchQuery)}&limit=5`);
        if (res.data.success) {
          setSearchResults(res.data.products);
        }
      } catch {
        // Ignore
      } finally {
        setIsSearching(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
      setIsSearchOpen(false);
      setSearchQuery('');
    }
  };

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'TN Drops (தமிழ்)', path: '/shop?category=tamil-drops' },
    { name: 'Under ₹299', path: '/shop?category=under-299' },
    { name: "Men's", path: '/shop?gender=men' },
    { name: "Women's", path: '/shop?gender=women' },
    { name: 'Oversized', path: '/shop?category=oversized' },
    { name: 'All Under ₹699', path: '/shop' },
    { name: 'Deals & Coupons', path: '/sale', highlight: true }
  ];

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-neutral-900/95 backdrop-blur-md border-b border-neutral-200/80 dark:border-neutral-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          
          {/* Mobile Menu Button */}
          <div className="flex items-center lg:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 -ml-2 rounded-lg text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800"
              aria-label="Toggle Navigation Menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Logo */}
          <div className="flex items-center gap-2">
            <Link to="/" className="flex items-center gap-2 group">
              <span className="w-8 h-8 rounded-lg bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 flex items-center justify-center font-extrabold text-lg tracking-tighter group-hover:scale-105 transition-transform font-heading">
                UT
              </span>
              <span className="text-2xl font-black tracking-tight text-neutral-900 dark:text-white font-heading">
                URBAN<span className="text-neutral-500 font-light">TEE</span>
              </span>
            </Link>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2">
            {navLinks.map((link) => {
              const isActive = location.pathname + location.search === link.path;
              return (
                <Link
                  key={link.name}
                  to={link.path}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'text-neutral-950 dark:text-white font-semibold bg-neutral-100 dark:bg-neutral-800'
                      : link.highlight
                      ? 'text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 font-semibold'
                      : 'text-neutral-600 dark:text-neutral-300 hover:text-neutral-950 dark:hover:text-white hover:bg-neutral-50 dark:hover:bg-neutral-800/60'
                  }`}
                >
                  {link.name}
                </Link>
              );
            })}
          </nav>

          {/* Right Action Icons */}
          <div className="flex items-center space-x-1 sm:space-x-2">
            
            {/* Compare Badge / Button */}
            {compareList.length > 0 && (
              <button
                onClick={openCompareModal}
                className="relative p-2 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full transition-colors hidden sm:flex items-center gap-1.5 text-xs font-semibold"
                title="Compare Products"
              >
                <Layers className="w-5 h-5 text-neutral-800 dark:text-neutral-200" />
                <span className="bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 px-1.5 py-0.5 rounded-full text-[10px]">
                  {compareList.length}
                </span>
              </button>
            )}

            {/* Search Trigger */}
            <button
              onClick={() => {
                setIsSearchOpen(true);
                setTimeout(() => searchInputRef.current?.focus(), 50);
              }}
              className="p-2 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full transition-colors"
              aria-label="Search Catalog"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Dark/Light Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full transition-colors"
              aria-label="Toggle Theme"
            >
              {theme === 'dark' ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5" />}
            </button>

            {/* Wishlist Link */}
            <Link
              to="/wishlist"
              className="relative p-2 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full transition-colors"
              aria-label="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlistIds.length > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                  {wishlistIds.length}
                </span>
              )}
            </Link>

            {/* Cart Drawer Trigger */}
            <button
              onClick={openCartDrawer}
              className="relative p-2 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full transition-colors"
              aria-label="Shopping Bag"
            >
              <ShoppingBag className="w-5 h-5" />
              {itemCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 text-[10px] font-bold rounded-full flex items-center justify-center animate-scale">
                  {itemCount}
                </span>
              )}
            </button>

            {/* User Account / Auth Dropdown */}
            <div className="relative" ref={userMenuRef}>
              <button
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="flex items-center gap-1.5 p-1.5 sm:px-3 sm:py-1.5 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full sm:rounded-lg text-sm font-medium transition-colors"
                aria-label="Account Menu"
              >
                <div className="w-7 h-7 rounded-full bg-neutral-200 dark:bg-neutral-700 flex items-center justify-center text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase">
                  {user ? user.name.charAt(0) : <UserIcon className="w-4 h-4" />}
                </div>
                <span className="hidden md:inline max-w-[100px] truncate">
                  {user ? user.name.split(' ')[0] : 'Account'}
                </span>
              </button>

              {/* User Dropdown Content */}
              {isUserMenuOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-neutral-900 rounded-2xl shadow-2xl border border-neutral-200 dark:border-neutral-800 py-2 z-50 animate-fade-in">
                  {user ? (
                    <>
                      <div className="px-4 py-3 border-b border-neutral-100 dark:border-neutral-800">
                        <p className="text-xs text-neutral-500 dark:text-neutral-400">Signed in as</p>
                        <p className="text-sm font-bold text-neutral-900 dark:text-white truncate">{user.name}</p>
                        <p className="text-xs text-neutral-500 truncate">{user.email}</p>
                        {user.role === 'ADMIN' && (
                          <span className="inline-flex items-center gap-1 mt-1.5 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                            <Shield className="w-3 h-3" /> Admin Account
                          </span>
                        )}
                      </div>

                      {user.role === 'ADMIN' && (
                        <Link
                          to="/admin"
                          className="flex items-center gap-2.5 px-4 py-2.5 text-sm font-semibold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/30"
                        >
                          <Shield className="w-4 h-4" />
                          Admin Dashboard
                        </Link>
                      )}

                      <Link
                        to="/account"
                        className="flex items-center gap-2.5 px-4 py-2.5 text-sm text-neutral-700 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-800"
                      >
                        <UserIcon className="w-4 h-4 text-neutral-400" />
                        My Profile
                      </Link>

                      <Link
                        to="/account?tab=orders"
                        className="flex items-center gap-2.5 px-4 py-2.5 text-sm text-neutral-700 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-800"
                      >
                        <Package className="w-4 h-4 text-neutral-400" />
                        My Orders
                      </Link>

                      <Link
                        to="/wishlist"
                        className="flex items-center gap-2.5 px-4 py-2.5 text-sm text-neutral-700 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-800"
                      >
                        <Heart className="w-4 h-4 text-neutral-400" />
                        Wishlist ({wishlistIds.length})
                      </Link>

                      <div className="border-t border-neutral-100 dark:border-neutral-800 my-1" />

                      <button
                        onClick={logout}
                        className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 font-medium text-left"
                      >
                        <LogOut className="w-4 h-4" />
                        Sign Out
                      </button>
                    </>
                  ) : (
                    <>
                      <div className="px-4 py-3 border-b border-neutral-100 dark:border-neutral-800 text-center">
                        <p className="text-sm font-semibold text-neutral-900 dark:text-white">Welcome to UrbanTee</p>
                        <p className="text-xs text-neutral-500 mt-0.5">Sign in to track orders & save wishlist</p>
                        <div className="mt-3 flex gap-2">
                          <Link
                            to="/login"
                            className="flex-1 py-2 px-3 text-xs font-semibold rounded-lg bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 text-center hover:opacity-90 transition-opacity"
                          >
                            Sign In
                          </Link>
                          <Link
                            to="/register"
                            className="flex-1 py-2 px-3 text-xs font-semibold rounded-lg border border-neutral-200 dark:border-neutral-700 text-neutral-800 dark:text-neutral-200 text-center hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors"
                          >
                            Register
                          </Link>
                        </div>
                      </div>

                      <div className="p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-b-2xl">
                        <p className="text-[11px] font-medium text-neutral-500 uppercase tracking-wider mb-2 flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-amber-500" /> Quick Demo Switch:
                        </p>
                        <div className="flex flex-col gap-1.5">
                          <button
                            onClick={loginDemoAdmin}
                            className="w-full py-1.5 px-2.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-md text-left flex items-center justify-between"
                          >
                            <span>1-Click Admin Access</span>
                            <Shield className="w-3 h-3" />
                          </button>
                          <button
                            onClick={loginDemoUser}
                            className="w-full py-1.5 px-2.5 text-xs font-semibold bg-neutral-200 dark:bg-neutral-700 hover:bg-neutral-300 dark:hover:bg-neutral-600 text-neutral-900 dark:text-neutral-100 rounded-md text-left flex items-center justify-between"
                          >
                            <span>1-Click Customer Access</span>
                            <UserIcon className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Search Modal / Popover Overlay */}
      {isSearchOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-start justify-center pt-16 px-4 animate-fade-in">
          <div className="bg-white dark:bg-neutral-900 w-full max-w-2xl rounded-2xl shadow-2xl border border-neutral-200 dark:border-neutral-800 overflow-hidden">
            <form onSubmit={handleSearchSubmit} className="relative flex items-center px-4 border-b border-neutral-200 dark:border-neutral-800">
              <Search className="w-5 h-5 text-neutral-400 mr-3 shrink-0" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by t-shirt style, anime, fit, graphic, color..."
                className="w-full py-4 text-base bg-transparent text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="p-1 text-neutral-400 hover:text-neutral-600 mr-2"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
              <button
                type="button"
                onClick={() => setIsSearchOpen(false)}
                className="px-2.5 py-1 text-xs font-semibold text-neutral-500 hover:text-neutral-900 dark:hover:text-white bg-neutral-100 dark:bg-neutral-800 rounded-md"
              >
                ESC
              </button>
            </form>

            {/* Quick Suggestions & Results */}
            <div className="max-h-96 overflow-y-auto p-4">
              {isSearching ? (
                <div className="py-8 text-center text-sm text-neutral-500">Searching catalog...</div>
              ) : searchResults.length > 0 ? (
                <div>
                  <p className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-3">Products</p>
                  <div className="space-y-2">
                    {searchResults.map((prod) => (
                      <Link
                        key={prod.id}
                        to={`/product/${prod.slug}`}
                        onClick={() => setIsSearchOpen(false)}
                        className="flex items-center gap-3 p-2 rounded-xl hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                      >
                        <img
                          src={prod.images[0]}
                          alt={prod.name}
                          className="w-12 h-14 object-cover rounded-lg bg-neutral-100"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-neutral-900 dark:text-white truncate">{prod.name}</p>
                          <p className="text-xs text-neutral-500 capitalize">{prod.category} • {prod.fit}</p>
                        </div>
                        <div className="text-right">
                          <span className="text-sm font-bold text-neutral-900 dark:text-white">₹{prod.price}</span>
                          {prod.originalPrice > prod.price && (
                            <span className="text-xs text-neutral-400 line-through block">₹{prod.originalPrice}</span>
                          )}
                        </div>
                      </Link>
                    ))}
                  </div>
                  <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-neutral-800 text-center">
                    <button
                      onClick={handleSearchSubmit}
                      className="text-xs font-semibold text-neutral-900 dark:text-white hover:underline"
                    >
                      View all results for "{searchQuery}" →
                    </button>
                  </div>
                </div>
              ) : searchQuery ? (
                <div className="py-8 text-center">
                  <p className="text-sm font-medium text-neutral-600 dark:text-neutral-400">No t-shirts found for "{searchQuery}"</p>
                  <p className="text-xs text-neutral-500 mt-1">Try searching for "Oversized", "Cyberpunk", "Acid Wash", or "Supima"</p>
                </div>
              ) : (
                <div>
                  <p className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">Popular Searches</p>
                  <div className="flex flex-wrap gap-2">
                    {['Oversized', 'Acid Wash', 'Anime Samurai', '240 GSM', 'Supima Plain', 'Heavyweight', 'Streetwear'].map((tag) => (
                      <button
                        key={tag}
                        onClick={() => {
                          setSearchQuery(tag);
                        }}
                        className="px-3 py-1.5 text-xs font-medium bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 rounded-full hover:bg-neutral-200 dark:hover:bg-neutral-700"
                      >
                        {tag}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-40 bg-black/50 backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)}>
          <div
            className="w-4/5 max-w-sm h-full bg-white dark:bg-neutral-900 shadow-2xl p-6 overflow-y-auto flex flex-col justify-between"
            onClick={(e) => e.stopPropagation()}
          >
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-neutral-100 dark:border-neutral-800 mb-4">
                <Link to="/" className="flex items-center gap-2">
                  <span className="w-7 h-7 rounded-lg bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 flex items-center justify-center font-bold text-sm">
                    UT
                  </span>
                  <span className="text-xl font-extrabold text-neutral-900 dark:text-white font-heading">
                    URBAN<span className="text-neutral-500 font-normal">TEE</span>
                  </span>
                </Link>
                <button onClick={() => setIsMobileMenuOpen(false)} className="p-1 text-neutral-500">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <nav className="space-y-1">
                {navLinks.map((link) => (
                  <Link
                    key={link.name}
                    to={link.path}
                    className={`block px-3 py-2.5 rounded-xl text-base font-semibold ${
                      link.highlight
                        ? 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40'
                        : 'text-neutral-800 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                    }`}
                  >
                    {link.name}
                  </Link>
                ))}
              </nav>

              <div className="mt-6 pt-4 border-t border-neutral-100 dark:border-neutral-800 space-y-1">
                <Link
                  to="/wishlist"
                  className="flex items-center justify-between px-3 py-2 rounded-xl text-sm font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800"
                >
                  <span className="flex items-center gap-2">
                    <Heart className="w-4 h-4 text-rose-500" /> My Wishlist
                  </span>
                  <span className="text-xs bg-neutral-200 dark:bg-neutral-700 px-2 py-0.5 rounded-full">
                    {wishlistIds.length}
                  </span>
                </Link>

                <Link
                  to="/about"
                  className="block px-3 py-2 rounded-xl text-sm font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800"
                >
                  About UrbanTee
                </Link>
                <Link
                  to="/contact"
                  className="block px-3 py-2 rounded-xl text-sm font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800"
                >
                  Contact & Support
                </Link>
                <Link
                  to="/size-guide"
                  className="block px-3 py-2 rounded-xl text-sm font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800"
                >
                  Size Guide & Fit Chart
                </Link>
              </div>
            </div>

            {/* Bottom Auth button */}
            <div className="pt-6 border-t border-neutral-100 dark:border-neutral-800">
              {user ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-3 p-2 bg-neutral-100 dark:bg-neutral-800 rounded-xl">
                    <div className="w-9 h-9 rounded-full bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 flex items-center justify-center font-bold text-sm">
                      {user.name.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold truncate text-neutral-900 dark:text-white">{user.name}</p>
                      <p className="text-xs text-neutral-500 truncate">{user.email}</p>
                    </div>
                  </div>
                  {user.role === 'ADMIN' && (
                    <Link
                      to="/admin"
                      className="block w-full text-center py-2.5 text-xs font-bold rounded-xl bg-indigo-600 text-white"
                    >
                      Admin Dashboard
                    </Link>
                  )}
                  <button
                    onClick={logout}
                    className="w-full text-center py-2 text-xs font-semibold text-rose-600 hover:underline"
                  >
                    Sign Out
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <Link
                    to="/login"
                    className="block w-full py-2.5 text-center text-sm font-semibold rounded-xl bg-neutral-900 text-white dark:bg-white dark:text-neutral-900"
                  >
                    Sign In
                  </Link>
                  <button
                    onClick={loginDemoAdmin}
                    className="block w-full py-2 text-center text-xs font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl"
                  >
                    Switch to Admin Mode
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
