import React, { useState } from 'react';
import { X, Sparkles, MapPin, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';

export const TopBanner: React.FC = () => {
  const [visible, setVisible] = useState(true);

  if (!visible) return null;

  return (
    <div className="bg-neutral-950 text-white text-xs py-2 px-4 relative z-40 transition-all border-b border-neutral-800">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex-1 text-center flex items-center justify-center gap-2 flex-wrap sm:flex-nowrap">
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-400 text-neutral-950 font-black text-[10px] uppercase tracking-wider">
            <Zap className="w-3 h-3 fill-current" /> ALL UNDER ₹699
          </span>
          <span>
            🔥 <strong>Zudio-Style Prices from ₹199</strong> • Pure Tirupur Combed Cotton • Use code <span className="underline font-mono font-bold text-amber-400 tracking-wider">VANAKKAM50</span> for ₹50 OFF!
          </span>
          <span className="hidden md:inline-flex items-center gap-1 text-neutral-300 ml-2">
            <MapPin className="w-3 h-3 text-rose-400" /> Fast 24-hr Delivery across Tamil Nadu
          </span>
          <Link to="/shop?category=tamil-drops" className="ml-2 font-bold text-amber-400 underline hover:text-amber-300 hidden sm:inline">
            TN Drops →
          </Link>
        </div>
        <button
          onClick={() => setVisible(false)}
          className="text-neutral-400 hover:text-white p-1 ml-2 shrink-0"
          aria-label="Dismiss banner"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
