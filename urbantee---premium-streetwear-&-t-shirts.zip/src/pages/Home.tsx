import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  Sparkles,
  Flame,
  Clock,
  ShieldCheck,
  Truck,
  RefreshCw,
  Star,
  CheckCircle2,
  Tag,
  Zap,
  MapPin,
  Heart
} from 'lucide-react';
import api from '../services/api';
import { Product, Category } from '../types';
import { ProductCard } from '../components/common/ProductCard';
import { QuickViewModal } from '../components/common/QuickViewModal';
import { RecentlyViewed } from '../components/common/RecentlyViewed';

export const Home: React.FC = () => {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [bestSellers, setBestSellers] = useState<Product[]>([]);
  const [newArrivals, setNewArrivals] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [activeTab, setActiveTab] = useState<'trending' | 'bestsellers' | 'new' | 'under299'>('trending');
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // Countdown timer for Tamil Nadu Flash Drop
  const [timeLeft, setTimeLeft] = useState({ hours: 11, minutes: 42, seconds: 15 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return { hours: 24, minutes: 0, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [prodRes, catRes] = await Promise.all([
          api.get('/products?limit=28'),
          api.get('/categories')
        ]);

        if (prodRes.data.success) {
          const all: Product[] = prodRes.data.products;
          setFeaturedProducts(all.filter((p) => p.featured || p.category === 'tamil-drops').slice(0, 8));
          setBestSellers(all.filter((p) => p.bestSeller).slice(0, 8));
          setNewArrivals(all.filter((p) => p.newArrival).slice(0, 8));
        }

        if (catRes.data.success) {
          setCategories(catRes.data.categories);
        }
      } catch (err) {
        console.error('Failed to load home data', err);
      }
    };
    fetchData();
  }, []);

  return (
    <div className="space-y-16 sm:space-y-24">
      
      {/* 1. HERO SECTION - TAMIL NADU & ZUDIO UNDER 699 FOCUS */}
      <section className="relative overflow-hidden bg-neutral-950 text-white rounded-3xl mx-4 sm:mx-6 lg:mx-8 mt-4 border border-neutral-800">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=2000&q=80"
            alt="Tamil Nadu Streetwear Hero"
            className="w-full h-full object-cover opacity-30 filter grayscale contrast-125"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-neutral-950 via-neutral-950/85 to-transparent" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-12 lg:px-16 py-16 sm:py-28 lg:py-36">
          <div className="max-w-2xl space-y-6">
            
            {/* Badges */}
            <div className="flex flex-wrap items-center gap-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400 text-neutral-950 text-xs font-black tracking-wider uppercase shadow-lg">
                <Zap className="w-3.5 h-3.5 fill-current" />
                <span>ALL UNDER ₹699 • ZUDIO PRICES</span>
              </div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-bold text-amber-300">
                <MapPin className="w-3 h-3 text-rose-400" />
                <span>Made in Tirupur for Tamil Nadu</span>
              </div>
            </div>

            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight leading-none uppercase font-heading text-white">
              வேற லெவல் <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-200 to-white">
                STREETWEAR.
              </span>
            </h1>

            <p className="text-base sm:text-lg text-neutral-300 font-normal leading-relaxed max-w-lg">
              Pure 100% Tirupur combed cotton tees engineered for Tamil Nadu climate. Zero sweat, maximum airflow, vibrant colors, and unbeatable prices starting from <strong>₹199 to ₹699</strong>.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <Link
                to="/shop?category=tamil-drops"
                className="px-8 py-4 bg-amber-400 hover:bg-amber-300 text-neutral-950 font-black text-xs uppercase tracking-widest rounded-xl transition-all shadow-xl hover:scale-105"
              >
                EXPLORE TN DROPS (ரூ. 299)
              </Link>
              <Link
                to="/shop?category=under-299"
                className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white border border-white/20 font-extrabold text-xs uppercase tracking-widest rounded-xl transition-all hover:scale-105 backdrop-blur-sm"
              >
                UNDER ₹299 DEALS
              </Link>
              <Link
                to="/shop"
                className="px-4 py-4 text-neutral-300 hover:text-white font-bold text-xs uppercase tracking-wider flex items-center gap-1.5"
              >
                <span>All Under ₹699</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            {/* Quick value banner */}
            <div className="pt-6 border-t border-white/10 grid grid-cols-3 gap-4 text-neutral-300">
              <div>
                <p className="text-xl sm:text-2xl font-black text-amber-400 font-heading">₹199 - ₹699</p>
                <p className="text-xs text-neutral-400">Zudio Match Pricing</p>
              </div>
              <div>
                <p className="text-xl sm:text-2xl font-black text-white font-heading">100% Pure</p>
                <p className="text-xs text-neutral-400">Tirupur Combed Cotton</p>
              </div>
              <div>
                <p className="text-xl sm:text-2xl font-black text-emerald-400 font-heading">24-48 Hrs</p>
                <p className="text-xs text-neutral-400">Express TN Delivery</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. PRICE BRACKET QUICK STRIP (Zudio Style Under ₹699) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <Link
            to="/shop?maxPrice=249"
            className="p-5 rounded-2xl bg-gradient-to-br from-amber-500/10 to-orange-500/10 border border-amber-300 dark:border-amber-900/50 hover:shadow-lg transition-all group"
          >
            <span className="text-[10px] font-black uppercase text-amber-600 dark:text-amber-400 tracking-wider">Crazy Deals</span>
            <h3 className="text-xl font-black text-neutral-900 dark:text-white font-heading mt-1 group-hover:translate-x-1 transition-transform">
              Under ₹249 →
            </h3>
            <p className="text-xs text-neutral-500 mt-1">Daily basic tees & packs</p>
          </Link>

          <Link
            to="/shop?category=under-299"
            className="p-5 rounded-2xl bg-gradient-to-br from-rose-500/10 to-pink-500/10 border border-rose-300 dark:border-rose-900/50 hover:shadow-lg transition-all group"
          >
            <span className="text-[10px] font-black uppercase text-rose-600 dark:text-rose-400 tracking-wider">Zudio Price</span>
            <h3 className="text-xl font-black text-neutral-900 dark:text-white font-heading mt-1 group-hover:translate-x-1 transition-transform">
              Under ₹299 →
            </h3>
            <p className="text-xs text-neutral-500 mt-1">Graphic & pocket cotton tees</p>
          </Link>

          <Link
            to="/shop?maxPrice=499"
            className="p-5 rounded-2xl bg-gradient-to-br from-indigo-500/10 to-blue-500/10 border border-indigo-300 dark:border-indigo-900/50 hover:shadow-lg transition-all group"
          >
            <span className="text-[10px] font-black uppercase text-indigo-600 dark:text-indigo-400 tracking-wider">Best Value</span>
            <h3 className="text-xl font-black text-neutral-900 dark:text-white font-heading mt-1 group-hover:translate-x-1 transition-transform">
              Under ₹499 →
            </h3>
            <p className="text-xs text-neutral-500 mt-1">Oversized & Tamil culture drops</p>
          </Link>

          <Link
            to="/shop?maxPrice=699"
            className="p-5 rounded-2xl bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-300 dark:border-emerald-900/50 hover:shadow-lg transition-all group"
          >
            <span className="text-[10px] font-black uppercase text-emerald-600 dark:text-emerald-400 tracking-wider">Top Tier</span>
            <h3 className="text-xl font-black text-neutral-900 dark:text-white font-heading mt-1 group-hover:translate-x-1 transition-transform">
              Under ₹699 →
            </h3>
            <p className="text-xs text-neutral-500 mt-1">Acid-washed & heavy 220 GSM</p>
          </Link>
        </div>
      </section>

      {/* 3. CATEGORIES GRID */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-neutral-500">Tamil Nadu Fashion</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white font-heading mt-1">
              Curated Collections Under ₹699
            </h2>
          </div>
          <Link
            to="/shop"
            className="text-xs font-bold text-neutral-900 dark:text-white hover:underline flex items-center gap-1 mt-2 sm:mt-0"
          >
            <span>View All Collections</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((cat) => (
            <Link
              key={cat.id}
              to={`/shop?category=${cat.slug}`}
              className="group relative rounded-2xl overflow-hidden aspect-[4/5] bg-neutral-100 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-800 flex flex-col justify-end p-4 transition-all duration-300 hover:shadow-xl"
            >
              <img
                src={cat.image}
                alt={cat.name}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/90 via-neutral-950/30 to-transparent" />
              <div className="relative z-10">
                <h3 className="text-xs sm:text-sm font-bold text-white font-heading group-hover:text-amber-400 transition-colors">
                  {cat.name}
                </h3>
                <span className="text-[10px] text-neutral-300 font-medium mt-0.5 inline-block">
                  Under ₹699
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* 4. PRODUCT TABS (Trending Tamil Drops, Bestsellers, Under ₹299, New Arrivals) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 border-b border-neutral-200 dark:border-neutral-800 pb-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-neutral-500">Fast Fashion Catalog</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white font-heading mt-1">
              Explore T-Shirts
            </h2>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0">
            <button
              onClick={() => setActiveTab('trending')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'trending'
                  ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 shadow-md'
                  : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200'
              }`}
            >
              🔥 Namma TN Drops
            </button>
            <button
              onClick={() => setActiveTab('under299')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'under299'
                  ? 'bg-amber-400 text-neutral-950 font-black shadow-md'
                  : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200'
              }`}
            >
              ⚡ Under ₹299 (Zudio Special)
            </button>
            <button
              onClick={() => setActiveTab('bestsellers')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'bestsellers'
                  ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 shadow-md'
                  : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200'
              }`}
            >
              ★ Top Bestsellers
            </button>
            <button
              onClick={() => setActiveTab('new')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'new'
                  ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 shadow-md'
                  : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200'
              }`}
            >
              ✨ Fresh In
            </button>
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {(activeTab === 'trending'
            ? featuredProducts
            : activeTab === 'under299'
            ? featuredProducts.filter((p) => p.price <= 299).concat(bestSellers.filter((p) => p.price <= 299)).slice(0, 8)
            : activeTab === 'bestsellers'
            ? bestSellers
            : newArrivals
          ).map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onQuickView={(p) => setQuickViewProduct(p)}
            />
          ))}
        </div>

        <div className="text-center mt-12">
          <Link
            to="/shop"
            className="inline-flex items-center gap-2 px-8 py-4 bg-neutral-900 dark:bg-white text-white dark:text-neutral-950 font-bold text-xs uppercase tracking-widest rounded-2xl hover:opacity-90 transition-opacity shadow-lg"
          >
            <span>View All T-Shirts Under ₹699</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      {/* 5. FLASH SALE BANNER WITH COUPON */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-amber-500 via-orange-600 to-rose-600 text-white p-8 sm:p-12 shadow-2xl">
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div className="space-y-4">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-extrabold uppercase tracking-wider">
                <Clock className="w-3.5 h-3.5" /> Tamil Nadu Flash Drop
              </span>
              <h2 className="text-3xl sm:text-5xl font-black font-heading leading-tight">
                EXTRA ₹50 OFF <br />ON ALL ORDERS!
              </h2>
              <p className="text-sm sm:text-base text-white/90 max-w-md">
                Get high quality Tirupur 100% cotton tees starting at just ₹199. Use coupon code below at checkout.
              </p>

              {/* Coupon Code Block */}
              <div className="inline-flex items-center gap-3 bg-neutral-950/40 backdrop-blur-md p-2 pl-4 rounded-2xl border border-white/30">
                <div>
                  <p className="text-[10px] text-white/70 font-semibold uppercase">Coupon Code</p>
                  <p className="font-mono text-lg font-black tracking-widest text-amber-300">VANAKKAM50</p>
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText('VANAKKAM50');
                    alert('Copied coupon code VANAKKAM50!');
                  }}
                  className="px-4 py-2 bg-white text-neutral-950 font-bold text-xs rounded-xl hover:bg-neutral-100 transition-colors uppercase"
                >
                  Copy
                </button>
              </div>
            </div>

            {/* Countdown timer */}
            <div className="flex flex-col items-center lg:items-end justify-center">
              <p className="text-xs font-bold uppercase tracking-widest text-white/80 mb-3">
                Offer ends in:
              </p>
              <div className="flex gap-3 text-center">
                <div className="bg-neutral-950/60 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/20 min-w-[70px]">
                  <span className="text-2xl sm:text-3xl font-black font-heading">{String(timeLeft.hours).padStart(2, '0')}</span>
                  <span className="block text-[10px] uppercase font-bold text-white/70">Hours</span>
                </div>
                <div className="bg-neutral-950/60 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/20 min-w-[70px]">
                  <span className="text-2xl sm:text-3xl font-black font-heading">{String(timeLeft.minutes).padStart(2, '0')}</span>
                  <span className="block text-[10px] uppercase font-bold text-white/70">Mins</span>
                </div>
                <div className="bg-neutral-950/60 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/20 min-w-[70px]">
                  <span className="text-2xl sm:text-3xl font-black font-heading">{String(timeLeft.seconds).padStart(2, '0')}</span>
                  <span className="block text-[10px] uppercase font-bold text-white/70">Secs</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. WHY CHOOSE TIRUPUR COTTON (VALUE PROPS) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 flex flex-col items-center text-center space-y-2">
            <div className="p-3 bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-2xl">
              <Zap className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-neutral-900 dark:text-white font-heading">Zudio Price Match</h4>
            <p className="text-xs text-neutral-500">Every single tee priced between ₹199 and ₹699 with zero quality compromise.</p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 flex flex-col items-center text-center space-y-2">
            <div className="p-3 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-2xl">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-neutral-900 dark:text-white font-heading">100% Tirupur Combed Cotton</h4>
            <p className="text-xs text-neutral-500">Super breathable, bio-washed, pre-shrunk, ideal for Tamil Nadu tropical climate.</p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 flex flex-col items-center text-center space-y-2">
            <div className="p-3 bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-2xl">
              <Truck className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-neutral-900 dark:text-white font-heading">24-48hr Fast Delivery & COD</h4>
            <p className="text-xs text-neutral-500">Express delivery across Chennai, Coimbatore, Madurai, Trichy and all 38 districts.</p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 flex flex-col items-center text-center space-y-2">
            <div className="p-3 bg-rose-500/10 text-rose-600 dark:text-rose-400 rounded-2xl">
              <RefreshCw className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-neutral-900 dark:text-white font-heading">7-Day Easy Doorstep Returns</h4>
            <p className="text-xs text-neutral-500">Hassle-free size exchanges and instant refunds with zero questions asked.</p>
          </div>
        </div>
      </section>

      {/* 7. VERIFIED TAMIL NADU CUSTOMER REVIEWS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-widest text-neutral-500">Customer Love</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white font-heading mt-1">
            Loved by 50,000+ Shoppers Across Tamil Nadu
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-3xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-4 shadow-sm">
            <div className="flex items-center gap-1 text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-current" />
              ))}
            </div>
            <p className="text-xs text-neutral-700 dark:text-neutral-300 leading-relaxed font-medium">
              "வேற லெவல் குவாலிட்டி! I ordered the Vera Level tee in Chennai Super Yellow. The Tirupur 210 GSM cotton is super soft and breathable in the Chennai humid climate. Delivered in 24 hours!"
            </p>
            <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between text-xs">
              <span className="font-bold text-neutral-900 dark:text-white">Karthik S.</span>
              <span className="text-neutral-400">Anna Nagar, Chennai</span>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-4 shadow-sm">
            <div className="flex items-center gap-1 text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-current" />
              ))}
            </div>
            <p className="text-xs text-neutral-700 dark:text-neutral-300 leading-relaxed font-medium">
              "Only ₹249 for pure 100% Tirupur cotton! I bought 4 plain basic tees for daily office wear. You cannot get this quality even in Zudio or Max for this price. No shrinking after wash."
            </p>
            <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between text-xs">
              <span className="font-bold text-neutral-900 dark:text-white">Divya R.</span>
              <span className="text-neutral-400">RS Puram, Coimbatore</span>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-4 shadow-sm">
            <div className="flex items-center gap-1 text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-current" />
              ))}
            </div>
            <p className="text-xs text-neutral-700 dark:text-neutral-300 leading-relaxed font-medium">
              "Whistle Podu and Filter Kaapi prints are so creative! The colors are super vibrant and don't fade. Cash on delivery was seamless in Madurai."
            </p>
            <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between text-xs">
              <span className="font-bold text-neutral-900 dark:text-white">Muthukumar P.</span>
              <span className="text-neutral-400">KK Nagar, Madurai</span>
            </div>
          </div>
        </div>
      </section>

      {/* 8. RECENTLY VIEWED CAROUSEL */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <RecentlyViewed onQuickView={(p) => setQuickViewProduct(p)} />
      </section>

      {/* Quick View Modal */}
      <QuickViewModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
      />
    </div>
  );
};
