import React, { useState, useEffect } from 'react';
import { useSearchParams, Link, useNavigate } from 'react-router-dom';
import {
  User as UserIcon,
  Package,
  MapPin,
  Lock,
  Plus,
  Trash2,
  CheckCircle2,
  Shield,
  Truck,
  ExternalLink,
  RotateCcw
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import api from '../services/api';
import { Order } from '../types';

export const UserProfilePage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const activeTabParam = searchParams.get('tab') || 'profile';

  const { user, updateProfile, addAddress, deleteAddress, logout } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState<string>(activeTabParam);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(false);

  // Profile Edit State
  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);

  // New Address State
  const [showAddressModal, setShowAddressModal] = useState(false);
  const [newAddress, setNewAddress] = useState({
    street: '',
    city: '',
    state: 'Maharashtra',
    zipCode: '',
    country: 'India',
    isDefault: false
  });

  // Password Change State
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [isChangingPass, setIsChangingPass] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate('/login');
    } else {
      setName(user.name);
      setPhone(user.phone || '');
    }
  }, [user, navigate]);

  useEffect(() => {
    setActiveTab(activeTabParam);
  }, [activeTabParam]);

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    setSearchParams({ tab });
  };

  // Fetch Orders
  useEffect(() => {
    if (activeTab === 'orders') {
      const fetchOrders = async () => {
        try {
          setLoadingOrders(true);
          const res = await api.get('/orders');
          if (res.data.success) {
            setOrders(res.data.orders);
          }
        } catch {
          // Ignore
        } finally {
          setLoadingOrders(false);
        }
      };
      fetchOrders();
    }
  }, [activeTab]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdatingProfile(true);
    await updateProfile({ name, phone });
    setIsUpdatingProfile(false);
  };

  const handleCreateAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAddress.street || !newAddress.city || !newAddress.zipCode) {
      showToast('Please fill out all address fields', 'error');
      return;
    }
    const success = await addAddress(newAddress);
    if (success) {
      setShowAddressModal(false);
      setNewAddress({ street: '', city: '', state: 'Maharashtra', zipCode: '', country: 'India', isDefault: false });
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 6) {
      showToast('Password must be at least 6 characters', 'error');
      return;
    }
    try {
      setIsChangingPass(true);
      const res = await api.put('/auth/password', { currentPassword: oldPassword, newPassword });
      if (res.data.success) {
        showToast('Password updated successfully!', 'success');
        setOldPassword('');
        setNewPassword('');
      } else {
        showToast(res.data.message || 'Failed to update password', 'error');
      }
    } catch {
      showToast('Incorrect current password', 'error');
    } finally {
      setIsChangingPass(false);
    }
  };

  const handleCancelOrder = async (orderId: string) => {
    try {
      const res = await api.put(`/orders/${orderId}/cancel`);
      if (res.data.success) {
        showToast('Order cancelled', 'info');
        setOrders((prev) =>
          prev.map((o) => (o.id === orderId ? { ...o, status: 'CANCELLED' } : o))
        );
      }
    } catch {
      showToast('Could not cancel order', 'error');
    }
  };

  if (!user) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header Profile Summary */}
      <div className="bg-white dark:bg-neutral-900 rounded-3xl p-6 sm:p-8 border border-neutral-200 dark:border-neutral-800 mb-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 flex items-center justify-center font-black text-2xl uppercase font-heading">
            {user.name.charAt(0)}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-neutral-900 dark:text-white font-heading">
                {user.name}
              </h1>
              {user.role === 'ADMIN' && (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 flex items-center gap-1">
                  <Shield className="w-3 h-3" /> Admin
                </span>
              )}
            </div>
            <p className="text-xs text-neutral-500 mt-0.5">{user.email} • {user.phone || 'No phone set'}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {user.role === 'ADMIN' && (
            <Link
              to="/admin"
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors"
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Admin Dashboard</span>
            </Link>
          )}
          <button
            onClick={logout}
            className="px-4 py-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-50 dark:hover:bg-neutral-800 text-xs font-bold transition-colors"
          >
            Sign Out
          </button>
        </div>
      </div>

      {/* Main Account Tabs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Navigation Sidebar */}
        <aside className="lg:col-span-3">
          <div className="bg-white dark:bg-neutral-900 rounded-3xl p-3 border border-neutral-200 dark:border-neutral-800 space-y-1">
            {[
              { id: 'profile', label: 'My Profile', icon: UserIcon },
              { id: 'orders', label: 'Order History', icon: Package },
              { id: 'addresses', label: 'Saved Addresses', icon: MapPin },
              { id: 'security', label: 'Account Security', icon: Lock }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => handleTabChange(tab.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs font-bold transition-all text-left ${
                    activeTab === tab.id
                      ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 shadow-md'
                      : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </aside>

        {/* Tab Content Panel */}
        <main className="lg:col-span-9">
          
          {/* 1. Profile Info Tab */}
          {activeTab === 'profile' && (
            <div className="bg-white dark:bg-neutral-900 rounded-3xl p-6 sm:p-8 border border-neutral-200 dark:border-neutral-800 space-y-6">
              <h2 className="text-base font-extrabold text-neutral-900 dark:text-white font-heading uppercase tracking-wider">
                Personal Information
              </h2>

              <form onSubmit={handleSaveProfile} className="space-y-4 max-w-lg">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1.5">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-xs text-neutral-900 dark:text-white focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1.5">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={user.email}
                    disabled
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-xs text-neutral-500 cursor-not-allowed"
                  />
                  <p className="text-[10px] text-neutral-400 mt-1">Email cannot be changed directly.</p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1.5">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="9876543210"
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-xs text-neutral-900 dark:text-white focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isUpdatingProfile}
                  className="px-6 py-3 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 text-xs font-bold uppercase tracking-wider rounded-xl hover:opacity-90 disabled:opacity-50"
                >
                  {isUpdatingProfile ? 'Saving...' : 'Save Profile Changes'}
                </button>
              </form>
            </div>
          )}

          {/* 2. Orders Tab */}
          {activeTab === 'orders' && (
            <div className="bg-white dark:bg-neutral-900 rounded-3xl p-6 sm:p-8 border border-neutral-200 dark:border-neutral-800 space-y-6">
              <h2 className="text-base font-extrabold text-neutral-900 dark:text-white font-heading uppercase tracking-wider">
                My Orders ({orders.length})
              </h2>

              {loadingOrders ? (
                <div className="space-y-4 animate-pulse">
                  {[...Array(2)].map((_, i) => (
                    <div key={i} className="h-32 bg-neutral-100 dark:bg-neutral-800 rounded-2xl" />
                  ))}
                </div>
              ) : orders.length === 0 ? (
                <div className="text-center py-12">
                  <Package className="w-12 h-12 text-neutral-400 mx-auto mb-3" />
                  <p className="text-sm font-bold text-neutral-900 dark:text-white">No orders placed yet</p>
                  <p className="text-xs text-neutral-500 mt-1 mb-4">When you place an order, you can track it live here.</p>
                  <Link
                    to="/shop"
                    className="px-6 py-2.5 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 text-xs font-bold rounded-xl uppercase tracking-wider inline-block"
                  >
                    Start Shopping
                  </Link>
                </div>
              ) : (
                <div className="space-y-4">
                  {orders.map((order) => (
                    <div
                      key={order.id}
                      className="p-5 rounded-2xl border border-neutral-200 dark:border-neutral-800 space-y-4 hover:border-neutral-300 dark:hover:border-neutral-700 transition-colors"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-neutral-100 dark:border-neutral-800 text-xs">
                        <div>
                          <span className="font-mono font-bold text-neutral-900 dark:text-white">{order.orderNumber}</span>
                          <span className="text-neutral-400 ml-3">{new Date(order.createdAt).toLocaleDateString()}</span>
                        </div>

                        <div className="flex items-center gap-3">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold tracking-wider uppercase ${
                            order.status === 'DELIVERED'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : order.status === 'CANCELLED'
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : 'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}>
                            {order.status}
                          </span>

                          <span className="font-black text-neutral-900 dark:text-white">₹{order.total}</span>
                        </div>
                      </div>

                      {/* Items */}
                      <div className="space-y-3">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="flex items-center gap-3 text-xs">
                            <img src={item.image} alt={item.name} className="w-12 h-14 rounded-lg object-cover bg-neutral-100 shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="font-bold text-neutral-900 dark:text-white truncate">{item.name}</p>
                              <p className="text-neutral-500 text-[11px]">Size: {item.size} • Color: {item.color} • Qty: {item.quantity}</p>
                            </div>
                            <span className="font-bold text-neutral-900 dark:text-white">₹{item.price * item.quantity}</span>
                          </div>
                        ))}
                      </div>

                      {/* Tracking / Cancel */}
                      <div className="flex items-center justify-between pt-3 border-t border-neutral-100 dark:border-neutral-800 text-xs">
                        <span className="text-neutral-500 font-mono">Tracking: <strong className="text-indigo-600 dark:text-indigo-400">{order.trackingNumber}</strong></span>
                        {order.status === 'PENDING' && (
                          <button
                            onClick={() => handleCancelOrder(order.id)}
                            className="text-xs font-bold text-rose-600 hover:underline"
                          >
                            Cancel Order
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* 3. Saved Addresses Tab */}
          {activeTab === 'addresses' && (
            <div className="bg-white dark:bg-neutral-900 rounded-3xl p-6 sm:p-8 border border-neutral-200 dark:border-neutral-800 space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-extrabold text-neutral-900 dark:text-white font-heading uppercase tracking-wider">
                  Saved Delivery Addresses
                </h2>
                <button
                  onClick={() => setShowAddressModal(true)}
                  className="px-4 py-2 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 text-xs font-bold rounded-xl flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add New</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {user.addresses && user.addresses.length > 0 ? (
                  user.addresses.map((addr) => (
                    <div
                      key={addr.id}
                      className="p-5 rounded-2xl border border-neutral-200 dark:border-neutral-800 space-y-2 relative"
                    >
                      <button
                        onClick={() => deleteAddress(addr.id)}
                        className="absolute top-4 right-4 text-neutral-400 hover:text-rose-500 p-1"
                        title="Delete Address"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>

                      {addr.isDefault && (
                        <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-[10px] font-bold uppercase">
                          Default Address
                        </span>
                      )}

                      <p className="text-xs font-bold text-neutral-900 dark:text-white pt-1">{addr.street}</p>
                      <p className="text-xs text-neutral-500">{addr.city}, {addr.state} - {addr.zipCode}</p>
                      <p className="text-xs text-neutral-500">{addr.country}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-neutral-500 col-span-2 py-4">No saved addresses yet.</p>
                )}
              </div>

              {/* Add Address Modal */}
              {showAddressModal && (
                <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
                  <div className="bg-white dark:bg-neutral-900 rounded-3xl max-w-md w-full p-6 space-y-4 border border-neutral-200 dark:border-neutral-800 shadow-2xl">
                    <h3 className="text-base font-bold text-neutral-900 dark:text-white font-heading">Add New Address</h3>
                    <form onSubmit={handleCreateAddress} className="space-y-3">
                      <div>
                        <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">Street Address</label>
                        <input
                          type="text"
                          value={newAddress.street}
                          onChange={(e) => setNewAddress({ ...newAddress, street: e.target.value })}
                          placeholder="Flat 101, Residency road"
                          className="w-full px-3 py-2 rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-xs text-neutral-900 dark:text-white focus:outline-none"
                          required
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">City</label>
                          <input
                            type="text"
                            value={newAddress.city}
                            onChange={(e) => setNewAddress({ ...newAddress, city: e.target.value })}
                            placeholder="Mumbai"
                            className="w-full px-3 py-2 rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-xs text-neutral-900 dark:text-white focus:outline-none"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">PIN Code</label>
                          <input
                            type="text"
                            maxLength={6}
                            value={newAddress.zipCode}
                            onChange={(e) => setNewAddress({ ...newAddress, zipCode: e.target.value })}
                            placeholder="400001"
                            className="w-full px-3 py-2 rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-xs text-neutral-900 dark:text-white font-mono focus:outline-none"
                            required
                          />
                        </div>
                      </div>
                      <div className="flex gap-2 pt-2">
                        <button
                          type="submit"
                          className="flex-1 py-2.5 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 text-xs font-bold uppercase rounded-xl"
                        >
                          Save Address
                        </button>
                        <button
                          type="button"
                          onClick={() => setShowAddressModal(false)}
                          className="px-4 py-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 text-xs font-bold"
                        >
                          Cancel
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 4. Security Tab */}
          {activeTab === 'security' && (
            <div className="bg-white dark:bg-neutral-900 rounded-3xl p-6 sm:p-8 border border-neutral-200 dark:border-neutral-800 space-y-6">
              <h2 className="text-base font-extrabold text-neutral-900 dark:text-white font-heading uppercase tracking-wider">
                Change Password
              </h2>

              <form onSubmit={handleChangePassword} className="space-y-4 max-w-lg">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1.5">
                    Current Password
                  </label>
                  <input
                    type="password"
                    value={oldPassword}
                    onChange={(e) => setOldPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-xs text-neutral-900 dark:text-white focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1.5">
                    New Password
                  </label>
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="At least 6 characters"
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-xs text-neutral-900 dark:text-white focus:outline-none"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={isChangingPass}
                  className="px-6 py-3 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 text-xs font-bold uppercase tracking-wider rounded-xl hover:opacity-90 disabled:opacity-50"
                >
                  {isChangingPass ? 'Updating...' : 'Update Password'}
                </button>
              </form>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
