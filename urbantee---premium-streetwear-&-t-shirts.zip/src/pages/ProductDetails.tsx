import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  Star,
  Heart,
  ShoppingBag,
  Zap,
  Ruler,
  Share2,
  CheckCircle2,
  Truck,
  RefreshCw,
  ShieldCheck,
  ChevronRight,
  Sparkles,
  MessageSquare,
  ThumbsUp,
  Layers
} from 'lucide-react';
import api from '../services/api';
import { Product, Review } from '../types';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { useCompare } from '../context/CompareContext';
import { useToast } from '../context/ToastContext';
import { useAuth } from '../context/AuthContext';
import { SizeGuideModal } from '../components/common/SizeGuideModal';
import { DeliveryChecker } from '../components/common/DeliveryChecker';
import { ProductCard } from '../components/common/ProductCard';
import { RecentlyViewed } from '../components/common/RecentlyViewed';

export const ProductDetails: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { showToast } = useToast();
  const { addToCart } = useCart();
  const { isInWishlist, toggleWishlist } = useWishlist();
  const { isComparing, addToCompare } = useCompare();
  const { user } = useAuth();

  const [product, setProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  const [selectedImage, setSelectedImage] = useState<number>(0);
  const [selectedSize, setSelectedSize] = useState<string>('M');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState<boolean>(false);
  const [isAdding, setIsAdding] = useState<boolean>(false);

  // Review submission state
  const [newRating, setNewRating] = useState<number>(5);
  const [newTitle, setNewTitle] = useState<string>('');
  const [newComment, setNewComment] = useState<string>('');
  const [isSubmittingReview, setIsSubmittingReview] = useState<boolean>(false);
  const [showReviewForm, setShowReviewForm] = useState<boolean>(false);

  // Active accordion tab
  const [activeTab, setActiveTab] = useState<'desc' | 'specs' | 'care' | 'reviews'>('desc');

  useEffect(() => {
    const fetchProductDetails = async () => {
      if (!slug) return;
      try {
        setLoading(true);
        const res = await api.get(`/products/slug/${slug}`);
        if (res.data.success) {
          const p: Product = res.data.product;
          setProduct(p);
          setSelectedSize(p.sizes[0] || 'M');
          setSelectedColor(p.colors[0]?.name || '');
          setSelectedImage(0);

          // Save to recently viewed
          try {
            const stored = localStorage.getItem('urbantee_recently_viewed');
            let list: Product[] = stored ? JSON.parse(stored) : [];
            list = list.filter((item) => item.id !== p.id);
            list.unshift(p);
            localStorage.setItem('urbantee_recently_viewed', JSON.stringify(list.slice(0, 10)));
          } catch {
            // Ignore
          }

          // Fetch related products in the same category
          const relRes = await api.get(`/products?category=${p.category}&limit=5`);
          if (relRes.data.success) {
            setRelatedProducts(relRes.data.products.filter((item: Product) => item.id !== p.id).slice(0, 4));
          }
        }
      } catch (err) {
        console.error('Failed to load product details', err);
      } finally {
        setLoading(false);
      }
    };

    fetchProductDetails();
  }, [slug]);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 animate-pulse">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="aspect-[3/4] bg-neutral-200 dark:bg-neutral-800 rounded-3xl" />
          <div className="space-y-4">
            <div className="h-8 bg-neutral-200 dark:bg-neutral-800 rounded w-3/4" />
            <div className="h-6 bg-neutral-200 dark:bg-neutral-800 rounded w-1/4" />
            <div className="h-24 bg-neutral-200 dark:bg-neutral-800 rounded w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-2">T-Shirt Not Found</h2>
        <p className="text-xs text-neutral-500 mb-6">The style you are looking for might have been archived.</p>
        <Link
          to="/shop"
          className="px-6 py-2.5 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-xl text-xs font-bold uppercase tracking-wider"
        >
          Return to Shop
        </Link>
      </div>
    );
  }

  const handleAddToCart = async () => {
    setIsAdding(true);
    await addToCart(product.id, selectedSize, selectedColor, quantity);
    setIsAdding(false);
  };

  const handleBuyNow = async () => {
    await addToCart(product.id, selectedSize, selectedColor, quantity);
    navigate('/checkout');
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      showToast('Link copied to clipboard! 📋', 'success');
    }
  };

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newComment.trim()) {
      showToast('Please provide a review title and comment', 'error');
      return;
    }

    try {
      setIsSubmittingReview(true);
      const res = await api.post(`/products/${product.id}/reviews`, {
        rating: newRating,
        title: newTitle,
        comment: newComment
      });

      if (res.data.success) {
        setProduct((prev) => (prev ? { ...prev, reviews: [res.data.review, ...(prev.reviews || [])] } : null));
        showToast('Thank you! Your review has been posted.', 'success');
        setNewTitle('');
        setNewComment('');
        setShowReviewForm(false);
      }
    } catch {
      showToast('Failed to submit review', 'error');
    } finally {
      setIsSubmittingReview(false);
    }
  };

  const inWishlist = isInWishlist(product.id);
  const comparing = isComparing(product.id);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10">
      
      {/* Breadcrumb navigation */}
      <nav className="flex items-center gap-2 text-xs text-neutral-400 mb-8 overflow-x-auto">
        <Link to="/" className="hover:text-neutral-900 dark:hover:text-white">Home</Link>
        <ChevronRight className="w-3 h-3" />
        <Link to="/shop" className="hover:text-neutral-900 dark:hover:text-white">Shop</Link>
        <ChevronRight className="w-3 h-3" />
        <Link to={`/category/${product.category}`} className="hover:text-neutral-900 dark:hover:text-white capitalize">
          {product.category}
        </Link>
        <ChevronRight className="w-3 h-3" />
        <span className="text-neutral-900 dark:text-white font-semibold truncate max-w-xs">{product.name}</span>
      </nav>

      {/* Main Product Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14">
        
        {/* Left Side: Product Gallery */}
        <div className="lg:col-span-7 flex flex-col-reverse sm:flex-row gap-4">
          
          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex sm:flex-col gap-3 overflow-x-auto sm:overflow-y-auto sm:w-20 shrink-0">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImage(idx)}
                  className={`w-16 h-20 sm:w-20 sm:h-24 rounded-2xl overflow-hidden border-2 shrink-0 transition-all ${
                    selectedImage === idx
                      ? 'border-neutral-900 dark:border-white shadow-md scale-105'
                      : 'border-transparent opacity-60 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}

          {/* Featured Large View */}
          <div className="relative flex-1 aspect-[3/4] rounded-3xl overflow-hidden bg-neutral-100 dark:bg-neutral-800 border border-neutral-200/80 dark:border-neutral-800">
            {product.discount > 0 && (
              <span className="absolute top-4 left-4 z-10 px-3 py-1 bg-rose-500 text-white text-xs font-black uppercase tracking-wider rounded-lg shadow-md">
                {product.discount}% OFF
              </span>
            )}

            <button
              onClick={() => toggleWishlist(product.id)}
              className={`absolute top-4 right-4 z-10 p-3 rounded-full backdrop-blur-md transition-all ${
                inWishlist
                  ? 'bg-rose-500 text-white shadow-lg'
                  : 'bg-white/80 dark:bg-neutral-900/80 text-neutral-800 dark:text-neutral-200 hover:bg-white'
              }`}
              aria-label="Toggle Wishlist"
            >
              <Heart className={`w-5 h-5 ${inWishlist ? 'fill-current' : ''}`} />
            </button>

            <img
              src={product.images[selectedImage] || product.images[0]}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Right Side: Product Configuration & CTA */}
        <div className="lg:col-span-5 space-y-6">
          <div>
            <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
              <span className="uppercase font-bold tracking-widest text-neutral-500">
                {product.category} • {product.gender.toUpperCase()}
              </span>
              <span className="font-mono text-neutral-500">SKU: {product.sku}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-neutral-900 dark:text-white font-heading tracking-tight leading-tight">
              {product.name}
            </h1>

            {/* Rating summary */}
            <div className="flex items-center gap-3 mt-3">
              <div className="flex items-center text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < Math.floor(product.rating) ? 'fill-current' : 'text-neutral-300 dark:text-neutral-700'
                    }`}
                  />
                ))}
              </div>
              <span className="text-xs font-bold text-neutral-900 dark:text-white">{product.rating}</span>
              <span className="text-xs text-neutral-400">({product.reviewCount} customer reviews)</span>
            </div>
          </div>

          {/* Pricing & Zudio Value Comparison */}
          <div className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200 dark:border-neutral-800 space-y-2">
            <div className="flex items-baseline justify-between">
              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-black text-neutral-900 dark:text-white font-heading">
                  ₹{product.price}
                </span>
                {product.originalPrice > product.price && (
                  <span className="text-sm text-neutral-400 line-through">₹{product.originalPrice}</span>
                )}
                {product.discount > 0 && (
                  <span className="px-2.5 py-0.5 bg-rose-500/10 text-rose-600 dark:text-rose-400 text-xs font-bold rounded-md">
                    Save ₹{product.originalPrice - product.price} ({product.discount}%)
                  </span>
                )}
              </div>
              <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full">
                ⚡ Direct Factory Price
              </span>
            </div>

            <div className="flex items-center gap-2 pt-1 text-[11px] text-neutral-500">
              <span className="font-semibold text-neutral-700 dark:text-neutral-300">Mall Price: ₹{product.price + 500}</span>
              <span>•</span>
              <span className="text-amber-600 dark:text-amber-400 font-bold">You Save ₹500+ with UrbanTee Tirupur Direct</span>
            </div>
          </div>

          {/* Highlight features bullets */}
          <div className="flex items-center gap-4 text-xs font-semibold text-neutral-700 dark:text-neutral-300">
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" /> {product.gsm} GSM
            </span>
            <span>•</span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> {product.fabric}
            </span>
            <span>•</span>
            <span>{product.fit}</span>
          </div>

          {/* Color Selection with All Color Swatches */}
          <div>
            <div className="flex items-center justify-between mb-2 text-xs">
              <span className="font-bold text-neutral-900 dark:text-white uppercase tracking-wider">
                Select Color ({product.colors.length} Available): <strong className="text-amber-600 dark:text-amber-400">{selectedColor}</strong>
              </span>
            </div>
            <div className="flex gap-2.5 flex-wrap">
              {product.colors.map((c, i) => (
                <button
                  key={c.name}
                  onClick={() => {
                    setSelectedColor(c.name);
                    if (product.images[i % product.images.length]) {
                      setSelectedImage(i % product.images.length);
                    }
                  }}
                  className={`w-9 h-9 rounded-full border-2 p-0.5 flex items-center justify-center transition-all ${
                    selectedColor === c.name ? 'border-neutral-900 dark:border-white scale-110 shadow-md ring-2 ring-amber-400' : 'border-transparent hover:scale-105'
                  }`}
                  title={c.name}
                >
                  <span className="w-full h-full rounded-full border border-neutral-300 shadow-inner" style={{ backgroundColor: c.hex }} />
                </button>
              ))}
            </div>
          </div>

          {/* Size Selection */}
          <div>
            <div className="flex items-center justify-between mb-2 text-xs">
              <span className="font-bold text-neutral-900 dark:text-white uppercase tracking-wider">
                Select Size: <strong className="text-neutral-900 dark:text-white">{selectedSize}</strong>
              </span>
              <button
                onClick={() => setIsSizeGuideOpen(true)}
                className="text-xs font-bold text-neutral-900 dark:text-white underline flex items-center gap-1 hover:text-neutral-600"
              >
                <Ruler className="w-3.5 h-3.5" /> Size Guide
              </button>
            </div>
            <div className="grid grid-cols-5 gap-2">
              {product.sizes.map((sz) => (
                <button
                  key={sz}
                  onClick={() => setSelectedSize(sz)}
                  className={`py-3 text-xs font-bold rounded-2xl border transition-all ${
                    selectedSize === sz
                      ? 'bg-neutral-900 text-white border-neutral-900 dark:bg-white dark:text-neutral-900 dark:border-white shadow-md'
                      : 'border-neutral-200 dark:border-neutral-700 text-neutral-800 dark:text-neutral-200 hover:border-neutral-400'
                  }`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </div>

          {/* Quantity selector & CTA buttons */}
          <div className="space-y-3 pt-2">
            <div className="flex gap-3">
              {/* Quantity */}
              <div className="flex items-center border border-neutral-300 dark:border-neutral-700 rounded-2xl px-3 bg-white dark:bg-neutral-900">
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="p-1 text-neutral-600 dark:text-neutral-300 hover:text-neutral-950 dark:hover:text-white text-base font-bold"
                >
                  -
                </button>
                <span className="px-3 text-sm font-bold text-neutral-900 dark:text-white">{quantity}</span>
                <button
                  onClick={() => setQuantity((q) => q + 1)}
                  className="p-1 text-neutral-600 dark:text-neutral-300 hover:text-neutral-950 dark:hover:text-white text-base font-bold"
                >
                  +
                </button>
              </div>

              {/* Add to Bag */}
              <button
                onClick={handleAddToCart}
                disabled={isAdding || product.stock <= 0}
                className="flex-1 py-4 px-6 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-900 font-extrabold text-xs uppercase tracking-widest rounded-2xl shadow-xl flex items-center justify-center gap-2 transition-all disabled:opacity-50"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{isAdding ? 'Adding...' : 'Add to Bag'}</span>
              </button>

              {/* Compare Button */}
              <button
                onClick={() => addToCompare(product)}
                className={`p-4 rounded-2xl border transition-all ${
                  comparing
                    ? 'bg-indigo-600 text-white border-indigo-600'
                    : 'border-neutral-200 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                }`}
                title="Compare with other t-shirts"
              >
                <Layers className="w-5 h-5" />
              </button>

              {/* Share */}
              <button
                onClick={handleShare}
                className="p-4 rounded-2xl border border-neutral-200 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                title="Share link"
              >
                <Share2 className="w-5 h-5" />
              </button>
            </div>

            {/* Instant Buy Now Button */}
            <button
              onClick={handleBuyNow}
              disabled={product.stock <= 0}
              className="w-full py-4 bg-amber-400 hover:bg-amber-300 text-neutral-950 font-black text-xs uppercase tracking-widest rounded-2xl shadow-lg flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              <Zap className="w-4 h-4" />
              <span>BUY NOW • CASH ON DELIVERY AVAILABLE</span>
            </button>
          </div>

          {/* Pin Code Delivery Checker */}
          <DeliveryChecker />

          {/* Value Props Strip */}
          <div className="grid grid-cols-3 gap-3 pt-2 text-center text-[11px] text-neutral-500 border-t border-neutral-100 dark:border-neutral-800">
            <div className="flex flex-col items-center gap-1">
              <Truck className="w-4 h-4 text-neutral-800 dark:text-neutral-200" />
              <span>Free Shipping &gt; ₹999</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <RefreshCw className="w-4 h-4 text-neutral-800 dark:text-neutral-200" />
              <span>7-Day Returns</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <ShieldCheck className="w-4 h-4 text-neutral-800 dark:text-neutral-200" />
              <span>100% Pure Cotton</span>
            </div>
          </div>
        </div>
      </div>

      {/* Accordion Tabs for Specifications, Wash Care, & Reviews */}
      <section className="mt-16 pt-8 border-t border-neutral-200 dark:border-neutral-800">
        <div className="flex border-b border-neutral-200 dark:border-neutral-800 gap-6 overflow-x-auto">
          {[
            { id: 'desc', label: 'Description & Styling' },
            { id: 'specs', label: 'Specifications & Fabric' },
            { id: 'care', label: 'Wash & Care Instructions' },
            { id: 'reviews', label: `Customer Reviews (${product.reviews?.length || 0})` }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`pb-4 text-sm font-bold tracking-wider uppercase whitespace-nowrap transition-all border-b-2 ${
                activeTab === tab.id
                  ? 'border-neutral-900 text-neutral-900 dark:border-white dark:text-white'
                  : 'border-transparent text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="py-8 text-sm">
          {activeTab === 'desc' && (
            <div className="max-w-3xl space-y-4 text-neutral-700 dark:text-neutral-300 leading-relaxed">
              <p className="text-base font-semibold text-neutral-900 dark:text-white">
                {product.description}
              </p>
              <p>
                Crafted for comfort and presence, the {product.name} delivers an effortless high-fashion boxy drape. Engineered with reinforced twin-needle stitching around the collar and armholes to prevent distortion over time.
              </p>
              <h4 className="font-bold text-neutral-900 dark:text-white pt-2">Styling Suggestion:</h4>
              <p>
                Pair with baggy cargo pants or vintage washed denim and chunky sneakers for an authentic contemporary streetwear aesthetic.
              </p>
            </div>
          )}

          {activeTab === 'specs' && (
            <div className="max-w-2xl">
              <table className="w-full text-xs text-left">
                <tbody className="divide-y divide-neutral-200 dark:divide-neutral-800">
                  <tr>
                    <td className="py-3 font-bold text-neutral-500 w-1/3">Fabric Composition</td>
                    <td className="py-3 text-neutral-900 dark:text-white font-medium">{product.fabric}</td>
                  </tr>
                  <tr>
                    <td className="py-3 font-bold text-neutral-500">GSM / Density</td>
                    <td className="py-3 text-neutral-900 dark:text-white font-medium">{product.gsm} GSM Heavyweight French Terry / Cotton</td>
                  </tr>
                  <tr>
                    <td className="py-3 font-bold text-neutral-500">Fit Silhouette</td>
                    <td className="py-3 text-neutral-900 dark:text-white font-medium">{product.fit} with dropped shoulders</td>
                  </tr>
                  <tr>
                    <td className="py-3 font-bold text-neutral-500">Neckline</td>
                    <td className="py-3 text-neutral-900 dark:text-white font-medium">1.25" Heavy Ribbed Crewneck</td>
                  </tr>
                  <tr>
                    <td className="py-3 font-bold text-neutral-500">Country of Origin</td>
                    <td className="py-3 text-neutral-900 dark:text-white font-medium">Crafted in Tirupur, India</td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'care' && (
            <div className="max-w-2xl space-y-3 text-neutral-700 dark:text-neutral-300 text-xs">
              <p className="font-bold text-neutral-900 dark:text-white text-sm">To preserve colors and heavyweight drape:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Machine wash cold (under 30°C) with similar dark colors.</li>
                <li>Wash and dry inside-out to protect high-density prints and embroidery.</li>
                <li>Do NOT iron directly on graphics or puff prints. Use a cool iron on reverse.</li>
                <li>Do not tumble dry or bleach. Flat air dry in shade.</li>
              </ul>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="space-y-8">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 bg-neutral-50 dark:bg-neutral-800/40 rounded-3xl border border-neutral-200 dark:border-neutral-800">
                <div>
                  <h3 className="text-lg font-bold text-neutral-900 dark:text-white font-heading">
                    Customer Ratings & Reviews
                  </h3>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex text-amber-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current" />
                      ))}
                    </div>
                    <span className="font-extrabold text-neutral-900 dark:text-white">{product.rating} out of 5</span>
                    <span className="text-xs text-neutral-400">based on {product.reviews?.length || 0} reviews</span>
                  </div>
                </div>

                <button
                  onClick={() => setShowReviewForm(!showReviewForm)}
                  className="px-5 py-2.5 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-xl text-xs font-bold uppercase tracking-wider hover:opacity-90"
                >
                  {showReviewForm ? 'Close Form' : 'Write a Review'}
                </button>
              </div>

              {/* Review Form */}
              {showReviewForm && (
                <form onSubmit={handleReviewSubmit} className="p-6 bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-4 animate-fade-in">
                  <h4 className="text-base font-bold text-neutral-900 dark:text-white font-heading">Share Your Experience</h4>
                  
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">Rating</label>
                    <div className="flex gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setNewRating(star)}
                          className={`p-1 text-2xl ${star <= newRating ? 'text-amber-400' : 'text-neutral-300'}`}
                        >
                          ★
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">Review Title</label>
                    <input
                      type="text"
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      placeholder="e.g. Best oversized fit I've bought"
                      className="w-full px-4 py-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-xs text-neutral-900 dark:text-white focus:outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">Detailed Comment</label>
                    <textarea
                      rows={4}
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      placeholder="How does the fabric feel? What size did you order and what is your height?"
                      className="w-full px-4 py-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-xs text-neutral-900 dark:text-white focus:outline-none"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmittingReview}
                    className="px-6 py-2.5 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 text-xs font-bold uppercase tracking-wider rounded-xl hover:opacity-90"
                  >
                    {isSubmittingReview ? 'Submitting...' : 'Submit Review'}
                  </button>
                </form>
              )}

              {/* Review items */}
              <div className="space-y-4">
                {product.reviews && product.reviews.length > 0 ? (
                  product.reviews.map((rev) => (
                    <div
                      key={rev.id}
                      className="p-5 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="flex text-amber-400">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} className={`w-3.5 h-3.5 ${i < rev.rating ? 'fill-current' : 'text-neutral-200'}`} />
                            ))}
                          </div>
                          <span className="font-bold text-xs text-neutral-900 dark:text-white">{rev.title}</span>
                        </div>
                        <span className="text-[11px] text-neutral-400">{new Date(rev.createdAt).toLocaleDateString()}</span>
                      </div>

                      <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">{rev.comment}</p>

                      <div className="flex items-center justify-between pt-2 text-[11px] text-neutral-400">
                        <span className="font-semibold text-neutral-800 dark:text-neutral-200 flex items-center gap-1">
                          {rev.userName}
                          {rev.verified && (
                            <span className="inline-flex items-center gap-0.5 text-emerald-600 text-[10px]">
                              <CheckCircle2 className="w-3 h-3" /> Verified Buyer
                            </span>
                          )}
                        </span>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-neutral-500 text-center py-6">No reviews yet. Be the first to review this t-shirt!</p>
                )}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Related Products Carousel */}
      {relatedProducts.length > 0 && (
        <section className="mt-16 pt-8 border-t border-neutral-200 dark:border-neutral-800">
          <h2 className="text-xl font-extrabold text-neutral-900 dark:text-white font-heading mb-6">
            You Might Also Like
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {relatedProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}

      {/* Size Guide Modal */}
      <SizeGuideModal
        isOpen={isSizeGuideOpen}
        onClose={() => setIsSizeGuideOpen(false)}
      />
    </div>
  );
};
