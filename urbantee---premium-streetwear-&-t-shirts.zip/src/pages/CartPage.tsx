import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Trash2,
  Plus,
  Minus,
  ArrowRight,
  ShoppingBag,
  Truck,
  ShieldCheck,
  Tag,
  Check,
  RotateCcw
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { RecentlyViewed } from '../components/common/RecentlyViewed';

export const CartPage: React.FC = () => {
  const {
    items,
    itemCount,
    subtotal,
    discount,
    deliveryFee,
    tax,
    total,
    freeShippingThreshold,
    amountNeededForFreeShipping,
    updateQuantity,
    removeFromCart,
    clearCart,
    appliedCoupon,
    applyCoupon,
    removeCoupon
  } = useCart();

  const [couponCode, setCouponCode] = useState('');
  const [isApplyingCoupon, setIsApplyingCoupon] = useState(false);
  const navigate = useNavigate();

  const handleApplyCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode.trim()) return;
    setIsApplyingCoupon(true);
    await applyCoupon(couponCode.trim());
    setIsApplyingCoupon(false);
    setCouponCode('');
  };

  const progressPercent = Math.min(100, Math.round((subtotal / freeShippingThreshold) * 100));

  if (items.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <div className="w-20 h-20 bg-neutral-100 dark:bg-neutral-800 rounded-full flex items-center justify-center mx-auto text-neutral-400 mb-6">
          <ShoppingBag className="w-10 h-10" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white font-heading mb-2">
          Your Shopping Bag is Empty
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 max-w-md mx-auto mb-8 leading-relaxed">
          Looks like you haven't added any items to your bag yet. Explore our curated range of oversized graphic tees, heavyweight blanks, and limited streetwear drops.
        </p>
        <Link
          to="/shop"
          className="inline-flex items-center gap-2 px-8 py-4 bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 font-bold text-xs uppercase tracking-widest rounded-xl hover:opacity-90 shadow-xl"
        >
          <span>Explore The Drop</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Title */}
      <div className="pb-6 border-b border-neutral-200 dark:border-neutral-800 mb-8 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-widest text-neutral-500">Checkout Process</span>
          <h1 className="text-3xl font-black text-neutral-900 dark:text-white font-heading mt-1">
            Shopping Bag ({itemCount} {itemCount === 1 ? 'item' : 'items'})
          </h1>
        </div>
        <button
          onClick={clearCart}
          className="text-xs font-semibold text-rose-600 hover:underline flex items-center gap-1"
        >
          <RotateCcw className="w-3.5 h-3.5" /> Clear Bag
        </button>
      </div>

      {/* Free Shipping Alert Banner */}
      <div className="p-4 rounded-2xl bg-neutral-100 dark:bg-neutral-800/60 border border-neutral-200 dark:border-neutral-800 mb-8">
        <div className="flex items-center justify-between text-xs font-medium mb-2">
          <span className="flex items-center gap-2 text-neutral-800 dark:text-neutral-200">
            <Truck className="w-4 h-4 text-emerald-600" />
            {amountNeededForFreeShipping > 0 ? (
              <span>Add <strong className="text-neutral-900 dark:text-white">₹{amountNeededForFreeShipping}</strong> more to unlock <strong>FREE Express Shipping</strong></span>
            ) : (
              <span className="text-emerald-600 font-bold flex items-center gap-1">
                <Check className="w-4 h-4" /> You have unlocked FREE Express Delivery on this order!
              </span>
            )}
          </span>
          <span className="font-bold text-neutral-900 dark:text-white">{progressPercent}%</span>
        </div>
        <div className="w-full bg-neutral-200 dark:bg-neutral-700 h-2 rounded-full overflow-hidden">
          <div
            className="bg-emerald-500 h-full rounded-full transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        
        {/* Left Side: Items List */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200 dark:border-neutral-800 divide-y divide-neutral-100 dark:divide-neutral-800 overflow-hidden">
            {items.map((item) => (
              <div key={item.id} className="p-6 flex flex-col sm:flex-row gap-5 items-start sm:items-center justify-between">
                
                <div className="flex gap-4 items-center flex-1 min-w-0">
                  <Link to={`/product/${item.slug}`} className="w-20 h-24 sm:w-24 sm:h-28 rounded-2xl overflow-hidden bg-neutral-100 shrink-0">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                  </Link>

                  <div className="min-w-0 flex-1">
                    <Link
                      to={`/product/${item.slug}`}
                      className="text-base font-extrabold text-neutral-900 dark:text-white hover:underline truncate block font-heading"
                    >
                      {item.name}
                    </Link>
                    
                    <div className="flex flex-wrap gap-2 mt-1.5 text-xs text-neutral-500">
                      <span className="px-2.5 py-0.5 rounded-lg bg-neutral-100 dark:bg-neutral-800 font-bold text-neutral-700 dark:text-neutral-300">
                        Size: {item.size}
                      </span>
                      <span className="px-2.5 py-0.5 rounded-lg bg-neutral-100 dark:bg-neutral-800 font-medium">
                        {item.color}
                      </span>
                    </div>

                    <p className="text-xs font-mono text-neutral-400 mt-2">Item ID: #{item.productId}</p>
                  </div>
                </div>

                {/* Quantity & Price */}
                <div className="flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto gap-4">
                  <div className="text-right">
                    <span className="text-base font-black text-neutral-900 dark:text-white block">
                      ₹{item.price * item.quantity}
                    </span>
                    {item.originalPrice > item.price && (
                      <span className="text-xs text-neutral-400 line-through">
                        ₹{item.originalPrice * item.quantity}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="flex items-center border border-neutral-300 dark:border-neutral-700 rounded-xl">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="p-1.5 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-l-xl"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-3 text-xs font-bold text-neutral-900 dark:text-white">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="p-1.5 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-r-xl"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="p-2 text-neutral-400 hover:text-rose-500 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
                      title="Remove from bag"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Side: Order Summary & Promo Code */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white dark:bg-neutral-900 rounded-3xl p-6 border border-neutral-200 dark:border-neutral-800 space-y-6">
            <h2 className="text-lg font-black text-neutral-900 dark:text-white font-heading uppercase tracking-wider">
              Order Summary
            </h2>

            {/* Promo Code Input */}
            <div>
              <p className="text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-2">Have a Promo Code?</p>
              {appliedCoupon ? (
                <div className="flex items-center justify-between p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs">
                  <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-300 font-medium">
                    <Tag className="w-4 h-4" />
                    <span>Coupon <strong>{appliedCoupon.code}</strong> (-₹{appliedCoupon.discountAmount})</span>
                  </div>
                  <button onClick={removeCoupon} className="text-xs font-bold text-rose-600 hover:underline">
                    Remove
                  </button>
                </div>
              ) : (
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <input
                    type="text"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                    placeholder="Coupon Code (e.g. URBAN30)"
                    className="flex-1 px-3 py-2.5 text-xs rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 uppercase font-mono placeholder:normal-case placeholder:font-sans focus:outline-none"
                  />
                  <button
                    type="submit"
                    disabled={isApplyingCoupon || !couponCode.trim()}
                    className="px-4 py-2.5 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 text-xs font-bold rounded-xl hover:opacity-90 disabled:opacity-50"
                  >
                    Apply
                  </button>
                </form>
              )}
            </div>

            {/* Summary Lines */}
            <div className="space-y-3 text-xs border-t border-neutral-100 dark:border-neutral-800 pt-4">
              <div className="flex justify-between text-neutral-600 dark:text-neutral-400">
                <span>Items Subtotal</span>
                <span className="font-bold text-neutral-900 dark:text-white">₹{subtotal}</span>
              </div>

              {discount > 0 && (
                <div className="flex justify-between text-emerald-600 dark:text-emerald-400">
                  <span>Coupon Discount</span>
                  <span className="font-bold">-₹{discount}</span>
                </div>
              )}

              <div className="flex justify-between text-neutral-600 dark:text-neutral-400">
                <span>Estimated GST (5%)</span>
                <span className="font-bold text-neutral-900 dark:text-white">₹{tax}</span>
              </div>

              <div className="flex justify-between text-neutral-600 dark:text-neutral-400">
                <span>Shipping & Delivery</span>
                <span className="font-bold text-neutral-900 dark:text-white">
                  {deliveryFee === 0 ? <span className="text-emerald-600 font-bold">FREE</span> : `₹${deliveryFee}`}
                </span>
              </div>

              <div className="flex justify-between pt-4 border-t border-neutral-200 dark:border-neutral-800 text-base font-black text-neutral-900 dark:text-white">
                <span>Grand Total</span>
                <span className="text-xl">₹{total}</span>
              </div>
            </div>

            {/* CTA */}
            <button
              onClick={() => navigate('/checkout')}
              className="w-full py-4 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 font-black text-xs uppercase tracking-widest rounded-2xl shadow-xl flex items-center justify-center gap-2 transition-all"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {/* Trust Badges */}
            <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-center gap-2 text-[11px] text-neutral-500">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>100% Encrypted & Safe Payments</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recently Viewed */}
      <RecentlyViewed />
    </div>
  );
};
