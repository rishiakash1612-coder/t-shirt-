import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams, useParams, Link } from 'react-router-dom';
import {
  SlidersHorizontal,
  X,
  ChevronDown,
  LayoutGrid,
  List,
  Sparkles,
  ArrowUpDown,
  RotateCcw,
  Zap,
  MapPin,
  Tag
} from 'lucide-react';
import api from '../services/api';
import { Product } from '../types';
import { ProductCard } from '../components/common/ProductCard';
import { QuickViewModal } from '../components/common/QuickViewModal';

export const Shop: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const { categorySlug } = useParams<{ categorySlug?: string }>();

  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Filter States initialized from URL params
  const initialCategory = categorySlug || searchParams.get('category') || '';
  const initialGender = searchParams.get('gender') || '';
  const initialFit = searchParams.get('fit') || '';
  const initialSort = searchParams.get('sort') || 'featured';
  const initialMaxPrice = Number(searchParams.get('maxPrice')) || 699;

  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [selectedGender, setSelectedGender] = useState<string>(initialGender);
  const [selectedFit, setSelectedFit] = useState<string>(initialFit);
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [selectedGsm, setSelectedGsm] = useState<string>('');
  const [priceRange, setPriceRange] = useState<number>(initialMaxPrice);
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<string>(initialSort);

  // Sync categorySlug changes from route
  useEffect(() => {
    if (categorySlug) {
      setSelectedCategory(categorySlug);
    }
  }, [categorySlug]);

  // Sync maxPrice from search params if present
  useEffect(() => {
    const p = searchParams.get('maxPrice');
    if (p) {
      setPriceRange(Number(p));
    }
    const cat = searchParams.get('category');
    if (cat) {
      setSelectedCategory(cat);
    }
  }, [searchParams]);

  // Fetch products from backend
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        const params: Record<string, string> = {};
        if (selectedCategory) params.category = selectedCategory;
        if (selectedGender) params.gender = selectedGender;
        if (selectedFit) params.fit = selectedFit;
        if (selectedSize) params.size = selectedSize;
        if (selectedColor) params.color = selectedColor;
        if (sortBy) params.sort = sortBy;

        const res = await api.get('/products', { params });
        if (res.data.success) {
          setProducts(res.data.products);
        }
      } catch (err) {
        console.error('Failed to load shop products', err);
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, [selectedCategory, selectedGender, selectedFit, selectedSize, selectedColor, sortBy]);

  // Client-side filtering for immediate interactivity
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (p.price > priceRange) return false;
      if (inStockOnly && p.stock <= 0) return false;
      if (selectedGsm && String(p.gsm) !== selectedGsm) return false;
      return true;
    });
  }, [products, priceRange, inStockOnly, selectedGsm]);

  const clearAllFilters = () => {
    setSelectedCategory('');
    setSelectedGender('');
    setSelectedFit('');
    setSelectedSize('');
    setSelectedColor('');
    setSelectedGsm('');
    setPriceRange(699);
    setInStockOnly(false);
    setSearchParams({});
  };

  const categories = [
    { name: 'All T-Shirts (Under ₹699)', slug: '' },
    { name: 'Namma TN Drops (தமிழ்)', slug: 'tamil-drops' },
    { name: 'Under ₹299 (Zudio Special)', slug: 'under-299' },
    { name: 'Oversized Streetwear', slug: 'oversized' },
    { name: 'Graphic & Anime', slug: 'graphic' },
    { name: 'Tirupur 100% Cotton Basics', slug: 'plain' },
    { name: 'Printed & Acid Washed', slug: 'printed' }
  ];

  const fits = ['All Fits', 'Oversized Drop Shoulder', 'Boxy Fit', 'Relaxed Fit', 'Regular Fit'];
  const sizes = ['S', 'M', 'L', 'XL', 'XXL'];
  const gsmOptions = ['175', '180', '190', '200', '210', '220', '230'];
  
  const colors = [
    { name: 'Yellow', label: 'Chennai Yellow', hex: '#FBBF24' },
    { name: 'Black', label: 'Jet Black', hex: '#111827' },
    { name: 'White', label: 'Tirupur White', hex: '#F8FAFC' },
    { name: 'Maroon', label: 'Pongal Maroon', hex: '#881337' },
    { name: 'Teal', label: 'Marina Teal', hex: '#0D9488' },
    { name: 'Blue', label: 'Coimbatore Blue', hex: '#1E3A8A' },
    { name: 'Green', label: 'Temple Green', hex: '#047857' },
    { name: 'Brown', label: 'Kaapi Brown', hex: '#522A1E' },
    { name: 'Lilac', label: 'Lavender Lilac', hex: '#C084FC' },
    { name: 'Peach', label: 'Coral Peach', hex: '#FB7185' },
    { name: 'Grey', label: 'Slate Grey', hex: '#64748B' }
  ];

  const activeFiltersCount =
    (selectedCategory ? 1 : 0) +
    (selectedGender ? 1 : 0) +
    (selectedFit ? 1 : 0) +
    (selectedSize ? 1 : 0) +
    (selectedColor ? 1 : 0) +
    (selectedGsm ? 1 : 0) +
    (priceRange < 699 ? 1 : 0) +
    (inStockOnly ? 1 : 0);

  const filterSidebarContent = (
    <div className="space-y-6">
      
      {/* Price Presets Strip */}
      <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-2xl border border-amber-200 dark:border-amber-900/60">
        <p className="text-[11px] font-black uppercase tracking-wider text-amber-900 dark:text-amber-300 mb-2 flex items-center gap-1">
          <Zap className="w-3.5 h-3.5 fill-current text-amber-500" /> Zudio Budget Presets
        </p>
        <div className="grid grid-cols-2 gap-1.5">
          <button
            onClick={() => setPriceRange(249)}
            className={`py-1.5 px-2 text-xs font-bold rounded-xl border text-center transition-all ${
              priceRange === 249
                ? 'bg-amber-400 text-neutral-950 border-amber-400 shadow-sm'
                : 'bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700'
            }`}
          >
            Under ₹249
          </button>
          <button
            onClick={() => setPriceRange(299)}
            className={`py-1.5 px-2 text-xs font-bold rounded-xl border text-center transition-all ${
              priceRange === 299
                ? 'bg-amber-400 text-neutral-950 border-amber-400 shadow-sm'
                : 'bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700'
            }`}
          >
            Under ₹299
          </button>
          <button
            onClick={() => setPriceRange(399)}
            className={`py-1.5 px-2 text-xs font-bold rounded-xl border text-center transition-all ${
              priceRange === 399
                ? 'bg-amber-400 text-neutral-950 border-amber-400 shadow-sm'
                : 'bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700'
            }`}
          >
            Under ₹399
          </button>
          <button
            onClick={() => setPriceRange(499)}
            className={`py-1.5 px-2 text-xs font-bold rounded-xl border text-center transition-all ${
              priceRange === 499
                ? 'bg-amber-400 text-neutral-950 border-amber-400 shadow-sm'
                : 'bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700'
            }`}
          >
            Under ₹499
          </button>
        </div>
      </div>

      {/* Category Section */}
      <div>
        <p className="text-xs font-bold text-neutral-900 dark:text-white uppercase tracking-wider mb-3">
          Collections
        </p>
        <div className="space-y-1">
          {categories.map((cat) => (
            <button
              key={cat.slug}
              onClick={() => setSelectedCategory(cat.slug)}
              className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold transition-all flex items-center justify-between ${
                selectedCategory === cat.slug
                  ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 font-bold shadow'
                  : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
              }`}
            >
              <span>{cat.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Gender Filter */}
      <div className="pt-4 border-t border-neutral-200 dark:border-neutral-800">
        <p className="text-xs font-bold text-neutral-900 dark:text-white uppercase tracking-wider mb-3">
          Gender
        </p>
        <div className="grid grid-cols-3 gap-1.5">
          {['', 'men', 'women'].map((g) => (
            <button
              key={g}
              onClick={() => setSelectedGender(g)}
              className={`py-2 px-2 text-xs font-bold rounded-xl border text-center capitalize transition-all ${
                selectedGender === g
                  ? 'bg-neutral-900 border-neutral-900 text-white dark:bg-white dark:border-white dark:text-neutral-900'
                  : 'border-neutral-200 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 hover:border-neutral-400'
              }`}
            >
              {g ? (g === 'men' ? "Men's" : "Women's") : 'All'}
            </button>
          ))}
        </div>
      </div>

      {/* Max Price Range Slider */}
      <div className="pt-4 border-t border-neutral-200 dark:border-neutral-800">
        <div className="flex justify-between items-center mb-2 text-xs">
          <span className="font-bold text-neutral-900 dark:text-white uppercase tracking-wider">Max Price</span>
          <span className="font-mono font-bold text-amber-600 dark:text-amber-400 text-sm">₹{priceRange}</span>
        </div>
        <input
          type="range"
          min="199"
          max="699"
          step="50"
          value={priceRange}
          onChange={(e) => setPriceRange(Number(e.target.value))}
          className="w-full accent-amber-500 cursor-pointer"
        />
        <div className="flex justify-between text-[10px] text-neutral-400 mt-1">
          <span>₹199 (Lowest)</span>
          <span>₹699 (Max Cap)</span>
        </div>
      </div>

      {/* Size Filter */}
      <div className="pt-4 border-t border-neutral-200 dark:border-neutral-800">
        <p className="text-xs font-bold text-neutral-900 dark:text-white uppercase tracking-wider mb-3">
          Size
        </p>
        <div className="grid grid-cols-5 gap-1.5">
          {sizes.map((sz) => (
            <button
              key={sz}
              onClick={() => setSelectedSize(selectedSize === sz ? '' : sz)}
              className={`py-2 text-xs font-bold rounded-xl border transition-all ${
                selectedSize === sz
                  ? 'bg-neutral-900 text-white border-neutral-900 dark:bg-white dark:text-neutral-900 dark:border-white shadow'
                  : 'border-neutral-200 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 hover:border-neutral-400'
              }`}
            >
              {sz}
            </button>
          ))}
        </div>
      </div>

      {/* Color Filter */}
      <div className="pt-4 border-t border-neutral-200 dark:border-neutral-800">
        <div className="flex items-center justify-between mb-3">
          <p className="text-xs font-bold text-neutral-900 dark:text-white uppercase tracking-wider">
            Color Palette ({colors.length})
          </p>
          {selectedColor && (
            <button
              onClick={() => setSelectedColor('')}
              className="text-[10px] text-neutral-400 hover:text-neutral-900 dark:hover:text-white underline"
            >
              Reset
            </button>
          )}
        </div>
        <div className="grid grid-cols-6 gap-2">
          {colors.map((c) => (
            <button
              key={c.name}
              onClick={() => setSelectedColor(selectedColor === c.name ? '' : c.name)}
              className={`w-8 h-8 rounded-full border-2 p-0.5 flex items-center justify-center transition-all ${
                selectedColor === c.name ? 'border-neutral-900 dark:border-white scale-110 shadow-md ring-2 ring-amber-400' : 'border-transparent hover:scale-105'
              }`}
              title={c.label}
            >
              <span className="w-full h-full rounded-full border border-neutral-300 shadow-inner" style={{ backgroundColor: c.hex }} />
            </button>
          ))}
        </div>
        {selectedColor && (
          <p className="text-[11px] text-neutral-500 mt-2">
            Selected: <strong className="text-neutral-900 dark:text-white">{selectedColor}</strong>
          </p>
        )}
      </div>

      {/* GSM / Fabric Weight Filter */}
      <div className="pt-4 border-t border-neutral-200 dark:border-neutral-800">
        <p className="text-xs font-bold text-neutral-900 dark:text-white uppercase tracking-wider mb-3">
          Tirupur Cotton Weight (GSM)
        </p>
        <div className="grid grid-cols-4 gap-1.5">
          {gsmOptions.map((gsm) => (
            <button
              key={gsm}
              onClick={() => setSelectedGsm(selectedGsm === gsm ? '' : gsm)}
              className={`py-1.5 text-xs font-bold rounded-xl border text-center transition-all ${
                selectedGsm === gsm
                  ? 'bg-neutral-900 border-neutral-900 text-white dark:bg-white dark:border-white dark:text-neutral-900'
                  : 'border-neutral-200 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 hover:border-neutral-400'
              }`}
            >
              {gsm}
            </button>
          ))}
        </div>
      </div>

      {/* In-Stock Toggle */}
      <div className="pt-4 border-t border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
        <span className="text-xs font-bold text-neutral-900 dark:text-white">In-Stock Only</span>
        <button
          onClick={() => setInStockOnly(!inStockOnly)}
          className={`w-10 h-6 rounded-full transition-colors relative ${
            inStockOnly ? 'bg-emerald-500' : 'bg-neutral-300 dark:bg-neutral-700'
          }`}
        >
          <span
            className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
              inStockOnly ? 'right-1' : 'left-1'
            }`}
          />
        </button>
      </div>

      {/* Reset All */}
      {activeFiltersCount > 0 && (
        <button
          onClick={clearAllFilters}
          className="w-full py-2.5 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset All Filters ({activeFiltersCount})</span>
        </button>
      )}
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header Banner */}
      <div className="bg-neutral-950 text-white rounded-3xl p-6 sm:p-10 mb-8 border border-neutral-800 relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-400 text-neutral-950 rounded-full text-xs font-black uppercase tracking-wider">
            <Zap className="w-3.5 h-3.5 fill-current" /> ALL ITEMS UNDER ₹699
          </div>
          <h1 className="text-2xl sm:text-4xl font-black font-heading uppercase tracking-tight">
            Namma Tamil Nadu T-Shirt Hub
          </h1>
          <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
            100% Breathable Tirupur Combed Cotton • Vera Level Tamil Slang Prints • Fast 24-hr Express Delivery across Chennai, Coimbatore, Madurai & All Districts.
          </p>
        </div>
      </div>

      {/* Top Controls Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 mb-6 border-b border-neutral-200 dark:border-neutral-800">
        
        {/* Results Counter & Mobile Trigger */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsMobileFilterOpen(true)}
            className="lg:hidden flex items-center gap-2 px-4 py-2 bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 rounded-xl text-xs font-bold shadow-md"
          >
            <SlidersHorizontal className="w-4 h-4" />
            <span>Filters {activeFiltersCount > 0 ? `(${activeFiltersCount})` : ''}</span>
          </button>

          <span className="text-xs font-medium text-neutral-500">
            Showing <strong className="text-neutral-900 dark:text-white font-bold">{filteredProducts.length}</strong> styles under ₹699
          </span>
        </div>

        {/* Sort & View Mode */}
        <div className="flex items-center gap-3 self-end sm:self-auto">
          {/* Sorting Dropdown */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-neutral-400 hidden sm:inline">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 text-neutral-900 dark:text-white text-xs font-bold rounded-xl px-3 py-2 focus:outline-none"
            >
              <option value="featured">Featured / Trending</option>
              <option value="price-low">Price: Low to High (₹199 first)</option>
              <option value="price-high">Price: High to Low (₹699 first)</option>
              <option value="rating">Top Customer Rated ★</option>
              <option value="bestseller">Best Sellers</option>
              <option value="newest">New Arrivals</option>
            </select>
          </div>

          {/* Grid / List view toggle */}
          <div className="hidden sm:flex items-center bg-neutral-100 dark:bg-neutral-800 rounded-xl p-1 border border-neutral-200 dark:border-neutral-700">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'grid' ? 'bg-white dark:bg-neutral-900 shadow-sm text-neutral-900 dark:text-white' : 'text-neutral-400'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'list' ? 'bg-white dark:bg-neutral-900 shadow-sm text-neutral-900 dark:text-white' : 'text-neutral-400'
              }`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Desktop Sidebar Filters */}
        <div className="hidden lg:block lg:col-span-1">
          <div className="sticky top-28 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-3xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-neutral-100 dark:border-neutral-800">
              <span className="text-sm font-black text-neutral-900 dark:text-white font-heading uppercase tracking-wider flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4" /> Filter Catalog
              </span>
              {activeFiltersCount > 0 && (
                <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-400 text-neutral-950 rounded-full">
                  {activeFiltersCount} active
                </span>
              )}
            </div>
            {filterSidebarContent}
          </div>
        </div>

        {/* Product Grid / List */}
        <div className="lg:col-span-3">
          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="aspect-[3/4] rounded-2xl bg-neutral-100 dark:bg-neutral-800 animate-pulse" />
              ))}
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-16 bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200 dark:border-neutral-800 p-8 space-y-4">
              <div className="w-16 h-16 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center mx-auto text-neutral-400">
                <SlidersHorizontal className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-neutral-900 dark:text-white">No t-shirts match your filters</h3>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                Try widening your price range or clearing color and size selections to see all styles under ₹699.
              </p>
              <button
                onClick={clearAllFilters}
                className="px-6 py-2.5 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 text-xs font-bold rounded-xl uppercase tracking-wider"
              >
                Clear All Filters
              </button>
            </div>
          ) : (
            <div className={viewMode === 'grid' ? 'grid grid-cols-2 sm:grid-cols-3 gap-4 sm:gap-6' : 'space-y-4'}>
              {filteredProducts.map((p) => (
                <ProductCard
                  key={p.id}
                  product={p}
                  onQuickView={(prod) => setQuickViewProduct(prod)}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Mobile Slide-over Drawer Filter */}
      {isMobileFilterOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm lg:hidden flex justify-end">
          <div className="w-full max-w-xs bg-white dark:bg-neutral-900 h-full overflow-y-auto p-6 flex flex-col justify-between shadow-2xl">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-neutral-200 dark:border-neutral-800 mb-6">
                <h3 className="text-base font-bold text-neutral-900 dark:text-white font-heading uppercase">
                  Filters & Price
                </h3>
                <button
                  onClick={() => setIsMobileFilterOpen(false)}
                  className="p-1.5 text-neutral-500 hover:text-neutral-900 dark:hover:text-white rounded-lg bg-neutral-100 dark:bg-neutral-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {filterSidebarContent}
            </div>

            <div className="pt-6 mt-6 border-t border-neutral-200 dark:border-neutral-800">
              <button
                onClick={() => setIsMobileFilterOpen(false)}
                className="w-full py-3 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 font-bold text-xs uppercase tracking-widest rounded-xl shadow-lg"
              >
                View {filteredProducts.length} Results
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quick View Modal */}
      <QuickViewModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
      />
    </div>
  );
};
