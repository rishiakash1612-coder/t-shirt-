import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  CheckCircle2,
  Package,
  Truck,
  MapPin,
  ArrowRight,
  Clock,
  Sparkles,
  ShoppingBag,
  ExternalLink
} from 'lucide-react';
import api from '../services/api';
import { Order } from '../types';

export const OrderSuccessPage: React.FC = () => {
  const { orderId } = useParams<{ orderId: string }>();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrder = async () => {
      if (!orderId) return;
      try {
        const res = await api.get(`/orders/${orderId}`);
        if (res.data.success) {
          setOrder(res.data.order);
        }
      } catch (err) {
        console.error('Failed to load order', err);
      } finally {
        setLoading(false);
      }
    };
    fetchOrder();
  }, [orderId]);

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center animate-pulse">
        <div className="w-16 h-16 bg-neutral-200 dark:bg-neutral-800 rounded-full mx-auto mb-4" />
        <div className="h-6 bg-neutral-200 dark:bg-neutral-800 rounded w-1/3 mx-auto mb-2" />
        <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-1/2 mx-auto" />
      </div>
    );
  }

  const estDate = new Date();
  estDate.setDate(estDate.getDate() + 3);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
      
      {/* Success Badge Banner */}
      <div className="text-center space-y-4 mb-12">
        <div className="w-20 h-20 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto shadow-inner">
          <CheckCircle2 className="w-10 h-10" />
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold border border-emerald-200 dark:border-emerald-800">
          <Sparkles className="w-3.5 h-3.5" /> Order Placed Successfully
        </div>

        <h1 className="text-3xl sm:text-4xl font-black text-neutral-900 dark:text-white font-heading tracking-tight">
          Thank you for shopping with UrbanTee!
        </h1>

        <p className="text-xs sm:text-sm text-neutral-500 max-w-md mx-auto">
          We’ve received your order. We're already prepping your heavy cotton streetwear pieces for priority air dispatch.
        </p>
      </div>

      {/* Order Info Card */}
      <div className="bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200 dark:border-neutral-800 p-6 sm:p-8 space-y-8 shadow-sm">
        
        {/* Top order metadata */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pb-6 border-b border-neutral-100 dark:border-neutral-800 text-xs">
          <div>
            <span className="text-neutral-400 block font-medium">Order Reference</span>
            <span className="font-mono font-bold text-neutral-900 dark:text-white mt-0.5 block">{order?.orderNumber || `#${orderId}`}</span>
          </div>

          <div>
            <span className="text-neutral-400 block font-medium">Tracking Number</span>
            <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400 mt-0.5 block">{order?.trackingNumber || 'UT-EXP-99214'}</span>
          </div>

          <div>
            <span className="text-neutral-400 block font-medium">Estimated Delivery</span>
            <span className="font-bold text-neutral-900 dark:text-white mt-0.5 block">
              {estDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
            </span>
          </div>

          <div>
            <span className="text-neutral-400 block font-medium">Payment Status</span>
            <span className="inline-flex items-center gap-1 font-bold text-emerald-600 mt-0.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> {order?.paymentStatus || 'PAID'}
            </span>
          </div>
        </div>

        {/* Items List */}
        <div>
          <h2 className="text-sm font-extrabold text-neutral-900 dark:text-white uppercase tracking-wider mb-4 font-heading flex items-center gap-2">
            <Package className="w-4 h-4" /> Ordered T-Shirts
          </h2>
          <div className="divide-y divide-neutral-100 dark:divide-neutral-800">
            {order?.items.map((item, idx) => (
              <div key={idx} className="py-4 flex items-center justify-between gap-4 text-xs">
                <img src={item.image} alt={item.name} className="w-14 h-16 rounded-xl object-cover bg-neutral-100" />
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-neutral-900 dark:text-white truncate">{item.name}</p>
                  <p className="text-neutral-400 mt-0.5">Size: <strong className="text-neutral-700 dark:text-neutral-300">{item.size}</strong> • Color: {item.color}</p>
                </div>
                <div className="text-right">
                  <span className="font-bold text-neutral-900 dark:text-white block">₹{item.price * item.quantity}</span>
                  <span className="text-[11px] text-neutral-400">Qty: {item.quantity}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Shipping & Payment summary */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-6 border-t border-neutral-100 dark:border-neutral-800 text-xs">
          <div className="space-y-1">
            <p className="font-bold text-neutral-900 dark:text-white uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-neutral-400" /> Shipping Destination
            </p>
            <p className="font-bold text-neutral-800 dark:text-neutral-200">{order?.shippingAddress.name}</p>
            <p className="text-neutral-500">{order?.shippingAddress.street}</p>
            <p className="text-neutral-500">{order?.shippingAddress.city}, {order?.shippingAddress.state} - {order?.shippingAddress.zipCode}</p>
            <p className="text-neutral-500">Contact: {order?.shippingAddress.phone}</p>
          </div>

          <div className="space-y-2 bg-neutral-50 dark:bg-neutral-800/40 p-4 rounded-2xl">
            <p className="font-bold text-neutral-900 dark:text-white uppercase tracking-wider mb-2">Price Breakdown</p>
            <div className="flex justify-between text-neutral-600 dark:text-neutral-400">
              <span>Subtotal</span>
              <span>₹{order?.subtotal}</span>
            </div>
            {order?.discount && order.discount > 0 ? (
              <div className="flex justify-between text-emerald-600">
                <span>Discount</span>
                <span>-₹{order.discount}</span>
              </div>
            ) : null}
            <div className="flex justify-between text-neutral-600 dark:text-neutral-400">
              <span>Shipping</span>
              <span>{order?.deliveryFee === 0 ? 'FREE' : `₹${order?.deliveryFee}`}</span>
            </div>
            <div className="flex justify-between font-bold text-neutral-900 dark:text-white pt-2 border-t border-neutral-200 dark:border-neutral-700">
              <span>Total Paid</span>
              <span className="text-sm">₹{order?.total}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Action CTA */}
      <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
        <Link
          to="/shop"
          className="w-full sm:w-auto px-8 py-4 bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 font-bold text-xs uppercase tracking-widest rounded-2xl hover:opacity-90 shadow-xl text-center"
        >
          Continue Shopping
        </Link>
        <Link
          to="/account?tab=orders"
          className="w-full sm:w-auto px-8 py-4 bg-white dark:bg-neutral-900 text-neutral-800 dark:text-neutral-200 border border-neutral-200 dark:border-neutral-800 font-bold text-xs uppercase tracking-widest rounded-2xl hover:bg-neutral-50 dark:hover:bg-neutral-800 text-center"
        >
          View Order History
        </Link>
      </div>
    </div>
  );
};
