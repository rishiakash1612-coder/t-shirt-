import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, Send, HelpCircle, Truck, RefreshCw, Shield, Sparkles, Ruler } from 'lucide-react';
import { useToast } from '../context/ToastContext';

// 1. About Us Page
export const AboutPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 sm:py-16 space-y-12">
      <div className="text-center space-y-4">
        <span className="text-xs font-bold uppercase tracking-widest text-neutral-500">The UrbanTee Story</span>
        <h1 className="text-3xl sm:text-5xl font-black text-neutral-900 dark:text-white font-heading uppercase tracking-tight">
          Redefining Streetwear Quality in India
        </h1>
        <p className="text-sm sm:text-base text-neutral-600 dark:text-neutral-400 max-w-2xl mx-auto leading-relaxed">
          UrbanTee was born out of a single obsession: why should high-density 240 GSM oversized t-shirts cost an arm and a leg?
        </p>
      </div>

      <div className="aspect-[16/9] rounded-3xl overflow-hidden bg-neutral-900 shadow-xl">
        <img
          src="https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?auto=format&fit=crop&w=1200&q=80"
          alt="Streetwear Brand Studio"
          className="w-full h-full object-cover opacity-80"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed">
        <div className="space-y-4">
          <h2 className="text-lg font-bold text-neutral-900 dark:text-white font-heading">
            Our Fabric Engineering
          </h2>
          <p>
            Unlike fast-fashion brands that use fragile 140–160 GSM jersey cotton, every single piece from UrbanTee is spun from 100% combed long-staple French Terry or heavy cotton ranging from 220 to 280 GSM.
          </p>
          <p>
            The result? A structural boxy silhouette that holds its sharp shape on your shoulders all day without clinging or stretching out.
          </p>
        </div>

        <div className="space-y-4">
          <h2 className="text-lg font-bold text-neutral-900 dark:text-white font-heading">
            Zero-Compromise Prints
          </h2>
          <p>
            From 3D tactile puff prints to artisan acid washes, our graphics are designed in-house by underground artists and screen-printed with reactive plastisol dyes that resist over 50 machine wash cycles.
          </p>
          <p>
            Every order is carefully inspected, folded into a frosted matte zip bag, and dispatched via priority air couriers.
          </p>
        </div>
      </div>
    </div>
  );
};

// 2. Contact Page
export const ContactPage: React.FC = () => {
  const { showToast } = useToast();
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    showToast('Message sent! Our support team will get back within 24 hours.', 'success');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 sm:py-16 space-y-12">
      <div className="text-center space-y-3">
        <span className="text-xs font-bold uppercase tracking-widest text-neutral-500">Customer Support</span>
        <h1 className="text-3xl sm:text-4xl font-black text-neutral-900 dark:text-white font-heading">
          Get in Touch
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 max-w-md mx-auto">
          Have questions about sizing, your order tracking, or custom bulk drops? We're here 7 days a week.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="space-y-6 md:col-span-1">
          <div className="p-5 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-2">
            <Mail className="w-5 h-5 text-neutral-900 dark:text-white" />
            <p className="text-xs font-bold text-neutral-900 dark:text-white uppercase tracking-wider">Email Us</p>
            <p className="text-xs text-neutral-500">support@urbantee.com</p>
            <p className="text-[10px] text-neutral-400">Response within 12-24 hours</p>
          </div>

          <div className="p-5 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-2">
            <Phone className="w-5 h-5 text-neutral-900 dark:text-white" />
            <p className="text-xs font-bold text-neutral-900 dark:text-white uppercase tracking-wider">WhatsApp & Call</p>
            <p className="text-xs text-neutral-500">+91 (800) 555-0199</p>
            <p className="text-[10px] text-neutral-400">Mon - Sat: 10:00 AM - 7:00 PM</p>
          </div>

          <div className="p-5 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-2">
            <MapPin className="w-5 h-5 text-neutral-900 dark:text-white" />
            <p className="text-xs font-bold text-neutral-900 dark:text-white uppercase tracking-wider">HQ & Studio</p>
            <p className="text-xs text-neutral-500">UrbanTee Studio, 4th Block, Koramangala, Bengaluru, Karnataka 560034</p>
          </div>
        </div>

        <div className="md:col-span-2 bg-white dark:bg-neutral-900 rounded-3xl p-6 sm:p-8 border border-neutral-200 dark:border-neutral-800 shadow-sm">
          {sent ? (
            <div className="py-12 text-center space-y-3">
              <Sparkles className="w-10 h-10 text-amber-500 mx-auto" />
              <h3 className="text-lg font-bold text-neutral-900 dark:text-white">Message Received!</h3>
              <p className="text-xs text-neutral-500 max-w-xs mx-auto">
                Thank you for reaching out. A ticket has been created and we will reply to {formData.email} shortly.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">Your Name</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Rahul Sharma"
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-xs text-neutral-900 dark:text-white focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">Email Address</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="name@domain.com"
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-xs text-neutral-900 dark:text-white focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">Subject</label>
                <input
                  type="text"
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  placeholder="Order Tracking / Size Inquiry"
                  className="w-full px-4 py-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-xs text-neutral-900 dark:text-white focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">Your Message</label>
                <textarea
                  rows={5}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="How can we assist you today?"
                  className="w-full px-4 py-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-xs text-neutral-900 dark:text-white focus:outline-none"
                  required
                />
              </div>

              <button
                type="submit"
                className="px-8 py-3.5 bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 font-bold text-xs uppercase tracking-wider rounded-xl hover:opacity-90 flex items-center gap-2"
              >
                <span>Send Message</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

// 3. FAQ Page
export const FAQPage: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'What does "240 GSM" mean in t-shirt fabrics?',
      a: 'GSM stands for Grams per Square Meter. Standard t-shirts in the market are thin at 140-160 GSM. UrbanTee uses heavy 220-280 GSM combed cotton which provides a thick, premium drape that does not cling to the body and retains its boxy streetwear silhouette.'
    },
    {
      q: 'How does your oversized sizing work?',
      a: 'Our oversized tees are intentionally cut with wider chests, dropped shoulders, and relaxed sleeves. We recommend ordering your true standard size for the intended boxy aesthetic. If you prefer a tailored slim fit, size down by one size.'
    },
    {
      q: 'What is your shipping time and courier partner?',
      a: 'We dispatch all confirmed orders within 24–48 hours from our fulfillment hub. Metro cities receive delivery within 2–3 business days, while rest of India takes 4–5 business days via BlueDart, Delhivery, and Xpressbees.'
    },
    {
      q: 'What is your return & exchange policy?',
      a: 'We offer a 7-day hassle-free doorstep return and exchange policy from the date of delivery. Items must be unworn with original tags attached. Return pickups are arranged at zero cost to you.'
    },
    {
      q: 'Is Cash on Delivery (COD) available?',
      a: 'Yes! We support Cash on Delivery across 19,000+ pin codes in India. You can also pay via UPI, Credit/Debit cards, or NetBanking during checkout.'
    }
  ];

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 sm:py-16 space-y-8">
      <div className="text-center space-y-2">
        <span className="text-xs font-bold uppercase tracking-widest text-neutral-500">Knowledge Base</span>
        <h1 className="text-3xl font-black text-neutral-900 dark:text-white font-heading">
          Frequently Asked Questions
        </h1>
      </div>

      <div className="space-y-3">
        {faqs.map((faq, idx) => (
          <div
            key={idx}
            className="rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 overflow-hidden"
          >
            <button
              onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
              className="w-full p-5 text-left flex items-center justify-between text-sm font-bold text-neutral-900 dark:text-white font-heading"
            >
              <span>{faq.q}</span>
              <span className="text-lg text-neutral-400 font-normal">{openIndex === idx ? '−' : '+'}</span>
            </button>
            {openIndex === idx && (
              <div className="px-5 pb-5 text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed border-t border-neutral-100 dark:border-neutral-800 pt-3">
                {faq.a}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

// 4. Size Guide Page
export const SizeGuidePage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 sm:py-16 space-y-10">
      <div className="text-center space-y-2">
        <span className="text-xs font-bold uppercase tracking-widest text-neutral-500">Fit Guide</span>
        <h1 className="text-3xl sm:text-4xl font-black text-neutral-900 dark:text-white font-heading">
          UrbanTee Measurement Chart
        </h1>
        <p className="text-xs text-neutral-500">Find your ideal fit across our oversized, relaxed, and tailored cuts.</p>
      </div>

      <div className="bg-white dark:bg-neutral-900 rounded-3xl p-6 sm:p-8 border border-neutral-200 dark:border-neutral-800 space-y-6">
        <h2 className="text-base font-extrabold text-neutral-900 dark:text-white font-heading">
          Oversized Streetwear Fit (Inches)
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-100 dark:bg-neutral-800 font-bold text-neutral-900 dark:text-white">
              <tr>
                <th className="p-3">Size</th>
                <th className="p-3">Chest (in)</th>
                <th className="p-3">Length (in)</th>
                <th className="p-3">Shoulder (in)</th>
                <th className="p-3">Sleeve (in)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200 dark:divide-neutral-800">
              <tr><td className="p-3 font-bold">S</td><td className="p-3">40"</td><td className="p-3">28"</td><td className="p-3">20"</td><td className="p-3">8.5"</td></tr>
              <tr><td className="p-3 font-bold">M</td><td className="p-3">42"</td><td className="p-3">29"</td><td className="p-3">21"</td><td className="p-3">9.0"</td></tr>
              <tr><td className="p-3 font-bold">L</td><td className="p-3">44"</td><td className="p-3">30"</td><td className="p-3">22"</td><td className="p-3">9.5"</td></tr>
              <tr><td className="p-3 font-bold">XL</td><td className="p-3">46"</td><td className="p-3">31"</td><td className="p-3">23"</td><td className="p-3">10.0"</td></tr>
              <tr><td className="p-3 font-bold">XXL</td><td className="p-3">48"</td><td className="p-3">32"</td><td className="p-3">24"</td><td className="p-3">10.5"</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// 5. Shipping & Returns Info Page
export const ShippingReturnsPage: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 sm:py-16 space-y-8">
      <h1 className="text-3xl font-black text-neutral-900 dark:text-white font-heading">
        Shipping & Return Policies
      </h1>
      <div className="space-y-6 text-xs sm:text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
        <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-2">
          <h2 className="text-base font-bold text-neutral-900 dark:text-white">Shipping Rates & Timelines</h2>
          <p>Orders above ₹999 qualify for FREE Express Air Shipping. For orders below ₹999, a flat shipping charge of ₹79 is applied at checkout.</p>
          <p>Dispatch happens within 24–48 hours of order confirmation. Delivery tracking numbers are sent via SMS and Email.</p>
        </div>

        <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-2">
          <h2 className="text-base font-bold text-neutral-900 dark:text-white">7-Day Return Policy</h2>
          <p>We want you to love your pieces. If you aren't completely satisfied with the fit or style, initiate a return from your Account page within 7 days of delivery.</p>
          <p>Refunds are initiated back to the original payment source or UPI ID within 48 hours of item verification.</p>
        </div>
      </div>
    </div>
  );
};
