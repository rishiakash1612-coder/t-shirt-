export interface Address {
  id?: string;
  name: string;
  phone: string;
  street: string;
  city: string;
  state: string;
  pincode?: string;
  zipCode?: string;
  country?: string;
  landmark?: string;
  isDefault?: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  passwordHash?: string;
  role: 'USER' | 'ADMIN';
  addresses?: Address[];
  createdAt?: string;
}

export interface ColorOption {
  name: string;
  hex: string;
}

export interface Review {
  id: string;
  productId?: string;
  userId?: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  title: string;
  comment: string;
  verified?: boolean;
  verifiedPurchase?: boolean;
  createdAt?: string;
  date?: string;
  likes?: number;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  originalPrice: number;
  discount: number;
  category: string;
  gender: 'men' | 'women' | 'unisex';
  sizes: ('S' | 'M' | 'L' | 'XL' | 'XXL' | string)[];
  colors: ColorOption[];
  images: string[];
  stock: number;
  rating: number;
  reviewCount: number;
  featured?: boolean;
  bestSeller?: boolean;
  newArrival?: boolean;
  onSale?: boolean;
  sku: string;
  fabric: string;
  gsm: number;
  fit: string;
  care?: string[];
  soldCount?: number;
  tags?: string[];
  reviews?: Review[];
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  image: string;
  description: string;
  productCount?: number;
}

export interface CartItem {
  id: string;
  productId: string;
  name: string;
  slug: string;
  image: string;
  size: string;
  color: string;
  quantity: number;
  price: number;
  originalPrice: number;
  stock: number;
}

export interface OrderItem {
  productId: string;
  name: string;
  slug?: string;
  image: string;
  size: string;
  color: string;
  quantity: number;
  price: number;
}

export interface OrderTimeline {
  status: string;
  date: string;
  note: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  userId: string;
  userName?: string;
  userEmail?: string;
  userPhone?: string;
  items: OrderItem[];
  shippingAddress: Address;
  deliveryOption?: {
    type: 'standard' | 'express';
    name: string;
    fee: number;
    estimatedDays: string;
  };
  paymentMethod: 'COD' | 'UPI' | 'CARD' | 'NETBANKING' | string;
  paymentStatus: 'PENDING' | 'PAID' | 'FAILED' | 'Pending' | 'Completed' | string;
  subtotal: number;
  discount?: number;
  couponCode?: string;
  deliveryFee: number;
  tax: number;
  total: number;
  status: 'PENDING' | 'PROCESSING' | 'SHIPPED' | 'DELIVERED' | 'CANCELLED' | 'Processing' | 'Confirmed' | 'Shipped' | 'Out for Delivery' | 'Delivered' | 'Cancelled' | string;
  trackingNumber?: string;
  trackingTimeline?: OrderTimeline[];
  estimatedDeliveryDate?: string;
  createdAt: string;
}

export interface Coupon {
  id: string;
  code: string;
  discountPercent: number;
  minOrderValue?: number;
  minOrder?: number;
  maxDiscountAmount?: number;
  maxDiscount?: number;
  expiresAt?: string;
  expiryDate?: string;
  maxUsage?: number;
  usedCount?: number;
  active?: boolean;
}

export interface FilterState {
  search?: string;
  category?: string;
  gender?: string;
  sizes: string[];
  colors: string[];
  minPrice: number;
  maxPrice: number;
  minRating: number;
  sort: 'newest' | 'price-low' | 'price-high' | 'best-selling' | 'rating';
  inStockOnly?: boolean;
}

export interface AdminAnalytics {
  totalSales: number;
  totalOrders: number;
  totalCustomers: number;
  totalProducts: number;
  pendingOrders: number;
  lowStockProducts: number;
  dailySales: { date: string; sales: number; orders: number }[];
  monthlySales: { month: string; sales: number; orders: number }[];
  categorySales: { category: string; count: number; revenue: number }[];
  topProducts: { id: string; name: string; sold: number; revenue: number; image: string }[];
}
