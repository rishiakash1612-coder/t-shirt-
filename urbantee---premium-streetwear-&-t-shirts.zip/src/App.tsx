import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import { ToastProvider } from './context/ToastContext';
import { AuthProvider } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import { WishlistProvider } from './context/WishlistContext';
import { CompareProvider } from './context/CompareContext';

// Layout Components
import { TopBanner } from './components/layout/TopBanner';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { CartDrawer } from './components/common/CartDrawer';
import { CompareModal } from './components/common/CompareModal';
import { ScrollToTop } from './components/common/ScrollToTop';

// Pages
import { Home } from './pages/Home';
import { Shop } from './pages/Shop';
import { ProductDetails } from './pages/ProductDetails';
import { CartPage } from './pages/CartPage';
import { WishlistPage } from './pages/WishlistPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrderSuccessPage } from './pages/OrderSuccessPage';
import { SearchResultsPage } from './pages/SearchResultsPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { ForgotPasswordPage } from './pages/ForgotPasswordPage';
import { UserProfilePage } from './pages/UserProfilePage';
import { AdminDashboard } from './pages/AdminDashboard';
import {
  AboutPage,
  ContactPage,
  FAQPage,
  SizeGuidePage,
  ShippingReturnsPage
} from './pages/StaticPages';

const NotFound: React.FC = () => (
  <div className="max-w-md mx-auto px-4 py-24 text-center">
    <h1 className="text-6xl font-black text-neutral-900 dark:text-white font-heading">404</h1>
    <p className="text-sm font-bold text-neutral-800 dark:text-neutral-200 mt-2 mb-1">Page Not Found</p>
    <p className="text-xs text-neutral-500 mb-6">The streetwear drop you are looking for does not exist or has been relocated.</p>
    <Link
      to="/"
      className="px-6 py-3 bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg inline-block"
    >
      Return Home
    </Link>
  </div>
);

export default function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <AuthProvider>
          <CartProvider>
            <WishlistProvider>
              <CompareProvider>
                <Router>
                  <ScrollToTop />
                  <div className="min-h-screen flex flex-col bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-50 transition-colors duration-200">
                    <TopBanner />
                    <Navbar />

                    <main className="flex-1">
                      <Routes>
                        <Route path="/" element={<Home />} />
                        <Route path="/shop" element={<Shop />} />
                        <Route path="/category/:category" element={<Shop />} />
                        <Route path="/product/:slug" element={<ProductDetails />} />
                        <Route path="/cart" element={<CartPage />} />
                        <Route path="/wishlist" element={<WishlistPage />} />
                        <Route path="/checkout" element={<CheckoutPage />} />
                        <Route path="/order-success/:orderId" element={<OrderSuccessPage />} />
                        <Route path="/search" element={<SearchResultsPage />} />
                        <Route path="/login" element={<LoginPage />} />
                        <Route path="/register" element={<RegisterPage />} />
                        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
                        <Route path="/account" element={<UserProfilePage />} />
                        <Route path="/admin" element={<AdminDashboard />} />
                        <Route path="/about" element={<AboutPage />} />
                        <Route path="/contact" element={<ContactPage />} />
                        <Route path="/faq" element={<FAQPage />} />
                        <Route path="/size-guide" element={<SizeGuidePage />} />
                        <Route path="/shipping-returns" element={<ShippingReturnsPage />} />
                        <Route path="*" element={<NotFound />} />
                      </Routes>
                    </main>

                    <Footer />
                    <CartDrawer />
                    <CompareModal />
                  </div>
                </Router>
              </CompareProvider>
            </WishlistProvider>
          </CartProvider>
        </AuthProvider>
      </ToastProvider>
    </ThemeProvider>
  );
}
