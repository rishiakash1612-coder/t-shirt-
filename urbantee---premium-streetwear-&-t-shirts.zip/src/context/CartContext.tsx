import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import api from '../services/api';
import { CartItem } from '../types';
import { useToast } from './ToastContext';
import { useAuth } from './AuthContext';

interface AppliedCoupon {
  code: string;
  discountPercent: number;
  discountAmount: number;
}

interface CartContextType {
  items: CartItem[];
  itemCount: number;
  subtotal: number;
  discount: number;
  deliveryFee: number;
  tax: number;
  total: number;
  freeShippingThreshold: number;
  amountNeededForFreeShipping: number;
  isCartDrawerOpen: boolean;
  appliedCoupon: AppliedCoupon | null;
  loading: boolean;
  addToCart: (productId: string, size: string, color: string, quantity?: number) => Promise<boolean>;
  updateQuantity: (cartItemId: string, quantity: number) => Promise<void>;
  removeFromCart: (cartItemId: string) => Promise<void>;
  clearCart: () => Promise<void>;
  openCartDrawer: () => void;
  closeCartDrawer: () => void;
  toggleCartDrawer: () => void;
  applyCoupon: (code: string) => Promise<boolean>;
  removeCoupon: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState(false);
  const [appliedCoupon, setAppliedCoupon] = useState<AppliedCoupon | null>(null);
  const [loading, setLoading] = useState(false);
  const { showToast } = useToast();
  const { user } = useAuth();

  const freeShippingThreshold = 999;

  const fetchCart = useCallback(async () => {
    try {
      const res = await api.get('/cart');
      if (res.data.success) {
        setItems(res.data.items);
      }
    } catch {
      // Ignore initial error
    }
  }, []);

  useEffect(() => {
    fetchCart();
  }, [user, fetchCart]);

  const addToCart = async (productId: string, size: string, color: string, quantity = 1): Promise<boolean> => {
    try {
      setLoading(true);
      const res = await api.post('/cart', { productId, size, color, quantity });
      if (res.data.success) {
        setItems(res.data.items);
        showToast('Added to bag! 🛍️', 'success');
        setIsCartDrawerOpen(true);
        return true;
      }
      showToast(res.data.message || 'Failed to add item', 'error');
      return false;
    } catch (err: any) {
      showToast(err.response?.data?.message || 'Could not add to cart', 'error');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const updateQuantity = async (cartItemId: string, quantity: number) => {
    try {
      const res = await api.put(`/cart/${cartItemId}`, { quantity });
      if (res.data.success) {
        setItems(res.data.items);
      }
    } catch (err: any) {
      showToast(err.response?.data?.message || 'Could not update quantity', 'error');
    }
  };

  const removeFromCart = async (cartItemId: string) => {
    try {
      const res = await api.delete(`/cart/${cartItemId}`);
      if (res.data.success) {
        setItems(res.data.items);
        showToast('Item removed from cart', 'info');
      }
    } catch {
      showToast('Could not remove item', 'error');
    }
  };

  const clearCart = async () => {
    try {
      await api.delete('/cart/clear');
      setItems([]);
      setAppliedCoupon(null);
    } catch {
      setItems([]);
    }
  };

  const applyCoupon = async (code: string): Promise<boolean> => {
    try {
      const res = await api.post('/coupons/validate', {
        code,
        orderAmount: subtotal
      });
      if (res.data.success) {
        setAppliedCoupon(res.data.coupon);
        showToast(res.data.message, 'success');
        return true;
      }
      showToast(res.data.message || 'Invalid coupon', 'error');
      return false;
    } catch (err: any) {
      showToast(err.response?.data?.message || 'Invalid coupon code', 'error');
      return false;
    }
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    showToast('Coupon removed', 'info');
  };

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discount = appliedCoupon ? appliedCoupon.discountAmount : 0;
  const deliveryFee = subtotal >= freeShippingThreshold || subtotal === 0 ? 0 : 79;
  const tax = Math.round((subtotal - discount) * 0.05); // 5% GST
  const total = Math.max(0, subtotal - discount + deliveryFee + tax);
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
  const amountNeededForFreeShipping = Math.max(0, freeShippingThreshold - subtotal);

  return (
    <CartContext.Provider
      value={{
        items,
        itemCount,
        subtotal,
        discount,
        deliveryFee,
        tax,
        total,
        freeShippingThreshold,
        amountNeededForFreeShipping,
        isCartDrawerOpen,
        appliedCoupon,
        loading,
        addToCart,
        updateQuantity,
        removeFromCart,
        clearCart,
        openCartDrawer: () => setIsCartDrawerOpen(true),
        closeCartDrawer: () => setIsCartDrawerOpen(false),
        toggleCartDrawer: () => setIsCartDrawerOpen((prev) => !prev),
        applyCoupon,
        removeCoupon
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
