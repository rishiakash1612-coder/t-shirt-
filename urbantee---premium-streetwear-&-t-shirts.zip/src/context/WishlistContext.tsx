import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import api from '../services/api';
import { Product } from '../types';
import { useToast } from './ToastContext';
import { useAuth } from './AuthContext';

interface WishlistContextType {
  wishlistIds: string[];
  wishlistProducts: Product[];
  toggleWishlist: (productId: string) => Promise<boolean>;
  isInWishlist: (productId: string) => boolean;
  clearWishlist: () => Promise<void>;
  loading: boolean;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export const WishlistProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [wishlistIds, setWishlistIds] = useState<string[]>([]);
  const [wishlistProducts, setWishlistProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const { showToast } = useToast();
  const { user } = useAuth();

  const fetchWishlist = useCallback(async () => {
    try {
      const res = await api.get('/wishlist');
      if (res.data.success) {
        setWishlistIds(res.data.productIds || []);
        setWishlistProducts(res.data.products || []);
      }
    } catch {
      // Ignore initial error
    }
  }, []);

  useEffect(() => {
    fetchWishlist();
  }, [user, fetchWishlist]);

  const toggleWishlist = async (productId: string): Promise<boolean> => {
    try {
      setLoading(true);
      const res = await api.post('/wishlist', { productId });
      if (res.data.success) {
        setWishlistIds(res.data.productIds);
        setWishlistProducts(res.data.products);
        showToast(res.data.message, 'success');
        return true;
      }
      return false;
    } catch {
      showToast('Could not update wishlist', 'error');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const clearWishlist = async () => {
    try {
      await api.delete('/wishlist/clear');
      setWishlistIds([]);
      setWishlistProducts([]);
      showToast('Wishlist cleared', 'info');
    } catch {
      // Ignore
    }
  };

  const isInWishlist = (productId: string): boolean => {
    return wishlistIds.includes(productId);
  };

  return (
    <WishlistContext.Provider
      value={{
        wishlistIds,
        wishlistProducts,
        toggleWishlist,
        isInWishlist,
        clearWishlist,
        loading
      }}
    >
      {children}
    </WishlistContext.Provider>
  );
};

export const useWishlist = () => {
  const context = useContext(WishlistContext);
  if (!context) {
    throw new Error('useWishlist must be used within a WishlistProvider');
  }
  return context;
};
