import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import api from '../services/api';
import { User } from '../types';
import { useToast } from './ToastContext';

interface AuthContextType {
  user: User | null;
  token: string | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, phone: string, password: string) => Promise<boolean>;
  logout: () => void;
  updateProfile: (data: { name?: string; phone?: string }) => Promise<boolean>;
  addAddress: (addressData: any) => Promise<boolean>;
  deleteAddress: (addressId: string) => Promise<boolean>;
  loginDemoAdmin: () => Promise<void>;
  loginDemoUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('urbantee_token'));
  const [loading, setLoading] = useState<boolean>(true);
  const { showToast } = useToast();

  const fetchCurrentUser = useCallback(async () => {
    try {
      const res = await api.get('/auth/me');
      if (res.data.success) {
        setUser(res.data.user);
      } else {
        setUser(null);
        setToken(null);
        localStorage.removeItem('urbantee_token');
      }
    } catch {
      setUser(null);
      setToken(null);
      localStorage.removeItem('urbantee_token');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (token) {
      fetchCurrentUser();
    } else {
      setLoading(false);
    }
  }, [token, fetchCurrentUser]);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      const res = await api.post('/auth/login', { email, password });
      if (res.data.success) {
        localStorage.setItem('urbantee_token', res.data.token);
        setToken(res.data.token);
        setUser(res.data.user);
        showToast(`Welcome back, ${res.data.user.name}!`, 'success');
        return true;
      }
      showToast(res.data.message || 'Login failed', 'error');
      return false;
    } catch (err: any) {
      const msg = err.response?.data?.message || 'Invalid email or password';
      showToast(msg, 'error');
      return false;
    }
  };

  const register = async (name: string, email: string, phone: string, password: string): Promise<boolean> => {
    try {
      const res = await api.post('/auth/register', { name, email, phone, password });
      if (res.data.success) {
        localStorage.setItem('urbantee_token', res.data.token);
        setToken(res.data.token);
        setUser(res.data.user);
        showToast('Registration successful! Welcome to UrbanTee.', 'success');
        return true;
      }
      showToast(res.data.message || 'Registration failed', 'error');
      return false;
    } catch (err: any) {
      const msg = err.response?.data?.message || 'Registration failed';
      showToast(msg, 'error');
      return false;
    }
  };

  const logout = () => {
    localStorage.removeItem('urbantee_token');
    setToken(null);
    setUser(null);
    showToast('Logged out successfully', 'info');
  };

  const updateProfile = async (data: { name?: string; phone?: string }): Promise<boolean> => {
    try {
      const res = await api.put('/auth/profile', data);
      if (res.data.success) {
        setUser(res.data.user);
        showToast('Profile updated successfully', 'success');
        return true;
      }
      return false;
    } catch {
      showToast('Failed to update profile', 'error');
      return false;
    }
  };

  const addAddress = async (addressData: any): Promise<boolean> => {
    try {
      const res = await api.post('/auth/addresses', addressData);
      if (res.data.success) {
        setUser(res.data.user);
        showToast('Address saved successfully', 'success');
        return true;
      }
      return false;
    } catch {
      showToast('Failed to save address', 'error');
      return false;
    }
  };

  const deleteAddress = async (addressId: string): Promise<boolean> => {
    try {
      const res = await api.delete(`/auth/addresses/${addressId}`);
      if (res.data.success) {
        setUser(res.data.user);
        showToast('Address removed', 'info');
        return true;
      }
      return false;
    } catch {
      showToast('Failed to remove address', 'error');
      return false;
    }
  };

  const loginDemoAdmin = async () => {
    await login('admin@urbantee.com', 'admin123');
  };

  const loginDemoUser = async () => {
    await login('alex@urbantee.com', 'user123');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        login,
        register,
        logout,
        updateProfile,
        addAddress,
        deleteAddress,
        loginDemoAdmin,
        loginDemoUser
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
