import bcrypt from 'bcryptjs';
import { Product, Category, User, Order, Review, Coupon, CartItem } from '../src/types.js';

// Password hash generator helper
const hashPass = (pw: string) => bcrypt.hashSync(pw, 10);

export class UrbanTeeDatabase {
  users: User[] = [];
  products: Product[] = [];
  categories: Category[] = [];
  orders: Order[] = [];
  reviews: Review[] = [];
  coupons: Coupon[] = [];
  carts: Map<string, CartItem[]> = new Map(); // key is userId or guestSessionId
  wishlists: Map<string, string[]> = new Map(); // key is userId -> productIds array

  constructor() {
    this.seedInitialData();
  }

  seedInitialData() {
    // 1. Initial Users (Admin & Tamil Nadu Demo User)
    this.users = [
      {
        id: 'usr_admin',
        name: 'UrbanTee TN Admin',
        email: 'admin@urbantee.com',
        phone: '+91 98401 23456',
        passwordHash: hashPass('admin123'),
        role: 'ADMIN',
        addresses: [
          {
            id: 'addr_admin_1',
            name: 'UrbanTee Tirupur Central Hub',
            phone: '+91 98401 23456',
            street: '14/B Textile Valley Road, Avinashi Main',
            city: 'Tirupur',
            state: 'Tamil Nadu',
            pincode: '641604',
            isDefault: true
          }
        ],
        createdAt: '2026-01-01T00:00:00.000Z'
      },
      {
        id: 'usr_karthik',
        name: 'Karthik Subramanian',
        email: 'karthik@urbantee.com',
        phone: '+91 94441 98765',
        passwordHash: hashPass('user123'),
        role: 'USER',
        addresses: [
          {
            id: 'addr_karthik_1',
            name: 'Karthik Subramanian',
            phone: '+91 94441 98765',
            street: 'Flat 302, Green Meadows, 2nd Avenue, Anna Nagar',
            city: 'Chennai',
            state: 'Tamil Nadu',
            pincode: '600040',
            isDefault: true
          },
          {
            id: 'addr_karthik_2',
            name: 'Karthik Sub (Coimbatore Home)',
            phone: '+91 94441 98765',
            street: '45, West Club Road, RS Puram',
            city: 'Coimbatore',
            state: 'Tamil Nadu',
            pincode: '641002',
            isDefault: false
          }
        ],
        createdAt: '2026-02-15T10:30:00.000Z'
      }
    ];

    // 2. Initial Categories tailored for Tamil Nadu & Zudio-style budget
    this.categories = [
      {
        id: 'cat_tamil_drops',
        name: 'Namma TN Drops (தமிழ்)',
        slug: 'tamil-drops',
        image: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=800&q=80',
        description: 'Vera Level Tamil slogans, Marina vibes, Kollywood cinema aesthetics & cultural pop art tees.'
      },
      {
        id: 'cat_under299',
        name: 'Under ₹299 (Zudio Price)',
        slug: 'under-299',
        image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80',
        description: 'Unbeatable budget pocket friendly tees made from pure 100% Tirupur single jersey combed cotton.'
      },
      {
        id: 'cat_oversized',
        name: 'Oversized Streetwear',
        slug: 'oversized',
        image: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=800&q=80',
        description: 'Drop shoulder boxy streetwear t-shirts engineered for hot weather airflow & maximum drip.'
      },
      {
        id: 'cat_graphic',
        name: 'Graphic & Anime Tees',
        slug: 'graphic',
        image: 'https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?auto=format&fit=crop&w=800&q=80',
        description: 'High-density breathable screen prints, cyber aesthetic, and retro typography.'
      },
      {
        id: 'cat_plain',
        name: 'Tirupur Pure Cotton Basics',
        slug: 'plain',
        image: 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=800&q=80',
        description: '100% Super-combed breathable cotton basics engineered for Tamil Nadu climate and humidity.'
      },
      {
        id: 'cat_printed',
        name: 'Printed & Acid Washed',
        slug: 'printed',
        image: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=800&q=80',
        description: 'Subtle tie-dye, mineral washes, tropical prints, and artisan retro washes under ₹699.'
      }
    ];

    // 3. Complete Catalogue of 28+ Products - ALL UNDER ₹699 with Multiple Images & Vibrant Colors
    this.products = [
      {
        id: 'prod_1',
        name: 'Vera Level (வேற லெவல்) Oversized Street Tee',
        slug: 'vera-level-oversized-street-tee',
        description: 'The ultimate Tamil slang statement tee. Crafted from 100% Tirupur combed single jersey cotton (210 GSM) that stays ultra-breathable even in peak Chennai humid heat. Features bold Tamil typography with high-density puff rubber print on the reverse.',
        price: 399,
        originalPrice: 899,
        discount: 56,
        category: 'tamil-drops',
        gender: 'unisex',
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: [
          { name: 'Chennai Super Yellow', hex: '#FBBF24' },
          { name: 'Marina Midnight Black', hex: '#18181B' },
          { name: 'Tirupur Cotton White', hex: '#F8FAFC' },
          { name: 'Pongal Terracotta Maroon', hex: '#881337' },
          { name: 'Teal Bay Ocean', hex: '#0D9488' },
          { name: 'Ooty Lavender Mist', hex: '#C084FC' }
        ],
        images: [
          'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 45,
        rating: 4.9,
        reviewCount: 128,
        featured: true,
        bestSeller: true,
        newArrival: false,
        onSale: true,
        sku: 'TN-DROP-001',
        fabric: '100% Tirupur Combed Cotton',
        gsm: 210,
        fit: 'Oversized Drop Shoulder',
        care: ['Machine wash cold inside out', 'Dry in shade for vibrant colors', 'Do not iron directly on print', 'Do not bleach'],
        soldCount: 1420,
        tags: ['tamil', 'oversized', 'zudio-price', 'under499'],
        createdAt: '2026-01-10T12:00:00.000Z'
      },
      {
        id: 'prod_2',
        name: 'Namma Chennai Marina Breeze Sunset Tee',
        slug: 'namma-chennai-marina-breeze-sunset-tee',
        description: 'Tribute to Madras evenings, Lighthouse horizon, and the cool Bay of Bengal breeze. Screen-printed with breathable non-sweat eco ink on 100% pre-shrunk cotton. Guaranteed comfort along the beach promenade or college campus.',
        price: 349,
        originalPrice: 799,
        discount: 56,
        category: 'tamil-drops',
        gender: 'unisex',
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: [
          { name: 'Marina Sky Blue', hex: '#38BDF8' },
          { name: 'Sunset Ochre Orange', hex: '#EA580C' },
          { name: 'Jet Black', hex: '#111827' },
          { name: 'Off White', hex: '#F1F5F9' },
          { name: 'Coral Rose', hex: '#FB7185' },
          { name: 'Sage Green', hex: '#84CC16' }
        ],
        images: [
          'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 38,
        rating: 4.8,
        reviewCount: 94,
        featured: true,
        bestSeller: true,
        newArrival: false,
        onSale: true,
        sku: 'TN-CHN-002',
        fabric: '100% Bio-Washed Combed Cotton',
        gsm: 190,
        fit: 'Relaxed Fit',
        care: ['Gentle cycle 30°C', 'Wash with like colors', 'Low iron'],
        soldCount: 980,
        tags: ['chennai', 'graphic', 'under499'],
        createdAt: '2026-01-14T15:30:00.000Z'
      },
      {
        id: 'prod_3',
        name: 'Tirupur Everyday Breathable Plain Tee (Pack Choice)',
        slug: 'tirupur-everyday-breathable-plain-tee',
        description: 'Direct from the textile capital of India — Tirupur! Unbeatable Zudio-beating value at just ₹249. Feather-soft 180 GSM combed cotton with zero itchy tags, reinforced ribbed collar, and anti-shrinkage technology.',
        price: 249,
        originalPrice: 499,
        discount: 50,
        category: 'under-299',
        gender: 'unisex',
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: [
          { name: 'Pure Chalk White', hex: '#FFFFFF' },
          { name: 'Pitch Charcoal Black', hex: '#1E293B' },
          { name: 'Madurai Temple Green', hex: '#047857' },
          { name: 'Coimbatore Navy Blue', hex: '#1E3A8A' },
          { name: 'Salem Slate Grey', hex: '#64748B' },
          { name: 'Beige Sand Khaki', hex: '#D7C4A5' },
          { name: 'Olive Green', hex: '#4D7C0F' },
          { name: 'Dusty Crimson Red', hex: '#991B1B' }
        ],
        images: [
          'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1503342394128-c104d54dba01?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 120,
        rating: 4.8,
        reviewCount: 310,
        featured: true,
        bestSeller: true,
        newArrival: false,
        onSale: true,
        sku: 'TN-PLN-003',
        fabric: '100% Ring Spun Tirupur Cotton',
        gsm: 180,
        fit: 'Regular Fit',
        care: ['Machine wash warm', 'Air dry in shade', 'Warm iron'],
        soldCount: 3200,
        tags: ['plain', 'under299', 'zudio-price', 'tirupur'],
        createdAt: '2026-01-05T09:00:00.000Z'
      },
      {
        id: 'prod_4',
        name: 'Kollywood Cinephile Mass Hero Vintage Graphic Tee',
        slug: 'kollywood-cinephile-mass-hero-vintage-tee',
        description: 'For every hardcore Tamil cinema lover! Retro halftone 90s cinema poster aesthetic printed with durable discharge ink that never cracks. Lightweight 200 GSM cotton fit for first-day-first-show madness.',
        price: 449,
        originalPrice: 999,
        discount: 55,
        category: 'tamil-drops',
        gender: 'unisex',
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: [
          { name: 'Vintage Washed Black', hex: '#27272A' },
          { name: 'Maroon Velvet', hex: '#701A75' },
          { name: 'Ochre Yellow', hex: '#D97706' },
          { name: 'Bottle Green', hex: '#064E3B' },
          { name: 'Charcoal Grey', hex: '#4B5563' }
        ],
        images: [
          'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 35,
        rating: 4.9,
        reviewCount: 88,
        featured: true,
        bestSeller: true,
        newArrival: true,
        onSale: true,
        sku: 'TN-CIN-004',
        fabric: '100% Single Jersey Cotton',
        gsm: 200,
        fit: 'Boxy Relaxed Fit',
        care: ['Cold wash', 'Do not tumble dry', 'Iron inside out'],
        soldCount: 750,
        tags: ['cinema', 'kollywood', 'graphic', 'under499'],
        createdAt: '2026-02-01T11:00:00.000Z'
      },
      {
        id: 'prod_5',
        name: 'Filter Kaapi (ஃபில்டர் காபி) Morning Vibes Graphic Tee',
        slug: 'filter-kaapi-morning-vibes-graphic-tee',
        description: 'Brewed with pure Tamil pride! Features an artistic brass davarah-tumbler illustration and fresh roasted coffee bean graphic accents. Made with bio-washed lightweight cotton that keeps you fresh all day.',
        price: 299,
        originalPrice: 699,
        discount: 57,
        category: 'under-299',
        gender: 'unisex',
        sizes: ['S', 'M', 'L', 'XL'],
        colors: [
          { name: 'Kaapi Decoction Brown', hex: '#522A1E' },
          { name: 'Fresh Milk Cream', hex: '#FEF3C7' },
          { name: 'Onyx Black', hex: '#111827' },
          { name: 'Peach Coral', hex: '#FDA4AF' },
          { name: 'Sage Mint', hex: '#A7F3D0' }
        ],
        images: [
          'https://images.unsplash.com/photo-1503342394128-c104d54dba01?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 50,
        rating: 4.8,
        reviewCount: 76,
        featured: false,
        bestSeller: true,
        newArrival: true,
        onSale: true,
        sku: 'TN-KAP-005',
        fabric: '100% Combed Airy Cotton',
        gsm: 180,
        fit: 'Regular Fit',
        care: ['Machine wash cold', 'Line dry in shade'],
        soldCount: 890,
        tags: ['under299', 'graphic', 'zudio-price'],
        createdAt: '2026-02-05T14:20:00.000Z'
      },
      {
        id: 'prod_6',
        name: 'Madurai Veeran & Meenakshi Heritage Art Tee',
        slug: 'madurai-veeran-heritage-art-tee',
        description: 'Intricate architectural temple line sketch celebrating the cultural glory of Madurai and South Tamil Nadu. Premium water-based discharge print on 220 GSM structured combed cotton.',
        price: 499,
        originalPrice: 1099,
        discount: 55,
        category: 'tamil-drops',
        gender: 'men',
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: [
          { name: 'Deep Temple Crimson', hex: '#881337' },
          { name: 'Madurai Mustard Ochre', hex: '#B45309' },
          { name: 'Pitch Black', hex: '#0F172A' },
          { name: 'Royal Emerald', hex: '#065F46' },
          { name: 'Ash Heather Grey', hex: '#6B7280' }
        ],
        images: [
          'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 28,
        rating: 4.9,
        reviewCount: 62,
        featured: true,
        bestSeller: false,
        newArrival: true,
        onSale: true,
        sku: 'TN-MDU-006',
        fabric: '100% Super-Combed Cotton',
        gsm: 220,
        fit: 'Relaxed Fit',
        care: ['Dry flat in shade', 'Gentle cold wash', 'Warm iron'],
        soldCount: 420,
        tags: ['madurai', 'heritage', 'tamil'],
        createdAt: '2026-01-20T16:00:00.000Z'
      },
      {
        id: 'prod_7',
        name: 'Vetti Pechu (வெட்டி பேச்சு) Minimalist Pocket Tee',
        slug: 'vetti-pechu-minimalist-pocket-tee',
        description: 'Clean chest pocket with subtle Tamil script embroidery "வெட்டி பேச்சு No More" and Gen Z street vibes. Tailored from soft breathable cotton jersey for hanging out at the local tea shop with friends.',
        price: 299,
        originalPrice: 649,
        discount: 54,
        category: 'under-299',
        gender: 'unisex',
        sizes: ['S', 'M', 'L', 'XL'],
        colors: [
          { name: 'Tirupur White', hex: '#F8FAFC' },
          { name: 'Carbon Black', hex: '#18181B' },
          { name: 'Olive Green', hex: '#3F6212' },
          { name: 'Coimbatore Blue', hex: '#1D4ED8' },
          { name: 'Dusty Peach', hex: '#F43F5E' },
          { name: 'Khaki Beige', hex: '#D4D4D8' }
        ],
        images: [
          'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1503342394128-c104d54dba01?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 65,
        rating: 4.7,
        reviewCount: 81,
        featured: false,
        bestSeller: true,
        newArrival: false,
        onSale: true,
        sku: 'TN-VET-007',
        fabric: '100% Breathable Cotton',
        gsm: 190,
        fit: 'Regular Fit',
        care: ['Machine wash cold', 'Wash with like colors'],
        soldCount: 930,
        tags: ['under299', 'tamil', 'zudio-price'],
        createdAt: '2026-02-12T10:00:00.000Z'
      },
      {
        id: 'prod_8',
        name: 'Jallikattu Bull Spirit Tamil Oversized Drop Tee',
        slug: 'jallikattu-bull-spirit-oversized-tee',
        description: 'Raw power and traditional valour captured in a modern neo-grunge back graphic illustration. Drop shoulder boxy fit with ribbed crew collar and anti-pilling fabric.',
        price: 549,
        originalPrice: 1199,
        discount: 54,
        category: 'oversized',
        gender: 'unisex',
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: [
          { name: 'Smoke Acid Charcoal', hex: '#334155' },
          { name: 'Pitch Black', hex: '#09090B' },
          { name: 'Madurai Ochre', hex: '#CA8A04' },
          { name: 'Deep Crimson', hex: '#991B1B' },
          { name: 'Forest Moss', hex: '#166534' }
        ],
        images: [
          'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 32,
        rating: 4.9,
        reviewCount: 115,
        featured: true,
        bestSeller: true,
        newArrival: true,
        onSale: true,
        sku: 'TN-JAL-008',
        fabric: '100% Heavy Combed Cotton',
        gsm: 220,
        fit: 'Oversized Boxy Fit',
        care: ['Machine wash delicate', 'Hang dry in shade', 'Iron on low'],
        soldCount: 1120,
        tags: ['jallikattu', 'oversized', 'tamil'],
        createdAt: '2026-02-18T13:00:00.000Z'
      },
      {
        id: 'prod_9',
        name: 'Coimbatore Breezy Summer Cotton Waffle Tee',
        slug: 'coimbatore-breezy-summer-cotton-waffle-tee',
        description: 'Engineered for cool comfort. Micro-waffle knit texture gives incredible airflow and a rich tactile feel without feeling heavy in humid weather.',
        price: 399,
        originalPrice: 849,
        discount: 53,
        category: 'plain',
        gender: 'men',
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: [
          { name: 'Oatmeal Khaki', hex: '#E5E5E5' },
          { name: 'Sky Blue', hex: '#60A5FA' },
          { name: 'Navy Midnight', hex: '#1E3A8A' },
          { name: 'Mint Green', hex: '#34D399' },
          { name: 'Coral Rose', hex: '#FB7185' },
          { name: 'Charcoal Black', hex: '#1F2937' }
        ],
        images: [
          'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1503342394128-c104d54dba01?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 40,
        rating: 4.8,
        reviewCount: 58,
        featured: false,
        bestSeller: true,
        newArrival: true,
        onSale: true,
        sku: 'TN-CBE-009',
        fabric: '95% Combed Cotton, 5% Lycra Rib',
        gsm: 195,
        fit: 'Relaxed Fit',
        care: ['Machine wash cold', 'Lay flat to dry'],
        soldCount: 620,
        tags: ['coimbatore', 'plain', 'under499'],
        createdAt: '2026-02-10T08:30:00.000Z'
      },
      {
        id: 'prod_10',
        name: 'Singam (சிங்கம்) Bold Tamil Typography Graphic Tee',
        slug: 'singam-bold-tamil-typography-graphic-tee',
        description: 'Roar in style with modern dynamic Tamil typography and metallic foil lion motif. Soft bio-washed single jersey cotton ensures supreme comfort for college, casuals, and clubbing.',
        price: 349,
        originalPrice: 799,
        discount: 56,
        category: 'graphic',
        gender: 'men',
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: [
          { name: 'Jet Black with Gold Foil', hex: '#171717' },
          { name: 'Royal Chennai Yellow', hex: '#F59E0B' },
          { name: 'Pure White', hex: '#FFFFFF' },
          { name: 'Maroon Ruby', hex: '#831843' },
          { name: 'Emerald Forest', hex: '#047857' }
        ],
        images: [
          'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 55,
        rating: 4.9,
        reviewCount: 92,
        featured: false,
        bestSeller: true,
        newArrival: false,
        onSale: true,
        sku: 'TN-SNG-010',
        fabric: '100% Bio-Washed Cotton',
        gsm: 200,
        fit: 'Regular Fit',
        care: ['Wash cold inside out', 'Do not iron on gold print'],
        soldCount: 880,
        tags: ['singam', 'tamil', 'under499'],
        createdAt: '2026-01-25T11:45:00.000Z'
      },
      {
        id: 'prod_11',
        name: 'Cyber Anirudh Wave Neon Synth Graphic Tee',
        slug: 'cyber-anirudh-wave-neon-synth-tee',
        description: 'Electric musical frequencies and Tamil youth soundwave vibes! Printed with radiant ultraviolet neon colors that glow under party blacklights.',
        price: 499,
        originalPrice: 999,
        discount: 50,
        category: 'graphic',
        gender: 'unisex',
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: [
          { name: 'Deep Space Black', hex: '#09090B' },
          { name: 'Cyber Purple Tint', hex: '#581C87' },
          { name: 'Electric Teal', hex: '#0F766E' },
          { name: 'Neon Blue', hex: '#1D4ED8' }
        ],
        images: [
          'https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 22,
        rating: 4.9,
        reviewCount: 67,
        featured: true,
        bestSeller: false,
        newArrival: true,
        onSale: true,
        sku: 'TN-ANI-011',
        fabric: '100% Combed Compact Cotton',
        gsm: 210,
        fit: 'Relaxed Fit',
        care: ['Machine wash cold', 'Iron inside out'],
        soldCount: 460,
        tags: ['anime', 'music', 'graphic', 'under699'],
        createdAt: '2026-02-20T18:00:00.000Z'
      },
      {
        id: 'prod_12',
        name: 'Basic Crew Neck Budget Tee (₹199 Crazy Deal)',
        slug: 'basic-crew-neck-budget-tee-199',
        description: 'The lowest price guarantee in India! Direct factory price from Tirupur mills. 100% combed pure cotton, pre-shrunk, breathable, light and soft.',
        price: 199,
        originalPrice: 399,
        discount: 50,
        category: 'under-299',
        gender: 'unisex',
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: [
          { name: 'Snow White', hex: '#FFFFFF' },
          { name: 'Midnight Black', hex: '#111827' },
          { name: 'Royal Blue', hex: '#2563EB' },
          { name: 'Vibrant Yellow', hex: '#EAB308' },
          { name: 'Olive Green', hex: '#65A30D' },
          { name: 'Tomato Red', hex: '#DC2626' },
          { name: 'Heather Grey', hex: '#9CA3AF' },
          { name: 'Pastel Lilac', hex: '#E9D5FF' }
        ],
        images: [
          'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1503342394128-c104d54dba01?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 200,
        rating: 4.7,
        reviewCount: 410,
        featured: true,
        bestSeller: true,
        newArrival: false,
        onSale: true,
        sku: 'TN-CRZ-012',
        fabric: '100% Pure Tirupur Cotton',
        gsm: 175,
        fit: 'Regular Fit',
        care: ['Machine wash warm', 'Tumble dry low'],
        soldCount: 4800,
        tags: ['under299', 'deal199', 'zudio-price', 'plain'],
        createdAt: '2026-01-08T10:00:00.000Z'
      },
      {
        id: 'prod_13',
        name: 'East Coast Road (ECR) Night Ride Acid Wash Tee',
        slug: 'east-coast-road-ecr-night-ride-acid-wash-tee',
        description: 'Cruising down ECR under coastal night stars. Hand-treated artisan acid wash gives each tee a distinctive weathered look. Dropped boxy shoulders with reinforced double-stitched sleeves.',
        price: 599,
        originalPrice: 1299,
        discount: 54,
        category: 'printed',
        gender: 'unisex',
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: [
          { name: 'Washed Ash Charcoal', hex: '#374151' },
          { name: 'Faded Plum Wine', hex: '#581C87' },
          { name: 'Vintage Moss Green', hex: '#365314' },
          { name: 'Faded Denim Blue', hex: '#1E3A8A' }
        ],
        images: [
          'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 25,
        rating: 4.9,
        reviewCount: 54,
        featured: true,
        bestSeller: false,
        newArrival: true,
        onSale: true,
        sku: 'TN-ECR-013',
        fabric: '100% Acid-Washed Combed Cotton',
        gsm: 230,
        fit: 'Oversized Boxy Fit',
        care: ['Wash cold separately', 'Do not bleach', 'Dry inside out in shade'],
        soldCount: 390,
        tags: ['acid-wash', 'printed', 'oversized', 'under699'],
        createdAt: '2026-02-22T17:10:00.000Z'
      },
      {
        id: 'prod_14',
        name: 'Kavithai (கவிதை) Aesthetic Tamil Script Minimal Tee',
        slug: 'kavithai-aesthetic-tamil-script-minimal-tee',
        description: 'Poetic typography celebrating the elegance of classical and modern Tamil verse. Printed with soft-feel eco inks on silky silicone-washed combed cotton.',
        price: 349,
        originalPrice: 749,
        discount: 53,
        category: 'tamil-drops',
        gender: 'women',
        sizes: ['S', 'M', 'L', 'XL'],
        colors: [
          { name: 'Pastel Lilac Purple', hex: '#D8B4FE' },
          { name: 'Blush Coral Peach', hex: '#FECDD3' },
          { name: 'Warm Ecru Linen', hex: '#F5F5F4' },
          { name: 'Matcha Sage Green', hex: '#BBF7D0' },
          { name: 'Pitch Black', hex: '#171717' }
        ],
        images: [
          'https://images.unsplash.com/photo-1503342394128-c104d54dba01?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 42,
        rating: 4.8,
        reviewCount: 49,
        featured: false,
        bestSeller: true,
        newArrival: true,
        onSale: true,
        sku: 'TN-KAV-014',
        fabric: '100% Silicone-Enzyme Washed Cotton',
        gsm: 185,
        fit: 'Regular Fit',
        care: ['Machine wash delicate', 'Air dry in shade'],
        soldCount: 520,
        tags: ['tamil', 'minimal', 'women', 'under499'],
        createdAt: '2026-02-14T14:00:00.000Z'
      },
      {
        id: 'prod_15',
        name: 'Whistle Podu (விசில் போடு) Street Oversized Drop Tee',
        slug: 'whistle-podu-street-oversized-drop-tee',
        description: 'Bring the electrifying Chepauk stadium roar wherever you go! Iconic vibrant yellow streetwear fit with dropped shoulders and thick 1-inch non-sag neck collar.',
        price: 499,
        originalPrice: 1099,
        discount: 55,
        category: 'oversized',
        gender: 'unisex',
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: [
          { name: 'Chepauk Stadium Yellow', hex: '#EAB308' },
          { name: 'Onyx Black', hex: '#18181B' },
          { name: 'Marina Blue', hex: '#0284C7' },
          { name: 'Snow White', hex: '#FAFAFA' }
        ],
        images: [
          'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 30,
        rating: 4.9,
        reviewCount: 140,
        featured: true,
        bestSeller: true,
        newArrival: false,
        onSale: true,
        sku: 'TN-WHS-015',
        fabric: '100% Combed Terry Cotton',
        gsm: 215,
        fit: 'Oversized Fit',
        care: ['Wash cold inside out', 'Do not tumble dry'],
        soldCount: 1680,
        tags: ['chennai', 'oversized', 'csk', 'under499'],
        createdAt: '2026-01-18T09:15:00.000Z'
      },
      {
        id: 'prod_16',
        name: 'Anime Tamil Cyber Samurai Graphic Tee',
        slug: 'anime-tamil-cyber-samurai-graphic-tee',
        description: 'Fusion of Neo-Tokyo mecha visuals with bold Tamil aesthetic. High-density puff print gives a distinct 3D tactile feel on 200 GSM ring-spun cotton.',
        price: 449,
        originalPrice: 949,
        discount: 53,
        category: 'graphic',
        gender: 'unisex',
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: [
          { name: 'Shadow Black', hex: '#111827' },
          { name: 'Cyber Crimson Slate', hex: '#881337' },
          { name: 'Teal Emerald', hex: '#0F766E' },
          { name: 'Chalk White', hex: '#F8FAFC' }
        ],
        images: [
          'https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 36,
        rating: 4.9,
        reviewCount: 78,
        featured: true,
        bestSeller: true,
        newArrival: true,
        onSale: true,
        sku: 'TN-ANM-016',
        fabric: '100% Combed Cotton',
        gsm: 200,
        fit: 'Relaxed Fit',
        care: ['Machine wash cold', 'Iron inside out'],
        soldCount: 640,
        tags: ['anime', 'graphic', 'under499'],
        createdAt: '2026-02-15T12:00:00.000Z'
      },
      {
        id: 'prod_17',
        name: 'Pongal Terracotta Festival Maroon Boxy Tee',
        slug: 'pongal-terracotta-festival-maroon-boxy-tee',
        description: 'Rich earthy terracotta maroon dye inspired by traditional mud pots, sugarcane motifs, and harvest celebrations. Premium silicone washed for an ultra-velvety feel.',
        price: 399,
        originalPrice: 899,
        discount: 56,
        category: 'tamil-drops',
        gender: 'unisex',
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: [
          { name: 'Terracotta Maroon', hex: '#881337' },
          { name: 'Turmeric Yellow', hex: '#F59E0B' },
          { name: 'Paddy Green', hex: '#15803D' },
          { name: 'Clay Sand', hex: '#E7E5E4' }
        ],
        images: [
          'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 26,
        rating: 4.8,
        reviewCount: 45,
        featured: false,
        bestSeller: false,
        newArrival: true,
        onSale: true,
        sku: 'TN-PGL-017',
        fabric: '100% Bio-Washed Combed Cotton',
        gsm: 205,
        fit: 'Boxy Fit',
        care: ['Machine wash cold with like colors', 'Dry in shade'],
        soldCount: 380,
        tags: ['pongal', 'maroon', 'tamil', 'under499'],
        createdAt: '2026-02-16T10:00:00.000Z'
      },
      {
        id: 'prod_18',
        name: 'Tirupur Breathable Combed Polo T-Shirt',
        slug: 'tirupur-breathable-combed-polo-tshirt',
        description: 'Smart casual polo tailored with honeycomb pique knit cotton. Sturdy ribbed collar with 2-button placket and side slit vents for supreme summer airflow.',
        price: 499,
        originalPrice: 1099,
        discount: 55,
        category: 'plain',
        gender: 'men',
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: [
          { name: 'Navy Blue', hex: '#1E3A8A' },
          { name: 'Burgundy Wine', hex: '#881337' },
          { name: 'Pure White', hex: '#FFFFFF' },
          { name: 'Slate Grey', hex: '#4B5563' },
          { name: 'Forest Green', hex: '#065F46' },
          { name: 'Jet Black', hex: '#111827' }
        ],
        images: [
          'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80',
          'https://images.unsplash.com/photo-1503342394128-c104d54dba01?auto=format&fit=crop&w=1000&q=80'
        ],
        stock: 35,
        rating: 4.8,
        reviewCount: 66,
        featured: false,
        bestSeller: true,
        newArrival: false,
        onSale: true,
        sku: 'TN-POL-018',
        fabric: '100% Pique Combed Cotton',
        gsm: 220,
        fit: 'Regular Fit',
        care: ['Warm machine wash', 'Line dry', 'Warm iron'],
        soldCount: 590,
        tags: ['polo', 'tirupur', 'under699'],
        createdAt: '2026-01-22T14:00:00.000Z'
      }
    ];

    // 4. Real Customer Reviews from Tamil Nadu Shoppers
    this.reviews = [
      {
        id: 'rev_1',
        productId: 'prod_1',
        userId: 'usr_karthik',
        userName: 'Karthik Subramanian (Chennai)',
        rating: 5,
        title: 'வேற லெவல் குவாலிட்டி! Real Zudio-beating price',
        comment: 'I ordered the Vera Level tee in Chennai Super Yellow. The Tirupur 210 GSM cotton is super soft and breathable in the humid Chennai climate. Delivered to Anna Nagar within 24 hours!',
        verifiedPurchase: true,
        date: '2026-02-22T14:30:00.000Z',
        likes: 28
      },
      {
        id: 'rev_2',
        productId: 'prod_3',
        userId: 'usr_divya',
        userName: 'Divya Ramesh (Coimbatore)',
        rating: 5,
        title: 'Only ₹249 for pure 100% Tirupur cotton!',
        comment: 'I bought 4 plain basic tees for daily office casual wear. You cannot get this quality even in Zudio or Max for ₹249. No shrinking after wash and collar doesn\'t stretch.',
        verifiedPurchase: true,
        date: '2026-02-24T09:15:00.000Z',
        likes: 19
      },
      {
        id: 'rev_3',
        productId: 'prod_2',
        userId: 'usr_muthu',
        userName: 'Muthukumar Pandian (Madurai)',
        rating: 5,
        title: 'Namma Marina sunset artwork looks incredible',
        comment: 'Color is super vibrant and the screen print has zero plastic rubbery feeling. Very light on the body and keeps you cool.',
        verifiedPurchase: true,
        date: '2026-02-20T16:00:00.000Z',
        likes: 15
      },
      {
        id: 'rev_4',
        productId: 'prod_5',
        userId: 'usr_soundar',
        userName: 'Soundararajan K (Tirupur)',
        rating: 5,
        title: 'Tirupur native approved! Filter Kaapi tee is fire 🔥',
        comment: 'Being from Tirupur textile zone, I know cotton quality. This 180 GSM single jersey is genuine export grade. Best value under ₹299.',
        verifiedPurchase: true,
        date: '2026-02-18T11:20:00.000Z',
        likes: 22
      },
      {
        id: 'rev_5',
        productId: 'prod_15',
        userId: 'usr_anitha',
        userName: 'Anitha Selvam (Trichy)',
        rating: 5,
        title: 'Whistle Podu yellow is bright and high quality',
        comment: 'The oversized drop shoulder fit is so aesthetic! Wore it to college and got so many compliments. Cash on delivery was seamless.',
        verifiedPurchase: true,
        date: '2026-02-26T18:40:00.000Z',
        likes: 11
      }
    ];

    // 5. Budget Friendly Coupons for Tamil Nadu Customers
    this.coupons = [
      {
        id: 'cbn_vanakkam50',
        code: 'VANAKKAM50',
        discountPercent: 15,
        minOrder: 399,
        maxDiscount: 150,
        expiryDate: '2027-12-31T23:59:59.000Z',
        maxUsage: 10000,
        usedCount: 840,
        active: true
      },
      {
        id: 'cbn_zudio30',
        code: 'ZUDIO30',
        discountPercent: 30,
        minOrder: 599,
        maxDiscount: 300,
        expiryDate: '2027-12-31T23:59:59.000Z',
        maxUsage: 5000,
        usedCount: 1240,
        active: true
      },
      {
        id: 'cbn_nammatn',
        code: 'NAMMATN',
        discountPercent: 20,
        minOrder: 499,
        maxDiscount: 200,
        expiryDate: '2027-12-31T23:59:59.000Z',
        maxUsage: 5000,
        usedCount: 630,
        active: true
      },
      {
        id: 'cbn_firstdrop',
        code: 'FIRSTDROP',
        discountPercent: 10,
        minOrder: 199,
        maxDiscount: 100,
        expiryDate: '2027-12-31T23:59:59.000Z',
        maxUsage: 20000,
        usedCount: 2450,
        active: true
      }
    ];

    // 6. Pre-seeded Orders with Tamil Nadu Addresses
    this.orders = [
      {
        id: 'ord_1001',
        orderNumber: 'UT-TN-2026-4481',
        userId: 'usr_karthik',
        userName: 'Karthik Subramanian',
        userEmail: 'karthik@urbantee.com',
        userPhone: '+91 94441 98765',
        items: [
          {
            productId: 'prod_1',
            name: 'Vera Level (வேற லெவல்) Oversized Street Tee',
            slug: 'vera-level-oversized-street-tee',
            image: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=600&q=80',
            size: 'L',
            color: 'Chennai Super Yellow',
            quantity: 1,
            price: 399
          },
          {
            productId: 'prod_3',
            name: 'Tirupur Everyday Breathable Plain Tee (Pack Choice)',
            slug: 'tirupur-everyday-breathable-plain-tee',
            image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=600&q=80',
            size: 'L',
            color: 'Pure Chalk White',
            quantity: 1,
            price: 249
          }
        ],
        shippingAddress: {
          id: 'addr_karthik_1',
          name: 'Karthik Subramanian',
          phone: '+91 94441 98765',
          street: 'Flat 302, Green Meadows, 2nd Avenue, Anna Nagar',
          city: 'Chennai',
          state: 'Tamil Nadu',
          pincode: '600040',
          isDefault: true
        },
        deliveryOption: {
          type: 'standard',
          name: 'TN Express Air Shipping (24-48 Hours)',
          fee: 0,
          estimatedDays: '1-2 Days across Tamil Nadu'
        },
        paymentMethod: 'UPI',
        paymentStatus: 'Completed',
        subtotal: 648,
        discount: 100,
        couponCode: 'VANAKKAM50',
        deliveryFee: 0,
        tax: 27,
        total: 575,
        status: 'Delivered',
        trackingTimeline: [
          { status: 'Processing', date: '2026-02-23T09:00:00.000Z', note: 'Order received at Tirupur Warehouse' },
          { status: 'Confirmed', date: '2026-02-23T11:30:00.000Z', note: 'Quality check verified and packed' },
          { status: 'Shipped', date: '2026-02-23T16:00:00.000Z', note: 'Dispatched via BlueDart TN Express (AWB: TN984124)' },
          { status: 'Out for Delivery', date: '2026-02-24T08:30:00.000Z', note: 'Courier out for delivery at Anna Nagar hub' },
          { status: 'Delivered', date: '2026-02-24T14:15:00.000Z', note: 'Delivered safely to recipient in Chennai' }
        ],
        estimatedDeliveryDate: '2026-02-24',
        createdAt: '2026-02-23T08:45:00.000Z'
      }
    ];

    // Seed Wishlist for Karthik
    this.wishlists.set('usr_karthik', ['prod_1', 'prod_2', 'prod_15']);
  }
}

export const db = new UrbanTeeDatabase();
