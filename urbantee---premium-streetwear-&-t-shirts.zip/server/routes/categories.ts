import { Router } from 'express';
import { db } from '../db.js';
import { authenticateToken, requireAdmin, AuthenticatedRequest } from '../middleware/auth.js';
import { Category } from '../../src/types.js';

const router = Router();

// GET /api/categories
router.get('/', (req, res) => {
  const catsWithCount = db.categories.map(c => {
    const count = db.products.filter(p => p.category.toLowerCase() === c.slug.toLowerCase()).length;
    return { ...c, productCount: count };
  });
  res.json({ success: true, categories: catsWithCount });
});

// POST /api/categories (Admin)
router.post('/', authenticateToken, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { name, image, description } = req.body;
  if (!name) {
    res.status(400).json({ success: false, message: 'Category name is required' });
    return;
  }

  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  const existing = db.categories.find(c => c.slug === slug);
  if (existing) {
    res.status(400).json({ success: false, message: 'Category slug already exists' });
    return;
  }

  const newCat: Category = {
    id: `cat_${Date.now()}`,
    name: name.trim(),
    slug,
    image: image || 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80',
    description: description || ''
  };

  db.categories.push(newCat);
  res.status(201).json({ success: true, message: 'Category created', category: newCat });
});

// PUT /api/categories/:id (Admin)
router.put('/:id', authenticateToken, requireAdmin, (req: AuthenticatedRequest, res) => {
  const cat = db.categories.find(c => c.id === req.params.id);
  if (!cat) {
    res.status(404).json({ success: false, message: 'Category not found' });
    return;
  }

  const { name, image, description } = req.body;
  if (name) cat.name = name.trim();
  if (image) cat.image = image;
  if (description) cat.description = description;

  res.json({ success: true, message: 'Category updated', category: cat });
});

// DELETE /api/categories/:id (Admin)
router.delete('/:id', authenticateToken, requireAdmin, (req: AuthenticatedRequest, res) => {
  const idx = db.categories.findIndex(c => c.id === req.params.id);
  if (idx === -1) {
    res.status(404).json({ success: false, message: 'Category not found' });
    return;
  }

  const removed = db.categories.splice(idx, 1)[0];
  res.json({ success: true, message: `Category '${removed.name}' removed` });
});

export default router;
