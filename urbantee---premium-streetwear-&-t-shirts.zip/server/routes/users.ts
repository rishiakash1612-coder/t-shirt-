import { Router } from 'express';
import { db } from '../db.js';
import { authenticateToken, requireAdmin, AuthenticatedRequest } from '../middleware/auth.js';

const router = Router();

// GET /api/users (Admin only)
router.get('/', authenticateToken, requireAdmin, (req: AuthenticatedRequest, res) => {
  const safeUsers = db.users.map(u => {
    const { passwordHash: _, ...safe } = u;
    const userOrders = db.orders.filter(o => o.userId === u.id);
    const totalSpent = userOrders.reduce((sum, o) => sum + o.total, 0);
    return {
      ...safe,
      ordersCount: userOrders.length,
      totalSpent
    };
  });
  res.json({ success: true, users: safeUsers });
});

export default router;
