import { Router } from 'express';
import { db } from '../db.js';
import { optionalAuth, AuthenticatedRequest } from '../middleware/auth.js';

const router = Router();

function getWishlistKey(req: AuthenticatedRequest): string {
  if (req.user) return req.user.id;
  const guestHeader = req.headers['x-guest-session-id'];
  if (guestHeader && typeof guestHeader === 'string') return guestHeader;
  return 'guest_default_session';
}

// GET /api/wishlist
router.get('/', optionalAuth, (req: AuthenticatedRequest, res) => {
  const key = getWishlistKey(req);
  const productIds = db.wishlists.get(key) || [];
  const products = db.products.filter(p => productIds.includes(p.id));
  res.json({ success: true, productIds, products });
});

// POST /api/wishlist
router.post('/', optionalAuth, (req: AuthenticatedRequest, res) => {
  const key = getWishlistKey(req);
  const { productId } = req.body;

  if (!productId) {
    res.status(400).json({ success: false, message: 'Product ID required' });
    return;
  }

  let list = db.wishlists.get(key) || [];
  if (!list.includes(productId)) {
    list.push(productId);
  } else {
    list = list.filter(id => id !== productId);
  }

  db.wishlists.set(key, list);
  const products = db.products.filter(p => list.includes(p.id));
  res.json({
    success: true,
    message: list.includes(productId) ? 'Added to wishlist' : 'Removed from wishlist',
    productIds: list,
    products
  });
});

// DELETE /api/wishlist/:productId
router.delete('/:productId', optionalAuth, (req: AuthenticatedRequest, res) => {
  const key = getWishlistKey(req);
  const { productId } = req.params;

  let list = db.wishlists.get(key) || [];
  if (productId === 'clear') {
    list = [];
  } else {
    list = list.filter(id => id !== productId);
  }

  db.wishlists.set(key, list);
  const products = db.products.filter(p => list.includes(p.id));
  res.json({ success: true, message: 'Wishlist updated', productIds: list, products });
});

export default router;
