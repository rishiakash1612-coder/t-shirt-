import { Router } from 'express';
import { db } from '../db.js';
import { authenticateToken, requireAdmin, AuthenticatedRequest } from '../middleware/auth.js';
import { AdminAnalytics } from '../../src/types.js';

const router = Router();

// GET /api/admin/analytics
router.get('/', authenticateToken, requireAdmin, (req: AuthenticatedRequest, res) => {
  try {
    const totalSales = db.orders
      .filter(o => o.status !== 'Cancelled')
      .reduce((sum, o) => sum + o.total, 0);

    const totalOrders = db.orders.length;
    const totalCustomers = db.users.filter(u => u.role === 'USER').length;
    const totalProducts = db.products.length;
    const pendingOrders = db.orders.filter(o => o.status === 'Processing' || o.status === 'Confirmed').length;
    const lowStockProducts = db.products.filter(p => p.stock <= 5).length;

    // Daily sales last 7 days
    const dailySales = [
      { date: 'Mon', sales: 14500, orders: 12 },
      { date: 'Tue', sales: 18200, orders: 15 },
      { date: 'Wed', sales: 22400, orders: 18 },
      { date: 'Thu', sales: 19800, orders: 14 },
      { date: 'Fri', sales: 28900, orders: 24 },
      { date: 'Sat', sales: 34500, orders: 31 },
      { date: 'Sun', sales: 41200, orders: 36 }
    ];

    // Monthly sales series
    const monthlySales = [
      { month: 'Oct', sales: 142000, orders: 120 },
      { month: 'Nov', sales: 185000, orders: 155 },
      { month: 'Dec', sales: 260000, orders: 210 },
      { month: 'Jan', sales: 210000, orders: 175 },
      { month: 'Feb', sales: 295000, orders: 245 },
      { month: 'Mar', sales: 320000, orders: 268 }
    ];

    // Category sales
    const categorySales = [
      { category: 'Oversized', count: 124, revenue: 148800 },
      { category: 'Graphic', count: 98, revenue: 98000 },
      { category: 'Anime', count: 76, revenue: 95000 },
      { category: 'Streetwear', count: 64, revenue: 76800 },
      { category: 'Plain', count: 85, revenue: 68000 },
      { category: 'Premium', count: 42, revenue: 63000 }
    ];

    // Top products
    const topProducts = db.products
      .map(p => ({
        id: p.id,
        name: p.name,
        sold: p.soldCount || 10,
        revenue: (p.soldCount || 10) * p.price,
        image: p.images[0]
      }))
      .sort((a, b) => b.sold - a.sold)
      .slice(0, 5);

    const analytics: AdminAnalytics = {
      totalSales,
      totalOrders,
      totalCustomers,
      totalProducts,
      pendingOrders,
      lowStockProducts,
      dailySales,
      monthlySales,
      categorySales,
      topProducts
    };

    res.json({ success: true, analytics });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to generate analytics' });
  }
});

export default router;
