import { Router } from 'express';
import { db } from '../db.js';
import { authenticateToken, requireAdmin, AuthenticatedRequest } from '../middleware/auth.js';
import { Review } from '../../src/types.js';

const router = Router();

// GET /api/reviews/:productId
router.get('/:productId', (req, res) => {
  const reviews = db.reviews.filter(r => r.productId === req.params.productId);
  res.json({ success: true, reviews });
});

// GET /api/reviews (All reviews for admin moderation)
router.get('/', authenticateToken, requireAdmin, (req: AuthenticatedRequest, res) => {
  res.json({ success: true, reviews: db.reviews });
});

// POST /api/reviews
router.post('/', authenticateToken, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const { productId, rating, title, comment } = req.body;

  if (!productId || !rating || !comment) {
    res.status(400).json({ success: false, message: 'Rating and comment are required.' });
    return;
  }

  const product = db.products.find(p => p.id === productId);
  if (!product) {
    res.status(404).json({ success: false, message: 'Product not found.' });
    return;
  }

  // Check if verified buyer
  const hasPurchased = db.orders.some(
    o => o.userId === user.id && o.items.some(i => i.productId === productId)
  );

  const newReview: Review = {
    id: `rev_${Date.now()}`,
    productId,
    userId: user.id,
    userName: user.name,
    rating: Math.min(5, Math.max(1, Number(rating))),
    title: title || 'Verified Customer Review',
    comment: comment.trim(),
    verifiedPurchase: hasPurchased,
    date: new Date().toISOString(),
    likes: 0
  };

  db.reviews.unshift(newReview);

  // Recalculate product rating
  const allProductReviews = db.reviews.filter(r => r.productId === productId);
  const totalScore = allProductReviews.reduce((sum, r) => sum + r.rating, 0);
  product.rating = Number((totalScore / allProductReviews.length).toFixed(1));
  product.reviewCount = allProductReviews.length;

  res.status(201).json({ success: true, message: 'Review submitted successfully!', review: newReview });
});

// DELETE /api/reviews/:id (Admin moderation)
router.delete('/:id', authenticateToken, requireAdmin, (req: AuthenticatedRequest, res) => {
  const idx = db.reviews.findIndex(r => r.id === req.params.id);
  if (idx === -1) {
    res.status(404).json({ success: false, message: 'Review not found' });
    return;
  }

  const [removed] = db.reviews.splice(idx, 1);

  // Recalculate rating for product
  const product = db.products.find(p => p.id === removed.productId);
  if (product) {
    const allProductReviews = db.reviews.filter(r => r.productId === product.id);
    if (allProductReviews.length > 0) {
      const totalScore = allProductReviews.reduce((sum, r) => sum + r.rating, 0);
      product.rating = Number((totalScore / allProductReviews.length).toFixed(1));
      product.reviewCount = allProductReviews.length;
    } else {
      product.reviewCount = 0;
    }
  }

  res.json({ success: true, message: 'Review deleted successfully' });
});

export default router;
