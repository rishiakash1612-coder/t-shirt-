import { Router } from 'express';
import { db } from '../db.js';
import { authenticateToken, requireAdmin, AuthenticatedRequest } from '../middleware/auth.js';
import { Coupon } from '../../src/types.js';

const router = Router();

// POST /api/coupons/validate
router.post('/validate', (req, res) => {
  const { code, orderAmount } = req.body;

  if (!code) {
    res.status(400).json({ success: false, message: 'Please enter a coupon code' });
    return;
  }

  const coupon = db.coupons.find(c => c.code.toUpperCase() === code.trim().toUpperCase());

  if (!coupon || !coupon.active) {
    res.status(404).json({ success: false, message: 'Invalid or expired coupon code.' });
    return;
  }

  const now = new Date();
  if (new Date(coupon.expiryDate) < now) {
    res.status(400).json({ success: false, message: 'This coupon has expired.' });
    return;
  }

  if (coupon.usedCount >= coupon.maxUsage) {
    res.status(400).json({ success: false, message: 'Coupon usage limit reached.' });
    return;
  }

  const subtotal = Number(orderAmount) || 0;
  if (subtotal < coupon.minOrder) {
    res.status(400).json({
      success: false,
      message: `Minimum order amount of ₹${coupon.minOrder} required for coupon ${coupon.code}.`
    });
    return;
  }

  const calculatedDiscount = Math.round((subtotal * coupon.discountPercent) / 100);
  const finalDiscount = Math.min(calculatedDiscount, coupon.maxDiscount);

  res.json({
    success: true,
    message: `Coupon '${coupon.code}' applied! You saved ₹${finalDiscount}.`,
    coupon: {
      code: coupon.code,
      discountPercent: coupon.discountPercent,
      discountAmount: finalDiscount
    }
  });
});

// GET /api/coupons (Admin only or public active promo banners)
router.get('/', (req, res) => {
  res.json({ success: true, coupons: db.coupons });
});

// POST /api/coupons (Admin only)
router.post('/', authenticateToken, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { code, discountPercent, minOrder, maxDiscount, expiryDate, maxUsage } = req.body;

  if (!code || !discountPercent) {
    res.status(400).json({ success: false, message: 'Code and discount percentage are required' });
    return;
  }

  const existing = db.coupons.find(c => c.code.toUpperCase() === code.trim().toUpperCase());
  if (existing) {
    res.status(400).json({ success: false, message: 'Coupon code already exists' });
    return;
  }

  const newCoupon: Coupon = {
    id: `cbn_${Date.now()}`,
    code: code.trim().toUpperCase(),
    discountPercent: Number(discountPercent),
    minOrder: Number(minOrder) || 0,
    maxDiscount: Number(maxDiscount) || 1000,
    expiryDate: expiryDate || '2027-12-31T23:59:59.000Z',
    maxUsage: Number(maxUsage) || 1000,
    usedCount: 0,
    active: true
  };

  db.coupons.push(newCoupon);
  res.status(201).json({ success: true, message: 'Coupon created successfully', coupon: newCoupon });
});

// DELETE /api/coupons/:id (Admin only)
router.delete('/:id', authenticateToken, requireAdmin, (req: AuthenticatedRequest, res) => {
  const idx = db.coupons.findIndex(c => c.id === req.params.id);
  if (idx === -1) {
    res.status(404).json({ success: false, message: 'Coupon not found' });
    return;
  }
  const removed = db.coupons.splice(idx, 1)[0];
  res.json({ success: true, message: `Coupon '${removed.code}' deleted` });
});

export default router;
