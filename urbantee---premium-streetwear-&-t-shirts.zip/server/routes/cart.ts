import { Router } from 'express';
import { db } from '../db.js';
import { optionalAuth, AuthenticatedRequest } from '../middleware/auth.js';
import { CartItem } from '../../src/types.js';

const router = Router();

function getSessionKey(req: AuthenticatedRequest): string {
  if (req.user) return req.user.id;
  const guestHeader = req.headers['x-guest-session-id'];
  if (guestHeader && typeof guestHeader === 'string') return guestHeader;
  return 'guest_default_session';
}

// GET /api/cart
router.get('/', optionalAuth, (req: AuthenticatedRequest, res) => {
  const key = getSessionKey(req);
  const items = db.carts.get(key) || [];
  res.json({ success: true, items });
});

// POST /api/cart
router.post('/', optionalAuth, (req: AuthenticatedRequest, res) => {
  const key = getSessionKey(req);
  const { productId, size, color, quantity } = req.body;

  if (!productId || !size || !color) {
    res.status(400).json({ success: false, message: 'Product ID, size, and color are required.' });
    return;
  }

  const product = db.products.find(p => p.id === productId);
  if (!product) {
    res.status(404).json({ success: false, message: 'Product not found.' });
    return;
  }

  if (product.stock <= 0) {
    res.status(400).json({ success: false, message: 'This item is currently out of stock.' });
    return;
  }

  let cart = db.carts.get(key) || [];
  const existingIdx = cart.findIndex(
    item => item.productId === productId && item.size === size && item.color === color
  );

  const addQty = quantity ? Math.max(1, Number(quantity)) : 1;

  if (existingIdx > -1) {
    const newQty = cart[existingIdx].quantity + addQty;
    if (newQty > product.stock) {
      res.status(400).json({
        success: false,
        message: `Only ${product.stock} items available in stock.`
      });
      return;
    }
    cart[existingIdx].quantity = newQty;
  } else {
    if (addQty > product.stock) {
      res.status(400).json({
        success: false,
        message: `Only ${product.stock} items available in stock.`
      });
      return;
    }
    const newItem: CartItem = {
      id: `cart_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      productId: product.id,
      name: product.name,
      slug: product.slug,
      image: product.images[0],
      size,
      color,
      quantity: addQty,
      price: product.price,
      originalPrice: product.originalPrice,
      stock: product.stock
    };
    cart.push(newItem);
  }

  db.carts.set(key, cart);
  res.json({ success: true, message: 'Added to cart!', items: cart });
});

// PUT /api/cart/:id
router.put('/:id', optionalAuth, (req: AuthenticatedRequest, res) => {
  const key = getSessionKey(req);
  const { quantity } = req.body;
  const cart = db.carts.get(key) || [];

  const item = cart.find(i => i.id === req.params.id);
  if (!item) {
    res.status(404).json({ success: false, message: 'Cart item not found' });
    return;
  }

  const product = db.products.find(p => p.id === item.productId);
  const maxStock = product ? product.stock : 10;

  const targetQty = Number(quantity);
  if (targetQty <= 0) {
    const updated = cart.filter(i => i.id !== req.params.id);
    db.carts.set(key, updated);
    res.json({ success: true, message: 'Item removed from cart', items: updated });
    return;
  }

  if (targetQty > maxStock) {
    res.status(400).json({
      success: false,
      message: `Only ${maxStock} items available in stock.`
    });
    return;
  }

  item.quantity = targetQty;
  db.carts.set(key, cart);
  res.json({ success: true, message: 'Cart updated', items: cart });
});

// DELETE /api/cart/:id
router.delete('/:id', optionalAuth, (req: AuthenticatedRequest, res) => {
  const key = getSessionKey(req);
  let cart = db.carts.get(key) || [];

  if (req.params.id === 'clear') {
    db.carts.set(key, []);
    res.json({ success: true, message: 'Cart cleared', items: [] });
    return;
  }

  cart = cart.filter(i => i.id !== req.params.id);
  db.carts.set(key, cart);
  res.json({ success: true, message: 'Item removed', items: cart });
});

export default router;
