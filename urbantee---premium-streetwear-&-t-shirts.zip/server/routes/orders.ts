import { Router } from 'express';
import { db } from '../db.js';
import { authenticateToken, requireAdmin, AuthenticatedRequest } from '../middleware/auth.js';
import { Order, OrderTimeline } from '../../src/types.js';

const router = Router();

// POST /api/orders
router.post('/', authenticateToken, (req: AuthenticatedRequest, res) => {
  try {
    const user = req.user!;
    const {
      items,
      shippingAddress,
      deliveryOption,
      paymentMethod,
      couponCode,
      subtotal,
      discount,
      deliveryFee,
      tax,
      total
    } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      res.status(400).json({ success: false, message: 'Cart items cannot be empty.' });
      return;
    }

    if (!shippingAddress || !shippingAddress.street || !shippingAddress.pincode) {
      res.status(400).json({ success: false, message: 'Valid shipping address is required.' });
      return;
    }

    // Verify stock and decrement
    for (const item of items) {
      const prod = db.products.find(p => p.id === item.productId);
      if (prod) {
        if (prod.stock < item.quantity) {
          res.status(400).json({
            success: false,
            message: `Not enough stock for ${prod.name}. Available: ${prod.stock}`
          });
          return;
        }
        prod.stock -= item.quantity;
        prod.soldCount = (prod.soldCount || 0) + item.quantity;
      }
    }

    // Clear user cart
    db.carts.delete(user.id);

    // If coupon used, increment coupon usage
    if (couponCode) {
      const coupon = db.coupons.find(c => c.code.toUpperCase() === couponCode.toUpperCase());
      if (coupon) coupon.usedCount += 1;
    }

    const orderNumber = `UT-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date();
    const estDate = new Date();
    estDate.setDate(now.getDate() + (deliveryOption?.type === 'express' ? 2 : 4));

    const initialTimeline: OrderTimeline[] = [
      {
        status: 'Processing',
        date: now.toISOString(),
        note: 'Order placed successfully and payment authorized.'
      }
    ];

    const newOrder: Order = {
      id: `ord_${Date.now()}`,
      orderNumber,
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      userPhone: user.phone || shippingAddress.phone,
      items,
      shippingAddress,
      deliveryOption: deliveryOption || {
        type: 'standard',
        name: 'Standard Express Shipping (3-5 Days)',
        fee: 0,
        estimatedDays: '3-5 Business Days'
      },
      paymentMethod: paymentMethod || 'UPI',
      paymentStatus: paymentMethod === 'COD' ? 'Pending' : 'Completed',
      subtotal: Number(subtotal),
      discount: Number(discount) || 0,
      couponCode,
      deliveryFee: Number(deliveryFee) || 0,
      tax: Number(tax) || 0,
      total: Number(total),
      status: 'Processing',
      trackingTimeline: initialTimeline,
      estimatedDeliveryDate: estDate.toISOString().split('T')[0],
      createdAt: now.toISOString()
    };

    db.orders.unshift(newOrder);

    res.status(201).json({
      success: true,
      message: 'Order placed successfully! 🎉',
      order: newOrder
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to process order' });
  }
});

// GET /api/orders (User gets own orders; Admin gets all orders)
router.get('/', authenticateToken, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  if (user.role === 'ADMIN') {
    res.json({ success: true, orders: db.orders });
    return;
  }
  const userOrders = db.orders.filter(o => o.userId === user.id);
  res.json({ success: true, orders: userOrders });
});

// GET /api/orders/:id
router.get('/:id', authenticateToken, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const order = db.orders.find(o => o.id === req.params.id || o.orderNumber === req.params.id);

  if (!order) {
    res.status(404).json({ success: false, message: 'Order not found' });
    return;
  }

  if (user.role !== 'ADMIN' && order.userId !== user.id) {
    res.status(403).json({ success: false, message: 'Unauthorized access to this order' });
    return;
  }

  res.json({ success: true, order });
});

// PUT /api/orders/:id/status (Admin only)
router.put('/:id/status', authenticateToken, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { status, note } = req.body;
  const order = db.orders.find(o => o.id === req.params.id);

  if (!order) {
    res.status(404).json({ success: false, message: 'Order not found' });
    return;
  }

  const validStatuses: Order['status'][] = [
    'Processing',
    'Confirmed',
    'Shipped',
    'Out for Delivery',
    'Delivered',
    'Cancelled'
  ];

  if (!validStatuses.includes(status)) {
    res.status(400).json({ success: false, message: 'Invalid status' });
    return;
  }

  order.status = status;
  order.trackingTimeline.push({
    status,
    date: new Date().toISOString(),
    note: note || `Status updated to ${status}`
  });

  if (status === 'Delivered') {
    order.paymentStatus = 'Completed';
  }

  res.json({ success: true, message: `Order status updated to ${status}`, order });
});

// PUT /api/orders/:id/cancel (User can cancel if still Processing)
router.put('/:id/cancel', authenticateToken, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const order = db.orders.find(o => o.id === req.params.id);

  if (!order) {
    res.status(404).json({ success: false, message: 'Order not found' });
    return;
  }

  if (user.role !== 'ADMIN' && order.userId !== user.id) {
    res.status(403).json({ success: false, message: 'Unauthorized' });
    return;
  }

  if (order.status !== 'Processing' && user.role !== 'ADMIN') {
    res.status(400).json({
      success: false,
      message: 'Order is already processed/shipped and cannot be cancelled automatically. Please contact support.'
    });
    return;
  }

  order.status = 'Cancelled';
  order.trackingTimeline.push({
    status: 'Cancelled',
    date: new Date().toISOString(),
    note: 'Order cancelled by customer. Refund/reversal initiated.'
  });

  // Restore inventory
  for (const item of order.items) {
    const prod = db.products.find(p => p.id === item.productId);
    if (prod) {
      prod.stock += item.quantity;
      prod.soldCount = Math.max(0, (prod.soldCount || 0) - item.quantity);
    }
  }

  res.json({ success: true, message: 'Order cancelled successfully.', order });
});

export default router;
