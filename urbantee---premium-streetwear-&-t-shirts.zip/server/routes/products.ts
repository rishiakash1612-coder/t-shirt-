import { Router } from 'express';
import { db } from '../db.js';
import { authenticateToken, requireAdmin, AuthenticatedRequest } from '../middleware/auth.js';
import { Product } from '../../src/types.js';

const router = Router();

// GET /api/products
router.get('/', (req, res) => {
  try {
    let result = [...db.products];

    const {
      search,
      category,
      gender,
      sizes,
      colors,
      minPrice,
      maxPrice,
      minRating,
      sort,
      featured,
      bestSeller,
      newArrival,
      onSale,
      limit,
      page
    } = req.query;

    // Search query
    if (search && typeof search === 'string' && search.trim() !== '') {
      const q = search.trim().toLowerCase();
      result = result.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.colors.some(c => c.name.toLowerCase().includes(q))
      );
    }

    // Category filter
    if (category && typeof category === 'string' && category !== 'all') {
      const cats = category.toLowerCase().split(',');
      result = result.filter(p => cats.includes(p.category.toLowerCase()));
    }

    // Gender filter
    if (gender && typeof gender === 'string' && gender !== 'all') {
      const gen = gender.toLowerCase();
      result = result.filter(p => p.gender === gen || p.gender === 'unisex');
    }

    // Sizes filter
    if (sizes && typeof sizes === 'string') {
      const sizeArr = sizes.split(',');
      result = result.filter(p => p.sizes.some(s => sizeArr.includes(s)));
    }

    // Colors filter
    if (colors && typeof colors === 'string') {
      const colorArr = colors.split(',').map(c => c.toLowerCase());
      result = result.filter(p => p.colors.some(c => colorArr.includes(c.name.toLowerCase())));
    }

    // Price range
    if (minPrice) {
      result = result.filter(p => p.price >= Number(minPrice));
    }
    if (maxPrice) {
      result = result.filter(p => p.price <= Number(maxPrice));
    }

    // Rating
    if (minRating) {
      result = result.filter(p => p.rating >= Number(minRating));
    }

    // Flags
    if (featured === 'true') {
      result = result.filter(p => p.featured);
    }
    if (bestSeller === 'true') {
      result = result.filter(p => p.bestSeller);
    }
    if (newArrival === 'true') {
      result = result.filter(p => p.newArrival);
    }
    if (onSale === 'true') {
      result = result.filter(p => p.onSale);
    }

    // Sorting
    switch (sort) {
      case 'price-low':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'best-selling':
        result.sort((a, b) => b.soldCount - a.soldCount);
        break;
      case 'rating':
        result.sort((a, b) => b.rating - a.rating);
        break;
      case 'newest':
      default:
        result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
    }

    const total = result.length;
    const pageSize = limit ? Number(limit) : 24;
    const currentPage = page ? Number(page) : 1;
    const paginated = result.slice((currentPage - 1) * pageSize, currentPage * pageSize);

    res.json({
      success: true,
      total,
      page: currentPage,
      totalPages: Math.ceil(total / pageSize),
      products: paginated
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch products' });
  }
});

// GET /api/products/:id or slug
router.get('/:idOrSlug', (req, res) => {
  const { idOrSlug } = req.params;
  const product = db.products.find(p => p.id === idOrSlug || p.slug === idOrSlug);
  if (!product) {
    res.status(404).json({ success: false, message: 'Product not found' });
    return;
  }

  // Find related products
  const related = db.products
    .filter(p => p.id !== product.id && (p.category === product.category || p.gender === product.gender))
    .slice(0, 4);

  // Fetch product reviews
  const reviews = db.reviews.filter(r => r.productId === product.id);

  res.json({
    success: true,
    product,
    related,
    reviews
  });
});

// POST /api/products (Admin only)
router.post('/', authenticateToken, requireAdmin, (req: AuthenticatedRequest, res) => {
  try {
    const {
      name,
      description,
      price,
      originalPrice,
      category,
      gender,
      sizes,
      colors,
      images,
      stock,
      sku,
      fabric,
      gsm,
      fit,
      featured,
      bestSeller,
      newArrival,
      onSale
    } = req.body;

    if (!name || !price || !category) {
      res.status(400).json({ success: false, message: 'Product name, price, and category are required.' });
      return;
    }

    const discount = originalPrice && originalPrice > price
      ? Math.round(((originalPrice - price) / originalPrice) * 100)
      : 0;

    const slug = name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '') + `-${Date.now().toString().slice(-4)}`;

    const newProduct: Product = {
      id: `prod_${Date.now()}`,
      name: name.trim(),
      slug,
      description: description || 'Premium quality 100% combed cotton t-shirt with modern styling.',
      price: Number(price),
      originalPrice: originalPrice ? Number(originalPrice) : Number(price),
      discount,
      category: category.toLowerCase(),
      gender: gender || 'unisex',
      sizes: sizes && sizes.length > 0 ? sizes : ['S', 'M', 'L', 'XL'],
      colors: colors && colors.length > 0 ? colors : [{ name: 'Black', hex: '#111111' }],
      images: images && images.length > 0 ? images : ['https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80'],
      stock: Number(stock) || 20,
      rating: 5.0,
      reviewCount: 0,
      featured: !!featured,
      bestSeller: !!bestSeller,
      newArrival: newArrival !== undefined ? !!newArrival : true,
      onSale: onSale !== undefined ? !!onSale : discount > 0,
      sku: sku || `UT-${category.slice(0, 3).toUpperCase()}-${Date.now().toString().slice(-4)}`,
      fabric: fabric || '100% Combed Cotton',
      gsm: Number(gsm) || 220,
      fit: fit || 'Oversized Fit',
      care: ['Machine wash cold inside out', 'Do not tumble dry', 'Iron on low'],
      soldCount: 0,
      createdAt: new Date().toISOString()
    };

    db.products.unshift(newProduct);
    res.status(201).json({ success: true, message: 'Product created successfully', product: newProduct });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to create product' });
  }
});

// PUT /api/products/:id (Admin only)
router.put('/:id', authenticateToken, requireAdmin, (req: AuthenticatedRequest, res) => {
  const product = db.products.find(p => p.id === req.params.id);
  if (!product) {
    res.status(404).json({ success: false, message: 'Product not found' });
    return;
  }

  const updates = req.body;
  if (updates.price && updates.originalPrice) {
    updates.discount = Math.round(((updates.originalPrice - updates.price) / updates.originalPrice) * 100);
  }

  Object.assign(product, updates);
  res.json({ success: true, message: 'Product updated successfully', product });
});

// DELETE /api/products/:id (Admin only)
router.delete('/:id', authenticateToken, requireAdmin, (req: AuthenticatedRequest, res) => {
  const idx = db.products.findIndex(p => p.id === req.params.id);
  if (idx === -1) {
    res.status(404).json({ success: false, message: 'Product not found' });
    return;
  }

  const removed = db.products.splice(idx, 1)[0];
  res.json({ success: true, message: `Product '${removed.name}' deleted successfully` });
});

export default router;
