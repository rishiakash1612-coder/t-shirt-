import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { db } from '../db.js';
import { authenticateToken, AuthenticatedRequest, JWT_SECRET } from '../middleware/auth.js';
import { User, Address } from '../../src/types.js';

const router = Router();

// POST /api/auth/register
router.post('/register', (req, res) => {
  try {
    const { name, email, phone, password } = req.body;

    if (!name || !email || !password) {
      res.status(400).json({ success: false, message: 'Name, email, and password are required.' });
      return;
    }

    const existingUser = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existingUser) {
      res.status(400).json({ success: false, message: 'An account with this email address already exists.' });
      return;
    }

    const newUser: User = {
      id: `usr_${Date.now()}`,
      name: name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone ? phone.trim() : '+91 90000 00000',
      passwordHash: bcrypt.hashSync(password, 10),
      role: 'USER',
      addresses: [],
      createdAt: new Date().toISOString()
    };

    db.users.push(newUser);

    const token = jwt.sign(
      { id: newUser.id, role: newUser.role, email: newUser.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { passwordHash: _, ...safeUser } = newUser;

    res.status(201).json({
      success: true,
      message: 'Account created successfully! Welcome to UrbanTee.',
      token,
      user: safeUser
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Internal server error during registration.' });
  }
});

// POST /api/auth/login
router.post('/login', (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ success: false, message: 'Please enter both email and password.' });
      return;
    }

    const user = db.users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());
    if (!user) {
      res.status(401).json({ success: false, message: 'Invalid email or password.' });
      return;
    }

    const isMatch = bcrypt.compareSync(password, user.passwordHash);
    if (!isMatch) {
      res.status(401).json({ success: false, message: 'Invalid email or password.' });
      return;
    }

    const token = jwt.sign(
      { id: user.id, role: user.role, email: user.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { passwordHash: _, ...safeUser } = user;

    res.json({
      success: true,
      message: 'Logged in successfully.',
      token,
      user: safeUser
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Internal server error during login.' });
  }
});

// GET /api/auth/me
router.get('/me', authenticateToken, (req: AuthenticatedRequest, res) => {
  if (!req.user) {
    res.status(401).json({ success: false, message: 'Not authenticated' });
    return;
  }
  const { passwordHash: _, ...safeUser } = req.user;
  res.json({ success: true, user: safeUser });
});

// PUT /api/auth/profile
router.put('/profile', authenticateToken, (req: AuthenticatedRequest, res) => {
  if (!req.user) {
    res.status(401).json({ success: false, message: 'Not authenticated' });
    return;
  }

  const { name, phone } = req.body;
  const user = db.users.find(u => u.id === req.user!.id);
  if (!user) {
    res.status(404).json({ success: false, message: 'User not found' });
    return;
  }

  if (name) user.name = name.trim();
  if (phone) user.phone = phone.trim();

  const { passwordHash: _, ...safeUser } = user;
  res.json({ success: true, message: 'Profile updated successfully', user: safeUser });
});

// PUT /api/auth/change-password
router.put('/change-password', authenticateToken, (req: AuthenticatedRequest, res) => {
  if (!req.user) {
    res.status(401).json({ success: false, message: 'Not authenticated' });
    return;
  }

  const { currentPassword, newPassword } = req.body;
  const user = db.users.find(u => u.id === req.user!.id);
  if (!user) {
    res.status(404).json({ success: false, message: 'User not found' });
    return;
  }

  const isMatch = bcrypt.compareSync(currentPassword, user.passwordHash);
  if (!isMatch) {
    res.status(400).json({ success: false, message: 'Current password does not match.' });
    return;
  }

  user.passwordHash = bcrypt.hashSync(newPassword, 10);
  res.json({ success: true, message: 'Password changed successfully.' });
});

// POST /api/auth/addresses
router.post('/addresses', authenticateToken, (req: AuthenticatedRequest, res) => {
  if (!req.user) {
    res.status(401).json({ success: false, message: 'Not authenticated' });
    return;
  }

  const { name, phone, street, city, state, pincode, isDefault } = req.body;
  if (!name || !phone || !street || !city || !state || !pincode) {
    res.status(400).json({ success: false, message: 'All address fields are required.' });
    return;
  }

  const user = db.users.find(u => u.id === req.user!.id);
  if (!user) {
    res.status(404).json({ success: false, message: 'User not found' });
    return;
  }

  if (isDefault || user.addresses.length === 0) {
    user.addresses.forEach(a => a.isDefault = false);
  }

  const newAddress: Address = {
    id: `addr_${Date.now()}`,
    name: name.trim(),
    phone: phone.trim(),
    street: street.trim(),
    city: city.trim(),
    state: state.trim(),
    pincode: pincode.trim(),
    isDefault: isDefault || user.addresses.length === 0
  };

  user.addresses.push(newAddress);
  const { passwordHash: _, ...safeUser } = user;
  res.status(201).json({ success: true, message: 'Address added successfully', user: safeUser, address: newAddress });
});

// DELETE /api/auth/addresses/:id
router.delete('/addresses/:id', authenticateToken, (req: AuthenticatedRequest, res) => {
  if (!req.user) {
    res.status(401).json({ success: false, message: 'Not authenticated' });
    return;
  }

  const user = db.users.find(u => u.id === req.user!.id);
  if (!user) {
    res.status(404).json({ success: false, message: 'User not found' });
    return;
  }

  user.addresses = user.addresses.filter(a => a.id !== req.params.id);
  if (user.addresses.length > 0 && !user.addresses.some(a => a.isDefault)) {
    user.addresses[0].isDefault = true;
  }

  const { passwordHash: _, ...safeUser } = user;
  res.json({ success: true, message: 'Address removed successfully', user: safeUser });
});

// POST /api/auth/forgot-password
router.post('/forgot-password', (req, res) => {
  const { email } = req.body;
  const user = db.users.find(u => u.email.toLowerCase() === (email || '').toLowerCase());
  if (!user) {
    // Return friendly response without exposing security enumeration
    res.json({ success: true, message: 'If this email exists in our system, a password reset link has been dispatched.' });
    return;
  }
  res.json({
    success: true,
    message: 'Password reset code sent. (For demonstration, code: 442981)',
    demoResetToken: 'demo_token_442981'
  });
});

// POST /api/auth/reset-password
router.post('/reset-password', (req, res) => {
  const { email, newPassword } = req.body;
  const user = db.users.find(u => u.email.toLowerCase() === (email || '').toLowerCase());
  if (!user) {
    res.status(400).json({ success: false, message: 'User account not found.' });
    return;
  }
  user.passwordHash = bcrypt.hashSync(newPassword, 10);
  res.json({ success: true, message: 'Password has been reset successfully. Please log in.' });
});

export default router;
