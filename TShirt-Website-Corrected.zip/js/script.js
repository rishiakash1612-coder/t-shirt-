document.addEventListener("DOMContentLoaded",function(){
const form=document.querySelector(".newsletter form");
if(form)form.addEventListener("submit",e=>{e.preventDefault();alert("Thank you for subscribing! 🎉");form.reset();});
const search=document.getElementById("searchInput"),cat=document.getElementById("categoryFilter"),price=document.getElementById("priceFilter"),cards=document.querySelectorAll(".product-card"),count=document.getElementById("productCount");
function filterProducts(){if(!cards.length)return;let s=(search?.value||"").toLowerCase(),c=cat?.value||"all",p=price?.value||"all",n=0;cards.forEach(card=>{let show=card.dataset.name.toLowerCase().includes(s)&& (c==="all"||card.dataset.category===c);let x=Number(card.dataset.price);if(p==="under300"&&x>=300)show=false;if(p==="under400"&&x>=400)show=false;if(p==="under500"&&x>=500)show=false;card.style.display=show?"block":"none";if(show)n++;});if(count)count.textContent=n+" Products";}
search?.addEventListener("input",filterProducts);cat?.addEventListener("change",filterProducts);price?.addEventListener("change",filterProducts);
window.clearFilters=function(){if(search)search.value="";if(cat)cat.value="all";if(price)price.value="all";filterProducts()};
window.addToCart=function(name,price){let cart=JSON.parse(localStorage.getItem("cart")||"[]");cart.push({name,price,quantity:1});localStorage.setItem("cart",JSON.stringify(cart));alert(name+" added to cart! 🛒");};
document.querySelectorAll(".wishlist").forEach(b=>b.addEventListener("click",()=>b.textContent=b.textContent==="♡"?"♥":"♡"));
const items=document.getElementById("cartItems"),total=document.getElementById("cartTotal");
if(items){let cart=JSON.parse(localStorage.getItem("cart")||"[]"),sum=0;if(!cart.length)items.innerHTML="<p>Your cart is empty.</p>";else{items.innerHTML=cart.map((x,i)=>{sum+=x.price*x.quantity;return `<div style="padding:15px;border-bottom:1px solid #eee"><b>${x.name}</b> — ₹${x.price}</div>`}).join("")}if(total)total.textContent="Total: ₹"+sum;}
});
